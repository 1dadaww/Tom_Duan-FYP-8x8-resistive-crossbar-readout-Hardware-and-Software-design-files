%% Example 04 - Calibrated full scan with DIRECT/VHALF and auto/fixed RF
%
% Run example_03_single_rf_calibration.m first. This script loads the
% latest multi-RF channel/RF calibration, then runs a full scan using either
% DIRECT or VHALF readout and either firmware auto-RF or fixed RF.
%
% For VHALF, the calibrated resistance is the apparent/equivalent resistance
% from total measured current. It is not VHALF sneak-current reconstruction.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
packetAverageCount = 1;
averageCount = 1;
readoutVCM = 1.65;
readoutVREAD = 0.1;
readoutVSEL = readoutVCM + readoutVREAD;

readMode = "DIRECT";        % "DIRECT" or "VHALF"
rfControlMode = "auto";   % "auto" or "fixed"

autoRangeStartRF = "1M";
fixedRF = "1M";

rowResetDelay_s = 0.005;
retryLowLimitV = 0.06;
retryHighLimitV = 0.9;
maxCellRetryAttempts = 12;
retryPause_s = 0.05;
firstCellStartRF = autoRangeStartRF;
firstCellSettle_s = 1.0;
firstCellMaxAttempts = 6;
firstCellRetryPause_s = 0.05;
firstCellStableRelTol = 0.02;
rowExtraGuardRows0 = 2;          % 0-based row index: MATLAB/display row 3
rowExtraGuardDiscardCount = 10;  % extra CELL_* reads only on rowExtraGuardRows0
rowExtraGuardPause_s = 0.02;
firstColumnCorrectionRows0 = 2; % after each row, re-read col0 0 and replace original value
firstColumnCorrectionCols0 = zeros(size(firstColumnCorrectionRows0));
firstColumnCorrectionPause_s = 0.05;

% Fixed-RF mode settings.
fixedManualDiscardCount = 1;
fixedManualDiscardPause_s = 0.05;

% "none" keeps readings from RF ranges absent from the multi-RF calibration
% index as NaN.
calibrationFallback = "none";
knownArrayOhmForError = 1000000; % set [] to skip percent-error output

readMode = upper(readMode);
rfControlMode = lower(rfControlMode);
if readMode ~= "DIRECT" && readMode ~= "VHALF"
    error("Example04:InvalidMode", "readMode must be DIRECT or VHALF.");
end
if rfControlMode ~= "auto" && rfControlMode ~= "fixed"
    error("Example04:InvalidRFControl", "rfControlMode must be auto or fixed.");
end
if readoutVSEL <= readoutVCM
    error("Example04:InvalidBias", "readoutVSEL must be greater than readoutVCM.");
end

primaryCalibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_multi_rf_delta_v_calibration.mat");
legacyCalibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_single_rf_3k3_delta_v_calibration.mat");
calibrationIndexPath = chooseCalibrationIndexPath(primaryCalibrationIndexPath, ...
    legacyCalibrationIndexPath);
if ~exist(calibrationIndexPath, 'file')
    error("Example04:MissingCalibration", ...
        "Calibration index not found. Run example_03_single_rf_calibration.m first.\nExpected: %s", ...
        primaryCalibrationIndexPath);
end
loaded = load(calibrationIndexPath);
readoutModel = loaded.readoutModel;
unusedGlobalFields = {'globalGain', 'globalOffset_a'};
for k = 1:numel(unusedGlobalFields)
    if isfield(readoutModel, unusedGlobalFields{k})
        readoutModel = rmfield(readoutModel, unusedGlobalFields{k});
    end
end
parameterTable = basic_delta_v_model_table(readoutModel);

modeLower = lower(readMode);
resultBaseName = modeLower + "_" + rfControlMode;
if readMode == "DIRECT"
    plotModeLabel = "VCM biased mode";
else
    plotModeLabel = "VHALF mode";
end
resultFolder = create_result_folder("full_scan_" + resultBaseName + "_calibrated_basic");

dev = BasicArrayReader(portName, 115200);
dev.connect();
cleanupObj = onCleanup(@() dev.disconnect());

dev.DefaultReadoutVCM = readoutVCM;
dev.DefaultReadoutVSEL = readoutVSEL;
if rfControlMode == "auto"
    dev.restoreDefaultReadoutState(packetAverageCount, autoRangeStartRF);
else
    dev.restoreDefaultReadoutState(packetAverageCount, fixedRF);
end
status = dev.getStatus();

fprintf("Loaded calibration index:\n%s\n", calibrationIndexPath);
fprintf("Calibration RF values / ohm: %s\n", mat2str(readoutModel.rfValues(:).'));
fprintf("Requested VCM %.6f V, VSEL %.6f V, VREAD %.6f V\n", ...
    readoutVCM, readoutVSEL, readoutVREAD);
fprintf("Using STATUS VCM %.6f V, VSEL %.6f V, VREAD %.6f V\n", ...
    status.VCM, status.VSEL, status.VREAD);
fprintf("Read mode: %s, RF control: %s\n", char(readMode), char(rfControlMode));

if rfControlMode == "auto"
    fprintf("Running %s CELL_%s_AUTO scan by cell...\n", char(readMode), char(readMode));
    scanReadout = scan_cell_auto_retry_in_window(dev, ...
        "mode", readMode, ...
        "startRF", autoRangeStartRF, ...
        "rowResetDelay_s", rowResetDelay_s, ...
        "averageCount", averageCount, ...
        "lowLimit_v", retryLowLimitV, ...
        "highLimit_v", retryHighLimitV, ...
        "maxCellAttempts", maxCellRetryAttempts, ...
        "retryPause_s", retryPause_s, ...
        "firstCellStartRF", firstCellStartRF, ...
        "firstCellSettle_s", firstCellSettle_s, ...
        "firstCellMaxAttempts", firstCellMaxAttempts, ...
        "firstCellRetryPause_s", firstCellRetryPause_s, ...
        "firstCellStableRelTol", firstCellStableRelTol, ...
        "rowExtraGuardRows0", rowExtraGuardRows0, ...
        "rowExtraGuardDiscardCount", rowExtraGuardDiscardCount, ...
        "rowExtraGuardPause_s", rowExtraGuardPause_s, ...
        "postRowRereadRows0", firstColumnCorrectionRows0, ...
        "postRowRereadCols0", firstColumnCorrectionCols0, ...
        "postRowRereadPause_s", firstColumnCorrectionPause_s);
else
    fprintf("Running %s fixed-RF scan by cell, RF %s...\n", char(readMode), char(fixedRF));
    scanReadout = scanFixedRfByCell(dev, readMode, fixedRF, rowResetDelay_s, ...
        averageCount, fixedManualDiscardCount, fixedManualDiscardPause_s, ...
        rowExtraGuardRows0, rowExtraGuardDiscardCount, rowExtraGuardPause_s, ...
        firstColumnCorrectionRows0, firstColumnCorrectionCols0, ...
        firstColumnCorrectionPause_s);
end

save_scan_outputs(scanReadout, resultFolder, resultBaseName + "_raw");
if isfield(scanReadout, "rawRetryTable")
    write_table_compatible(scanReadout.rawRetryTable, ...
        fullfile(resultFolder, resultBaseName + "_raw_retry_table.csv"));
end
if isfield(scanReadout, "rawFixedTrialTable")
    write_table_compatible(scanReadout.rawFixedTrialTable, ...
        fullfile(resultFolder, resultBaseName + "_fixed_raw_trial_table.csv"));
end

calibrated = apply_basic_delta_v_calibration_model(scanReadout, readoutModel, ...
    "deltaV", status.VREAD, "fallback", calibrationFallback, ...
    "numRows", dev.NumRows, "numCols", dev.NumCols);
Rcal = calibrated.matrices.R_readout_calibrated_ohm;
Ical = calibrated.matrices.current_readout_calibrated_a;

write_table_compatible(parameterTable, ...
    fullfile(resultFolder, "loaded_multi_rf_gain_offset_parameters.csv"));
write_table_compatible(calibrated.table, ...
    fullfile(resultFolder, resultBaseName + "_calibrated_table.csv"));
rfUsageTable = summarizeCalibrationRfUse(calibrated.table);
write_table_compatible(rfUsageTable, ...
    fullfile(resultFolder, resultBaseName + "_rf_calibration_usage.csv"));
disp("Actual RF to calibration RF usage:");
disp(rfUsageTable);
if any(~calibrated.table.readout_cal_applied)
    warning("Example04:UncalibratedRF", ...
        "Some cells used an RF range not present in the calibration model. Their calibrated values are NaN.");
end
writematrix(Rcal, fullfile(resultFolder, resultBaseName + "_calibrated_R_ohm.csv"));
writematrix(Ical, fullfile(resultFolder, resultBaseName + "_calibrated_current_a.csv"));
writematrix(scanReadout.matrices.R_ohm, ...
    fullfile(resultFolder, resultBaseName + "_raw_R_ohm.csv"));

plot_matrix_heatmap(Rcal, ...
    plotModeLabel + " calibrated resistance map / ohm", ...
    fullfile(resultFolder, resultBaseName + "_calibrated_R_map.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(Rcal, ...
    plotModeLabel + " calibrated resistance decimal / ohm", ...
    fullfile(resultFolder, resultBaseName + "_calibrated_R_map_decimal.png"), ...
    "logScale", false, "colorbarLabel", "ohm", "showText", true);

if ~isempty(knownArrayOhmForError)
    rawErrorPercent = 100 .* (scanReadout.matrices.R_ohm - knownArrayOhmForError) ./ knownArrayOhmForError;
    calibratedErrorPercent = 100 .* (Rcal - knownArrayOhmForError) ./ knownArrayOhmForError;

    writematrix(rawErrorPercent, fullfile(resultFolder, resultBaseName + "_raw_error_percent_vs_known.csv"));
    writematrix(calibratedErrorPercent, ...
        fullfile(resultFolder, resultBaseName + "_calibrated_error_percent_vs_known.csv"));

    plot_matrix_heatmap(calibratedErrorPercent, ...
        plotModeLabel + " calibrated error vs known / %", ...
        fullfile(resultFolder, resultBaseName + "_calibrated_error_percent_heatmap.png"), ...
        "logScale", false, "colorbarLabel", "%", "showText", true);
end

save(fullfile(resultFolder, resultBaseName + "_calibrated_scan_outputs.mat"), ...
    "scanReadout", "calibrated", "readoutModel", "parameterTable", ...
    "calibrationIndexPath", "Rcal", "Ical", "status", "calibrationFallback", ...
    "knownArrayOhmForError", "readMode", "rfControlMode", ...
    "primaryCalibrationIndexPath", "legacyCalibrationIndexPath", ...
    "autoRangeStartRF", "fixedRF", "rowResetDelay_s", ...
    "retryLowLimitV", "retryHighLimitV", "maxCellRetryAttempts", ...
    "retryPause_s", "firstCellStartRF", "firstCellSettle_s", ...
    "firstCellMaxAttempts", "firstCellRetryPause_s", "firstCellStableRelTol", ...
    "rowExtraGuardRows0", "rowExtraGuardDiscardCount", ...
    "rowExtraGuardPause_s", "firstColumnCorrectionRows0", ...
    "firstColumnCorrectionCols0", "firstColumnCorrectionPause_s", ...
    "fixedManualDiscardCount", "fixedManualDiscardPause_s");

fprintf("Saved calibrated %s %s scan outputs to:\n%s\n", ...
    char(readMode), char(rfControlMode), resultFolder);
if readMode == "VHALF"
    fprintf("Note: VHALF calibrated R is apparent/equivalent resistance from total current.\n");
end

function scan = scanFixedRfByCell(dev, mode, fixedRF, rowResetDelay_s, ...
        averageCount, discardCount, discardPause_s, rowGuardRows0, ...
        rowGuardDiscardCount, rowGuardPause_s, postRowRereadRows0, ...
        postRowRereadCols0, postRowRereadPause_s)
mode = upper(string(mode));
fixedRF = string(fixedRF);
rowGuardRows0 = unique(reshape(double(rowGuardRows0), 1, []));
postRowRereadRows0 = reshape(double(postRowRereadRows0), 1, []);
postRowRereadCols0 = reshape(double(postRowRereadCols0), 1, []);
if numel(postRowRereadRows0) ~= numel(postRowRereadCols0)
    error("Example04:PostRowRereadSize", ...
        "postRowRereadRows0 and postRowRereadCols0 must have the same length.");
end
validateattributes(averageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});
discardCount = round(discardCount);
rowGuardDiscardCount = round(rowGuardDiscardCount);
discardPause_s = max(0, discardPause_s);
rowGuardPause_s = max(0, rowGuardPause_s);
postRowRereadPause_s = max(0, postRowRereadPause_s);

dev.setDefaultReadoutBias();
dev.setRF(fixedRF);
if rowResetDelay_s > 0
    pause(rowResetDelay_s);
end
status = dev.getStatus();

dataRows = cell(dev.NumRows * dev.NumCols, 1);
trialRows = cell(dev.NumRows * dev.NumCols, 1);
idx = 0;
for row0 = 0:dev.NumRows-1
    dev.setDefaultReadoutBias();
    dev.setRF(fixedRF);
    if rowResetDelay_s > 0
        pause(rowResetDelay_s);
    end

    for col0 = 0:dev.NumCols-1
        idx = idx + 1;
        [T, trials] = readFixedCell(dev, row0, col0, mode, fixedRF, ...
            averageCount, discardCount, discardPause_s, rowGuardRows0, ...
            rowGuardDiscardCount, rowGuardPause_s);
        T.fixed_rf_name = repmat(fixedRF, height(T), 1);
        T.rf_control_mode = repmat("fixed", height(T), 1);
        T.row_reset_delay_s = repmat(rowResetDelay_s, height(T), 1);
        T.row_extra_guard_rows0 = repmat(rowListLabelLocal(rowGuardRows0), height(T), 1);
        T.row_extra_guard_discard_count_setting = repmat(rowGuardDiscardCount, height(T), 1);
        T.row_extra_guard_pause_s = repmat(rowGuardPause_s, height(T), 1);
        T.post_row_reread_target_cells = repmat(cellListLabelLocal( ...
            postRowRereadRows0, postRowRereadCols0), height(T), 1);
        T.post_row_reread_replaced_value = false(height(T), 1);
        T.post_row_reread_after_col0 = nan(height(T), 1);
        T.post_row_reread_pause_s = repmat(postRowRereadPause_s, height(T), 1);
        T.scan_method = repmat("CELL_" + mode + "_FIXED_RF", height(T), 1);
        dataRows{idx} = T;
        trialRows{idx} = trials;

        fprintf("row0 %d col0 %d | fixed RF %s | Vadc %.6g V | R %.6g ohm | %s\n", ...
            row0, col0, char(fixedRF), T.vadc_v(1), T.r_ohm(1), char(T.status(1)));
    end

    postTargets = find(postRowRereadRows0 == row0);
    for kk = 1:numel(postTargets)
        targetCol0 = postRowRereadCols0(postTargets(kk));
        if targetCol0 < 0 || targetCol0 >= dev.NumCols
            error("Example04:InvalidPostRowRereadCell", ...
                "post-row reread col0 %g is outside 0..%d.", targetCol0, dev.NumCols - 1);
        end

        targetIdx = row0 * dev.NumCols + targetCol0 + 1;
        if postRowRereadPause_s > 0
            pause(postRowRereadPause_s);
        end

        fprintf("Post-row reread %s fixed-RF cell row0 %d col0 %d after col0 %d; replacing original value...\n", ...
            char(mode), row0, targetCol0, dev.NumCols - 1);
        [Tpost, postTrials] = readFixedCell(dev, row0, targetCol0, mode, fixedRF, ...
            averageCount, discardCount, discardPause_s, rowGuardRows0, ...
            rowGuardDiscardCount, rowGuardPause_s);
        Tpost.fixed_rf_name = repmat(fixedRF, height(Tpost), 1);
        Tpost.rf_control_mode = repmat("fixed", height(Tpost), 1);
        Tpost.row_reset_delay_s = repmat(rowResetDelay_s, height(Tpost), 1);
        Tpost.row_extra_guard_rows0 = repmat(rowListLabelLocal(rowGuardRows0), height(Tpost), 1);
        Tpost.row_extra_guard_discard_count_setting = repmat(rowGuardDiscardCount, height(Tpost), 1);
        Tpost.row_extra_guard_pause_s = repmat(rowGuardPause_s, height(Tpost), 1);
        Tpost.post_row_reread_target_cells = repmat(cellListLabelLocal( ...
            postRowRereadRows0, postRowRereadCols0), height(Tpost), 1);
        Tpost.post_row_reread_replaced_value = true(height(Tpost), 1);
        Tpost.post_row_reread_after_col0 = repmat(dev.NumCols - 1, height(Tpost), 1);
        Tpost.post_row_reread_pause_s = repmat(postRowRereadPause_s, height(Tpost), 1);
        Tpost.scan_method = repmat("CELL_" + mode + "_FIXED_RF_POST_ROW_REREAD", height(Tpost), 1);

        dataRows{targetIdx} = Tpost;
        trialRows{targetIdx} = vertcat(trialRows{targetIdx}, postTrials);

        fprintf("replaced row0 %d col0 %d | fixed RF %s | Vadc %.6g V | R %.6g ohm | %s\n", ...
            row0, targetCol0, char(fixedRF), Tpost.vadc_v(1), ...
            Tpost.r_ohm(1), char(Tpost.status(1)));
    end
end

Tscan = vertcat(dataRows{:});
scan = struct();
scan.command = "CELL_" + mode + "_FIXED_RF";
scan.beginLine = "";
scan.endLine = "";
scan.lines = strings(0, 1);
scan.table = Tscan;
scan.rawFixedTrialTable = vertcat(trialRows{:});
scan.matrices = BasicArrayReader.tableToMatrices(Tscan, dev.NumRows, dev.NumCols);
scan.mode = mode;
scan.autoRF = false;
scan.timestamp = datetime("now");
scan.header = struct("mode", mode + "_FIXED_RF", ...
    "numRows", dev.NumRows, "numCols", dev.NumCols, ...
    "VREAD", status.VREAD, "packet_avg", dev.PacketAverageCount, ...
    "fixed_rf_name", fixedRF, "row_reset_delay_s", rowResetDelay_s, ...
    "discard_count", discardCount, "discard_pause_s", discardPause_s, ...
    "row_extra_guard_rows0", rowGuardRows0, ...
    "row_extra_guard_discard_count", rowGuardDiscardCount, ...
    "row_extra_guard_pause_s", rowGuardPause_s, ...
    "post_row_reread_rows0", postRowRereadRows0, ...
    "post_row_reread_cols0", postRowRereadCols0, ...
    "post_row_reread_pause_s", postRowRereadPause_s);
end

function [accepted, rawTrials] = readFixedCell(dev, row0, col0, mode, fixedRF, ...
        averageCount, discardCount, discardPause_s, rowGuardRows0, ...
        rowGuardDiscardCount, rowGuardPause_s)
rawRows = {};

if rowGuardDiscardCount > 0 && ismember(row0, rowGuardRows0)
    for k = 1:rowGuardDiscardCount
        Tguard = dev.readCell(row0, col0, mode, false);
        Tguard = tagFixedTrial(Tguard, fixedRF, "row_extra_guard_discard", k);
        rawRows{end+1, 1} = Tguard; %#ok<AGROW>
        if rowGuardPause_s > 0
            pause(rowGuardPause_s);
        end
    end
end

for k = 1:discardCount
    Tdiscard = dev.readCell(row0, col0, mode, false);
    Tdiscard = tagFixedTrial(Tdiscard, fixedRF, "manual_discard", k);
    rawRows{end+1, 1} = Tdiscard; %#ok<AGROW>
    if discardPause_s > 0
        pause(discardPause_s);
    end
end

candidateRows = cell(averageCount, 1);
for rep = 1:averageCount
    T = dev.readCell(row0, col0, mode, false);
    T = tagFixedTrial(T, fixedRF, "candidate", rep);
    T.average_repeat_index = repmat(rep, height(T), 1);
    candidateRows{rep} = T;
    rawRows{end+1, 1} = T; %#ok<AGROW>
end

if averageCount == 1
    accepted = candidateRows{1};
else
    accepted = BasicArrayReader.averageDataRows(vertcat(candidateRows{:}));
end
accepted.average_count = repmat(averageCount, height(accepted), 1);
accepted.fixed_read_total_trial_rows = repmat(numel(rawRows), height(accepted), 1);
accepted.fixed_rf_name = repmat(fixedRF, height(accepted), 1);
accepted.rf_control_mode = repmat("fixed", height(accepted), 1);
rawTrials = vertcat(rawRows{:});
end

function T = tagFixedTrial(T, fixedRF, role, index)
T.fixed_rf_name = repmat(string(fixedRF), height(T), 1);
T.rf_control_mode = repmat("fixed", height(T), 1);
T.fixed_trial_role = repmat(string(role), height(T), 1);
T.fixed_trial_index = repmat(index, height(T), 1);
end

function label = rowListLabelLocal(rows0)
if isempty(rows0)
    label = "";
else
    label = strjoin(string(rows0), ";");
end
end

function label = cellListLabelLocal(rows0, cols0)
if isempty(rows0)
    label = "";
    return;
end

parts = strings(numel(rows0), 1);
for k = 1:numel(rows0)
    parts(k) = string(rows0(k)) + "," + string(cols0(k));
end
label = strjoin(parts, ";");
end

function calibrationIndexPath = chooseCalibrationIndexPath(primaryPath, legacyPath)
if exist(primaryPath, 'file')
    calibrationIndexPath = primaryPath;
elseif exist(legacyPath, 'file')
    calibrationIndexPath = legacyPath;
else
    calibrationIndexPath = primaryPath;
end
end

function summary = summarizeCalibrationRfUse(T)
actualRf = T.readout_cal_rf_actual_ohm;
matchedRf = T.readout_cal_rf_nominal_ohm;
applied = logical(T.readout_cal_applied);

actualLabel = compose("%.12g", actualRf);
matchedLabel = compose("%.12g", matchedRf);
matchedLabel(~isfinite(matchedRf)) = "uncalibrated";

[groups, rfActualLabel, rfMatchedLabel] = findgroups(actualLabel, matchedLabel);
numCells = splitapply(@numel, applied, groups);
numCalibrated = splitapply(@sum, applied, groups);
numUncalibrated = numCells - numCalibrated;
rfActual = str2double(rfActualLabel);
rfMatched = str2double(rfMatchedLabel);

summary = table(rfActual, rfMatched, numCells, numCalibrated, numUncalibrated, ...
    'VariableNames', {'actual_rf_ohm', 'matched_calibration_rf_ohm', ...
    'num_cells', 'num_calibrated', 'num_uncalibrated'});
end
