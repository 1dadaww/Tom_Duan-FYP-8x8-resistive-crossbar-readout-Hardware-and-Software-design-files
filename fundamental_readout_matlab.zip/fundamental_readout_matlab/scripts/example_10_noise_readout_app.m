%% Example 10 - Launch fundamental ADC noise and resolution app
clear; clc;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

app = FundamentalNoiseReadoutApp(); %#ok<NASGU>
