%% Example 03 - Single-RF delta-V readout calibration with multi-RF index
%
% Calibration board:
%   row 0 -> col 0 through one known resistor
%   row 1 -> col 1 through one known resistor
%   ...
%   row 7 -> col 7 through one known resistor
%
% The script calibrates one feedback-resistor range across all eight readout
% channels. Calibration data for other RF ranges remain in the persistent
% index; recalibrating the same range replaces its earlier entries.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
packetAverageCount = 3;
averageCount = 3;
knownResistorOhm = 1000000;
calibrationRF = "1M";
vcm = 1.65;
deltaVList = [0.10, 0.15];
rfSettlingDelay_s = 1.0;
biasSettlingDelay_s = 1.0;
calibrationSingleCellReadDelay_s = 0.2;
calibrationLowLimitV = 0.01;
calibrationHighLimitV = 1.05;
calibrationMaxCellAttempts = 6;
calibrationRetryPause_s = 0.05;

resultFolder = create_result_folder("single_rf_delta_v_calibration_basic");
calibrationIndexFolder = fullfile(projectRoot, "calibration_index");
if ~exist(calibrationIndexFolder, 'dir')
    mkdir(calibrationIndexFolder);
end
legacyCalibrationIndexPath = fullfile(calibrationIndexFolder, ...
    "latest_single_rf_3k3_delta_v_calibration.mat");
calibrationIndexPath = fullfile(calibrationIndexFolder, ...
    "latest_multi_rf_delta_v_calibration.mat");
parameterIndexPath = fullfile(calibrationIndexFolder, ...
    "latest_multi_rf_gain_offset_parameters.csv");
legacyParameterIndexPath = fullfile(calibrationIndexFolder, ...
    "latest_single_rf_3k3_gain_offset_parameters.csv");

dev = BasicArrayReader(portName, 115200);
dev.connect();
cleanupObj = onCleanup(@() dev.disconnect());

dev.setPacketAverage(packetAverageCount);
dev.DefaultReadoutVCM = vcm;
status0 = dev.getStatus();
fprintf("Connected. Current STATUS VREAD = %.6f V\n", status0.VREAD);

fprintf("\nConnect the diagonal calibration board now.\n");
fprintf("Expected wiring: row i -> col i, for i = 0..7.\n");
fprintf("Known resistor value: %.6g ohm. RF range being calibrated: %s.\n", ...
    knownResistorOhm, calibrationRF);
input("Press Enter when the board is connected and ready...", "s");

fprintf("Setting calibration RF to %s for all channels.\n", calibrationRF);
dev.setRF(calibrationRF);
pause(rfSettlingDelay_s);

newCalRows = {};
for deltaV = deltaVList
    vsel = vcm + deltaV;
    fprintf("\nSetting BIAS VCM %.6f V, VSEL %.6f V, deltaV %.6f V\n", ...
        vcm, vsel, deltaV);
    dev.setBias(vcm, vsel);
    pause(biasSettlingDelay_s);
    biasStatus = dev.getStatus();
    actualDeltaV = biasStatus.VREAD;
    fprintf("STATUS after bias: VCM %.6f V, VSEL %.6f V, VREAD %.6f V\n", ...
        biasStatus.VCM, biasStatus.VSEL, actualDeltaV);

    for ch = 0:dev.NumCols-1
        row = readCalibrationCellSingleStyle(dev, ch, calibrationRF, ...
            packetAverageCount, vcm, vsel, calibrationSingleCellReadDelay_s, ...
            averageCount, calibrationLowLimitV, calibrationHighLimitV, ...
            calibrationMaxCellAttempts, calibrationRetryPause_s);
        row.board = "single_rf_diagonal";
        row.channel0 = ch;
        row.rf_name_requested = calibrationRF;
        row.r_true = knownResistorOhm;
        row.r_measured = row.r_ohm;
        row.vcm_requested = vcm;
        row.vsel_requested = vsel;
        row.delta_v_requested = deltaV;
        row.vcm = biasStatus.VCM;
        row.vsel = biasStatus.VSEL;
        row.delta_v = actualDeltaV;
        row.current_true_a = actualDeltaV / knownResistorOhm;
        row.calibration_note = "single RF diagonal channel calibration";
        newCalRows{end+1, 1} = row; %#ok<SAGROW>

        fprintf("  ch %d | RF %s | dV %.6g V | tries %d | Iraw %.6g A | Itrue %.6g A | Rraw %.6g ohm | %s\n", ...
            ch, calibrationRF, actualDeltaV, row.calibration_single_cell_attempt(1), ...
            abs(row.current_a), row.current_true_a, row.r_ohm, ...
            char(row.calibration_single_cell_reason(1)));
    end
end

newCalibrationTable = vertcat(newCalRows{:});
write_table_compatible(newCalibrationTable, ...
    fullfile(resultFolder, "single_rf_new_calibration_table.csv"));

[previousCalibrationTable, previousIndexPathUsed] = loadPreviousCalibrationTable( ...
    calibrationIndexPath, legacyCalibrationIndexPath);
[calibrationTable, replacedCalibrationTable] = mergeCalibrationTableByRF( ...
    previousCalibrationTable, newCalibrationTable, calibrationRF);

write_table_compatible(calibrationTable, ...
    fullfile(resultFolder, "multi_rf_combined_calibration_table.csv"));
if ~isempty(replacedCalibrationTable)
    write_table_compatible(replacedCalibrationTable, ...
        fullfile(resultFolder, "replaced_same_rf_previous_calibration_table.csv"));
end

readoutModel = fit_basic_delta_v_calibration_model(calibrationTable, ...
    "numChannels", dev.NumCols, "minPoints", 2);
parameterTable = basic_delta_v_model_table(readoutModel);

write_table_compatible(parameterTable, ...
    fullfile(resultFolder, "multi_rf_gain_offset_parameters.csv"));
write_table_compatible(parameterTable, ...
    parameterIndexPath);
write_table_compatible(parameterTable, legacyParameterIndexPath);

save(fullfile(resultFolder, "multi_rf_delta_v_calibration_model.mat"), ...
    "readoutModel", "parameterTable", "calibrationTable", ...
    "newCalibrationTable", "replacedCalibrationTable", ...
    "previousCalibrationTable", "previousIndexPathUsed", ...
    "knownResistorOhm", "calibrationRF", "deltaVList", "vcm", ...
    "packetAverageCount", "averageCount", ...
    "calibrationSingleCellReadDelay_s", "calibrationLowLimitV", ...
    "calibrationHighLimitV", "calibrationMaxCellAttempts", ...
    "calibrationRetryPause_s");

save(calibrationIndexPath, ...
    "readoutModel", "parameterTable", "calibrationTable", ...
    "newCalibrationTable", "replacedCalibrationTable", ...
    "previousCalibrationTable", "previousIndexPathUsed", ...
    "knownResistorOhm", "calibrationRF", "deltaVList", "vcm", ...
    "packetAverageCount", "averageCount", ...
    "calibrationSingleCellReadDelay_s", "calibrationLowLimitV", ...
    "calibrationHighLimitV", "calibrationMaxCellAttempts", ...
    "calibrationRetryPause_s");
save(legacyCalibrationIndexPath, ...
    "readoutModel", "parameterTable", "calibrationTable", ...
    "newCalibrationTable", "replacedCalibrationTable", ...
    "previousCalibrationTable", "previousIndexPathUsed", ...
    "knownResistorOhm", "calibrationRF", "deltaVList", "vcm", ...
    "packetAverageCount", "averageCount", ...
    "calibrationSingleCellReadDelay_s", "calibrationLowLimitV", ...
    "calibrationHighLimitV", "calibrationMaxCellAttempts", ...
    "calibrationRetryPause_s");

disp("Multi-RF calibration gain/offset parameters:");
disp(parameterTable);
fprintf("Model now contains RF values / ohm: %s\n", mat2str(readoutModel.rfValues(:).'));
if ~isempty(previousIndexPathUsed)
    fprintf("Loaded previous calibration table from:\n%s\n", previousIndexPathUsed);
end
fprintf("Replaced %d previous row(s) for RF %s; kept %d previous row(s) from other RF range(s).\n", ...
    height(replacedCalibrationTable), calibrationRF, ...
    max(0, height(previousCalibrationTable) - height(replacedCalibrationTable)));

dev.restoreDefaultReadoutState(packetAverageCount, calibrationRF);

fprintf("\nSaved calibration outputs to:\n%s\n", resultFolder);
fprintf("Saved persistent calibration index to:\n%s\n", calibrationIndexPath);
fprintf("Also updated legacy compatibility index:\n%s\n", legacyCalibrationIndexPath);

function accepted = readCalibrationCellSingleStyle(dev, ch, rfName, ...
        packetAverageCount, vcm, vsel, readDelay_s, averageCount, ...
        lowLimitV, highLimitV, maxCellAttempts, retryPause_s)
rawRows = cell(maxCellAttempts, 1);
accepted = table();
rfName = string(rfName);

for attempt = 1:maxCellAttempts
    dev.setPacketAverage(packetAverageCount);
    dev.setBias(vcm, vsel);
    dev.setRF(rfName);
    dev.setRFChannel(ch, rfName);

    if readDelay_s > 0
        pause(readDelay_s);
    end

    T = dev.readCellAveraged(ch, ch, "DIRECT", false, averageCount);
    [inWindow, reason] = classifyCalibrationCellResult(T, lowLimitV, highLimitV);
    T.calibration_single_cell_style = true(height(T), 1);
    T.calibration_single_cell_attempt = repmat(attempt, height(T), 1);
    T.calibration_single_cell_in_window = repmat(logical(inWindow), height(T), 1);
    T.calibration_single_cell_reason = repmat(string(reason), height(T), 1);
    T.calibration_single_cell_read_delay_s = repmat(readDelay_s, height(T), 1);
    T.calibration_low_limit_v = repmat(lowLimitV, height(T), 1);
    T.calibration_high_limit_v = repmat(highLimitV, height(T), 1);
    T.calibration_max_cell_attempts = repmat(maxCellAttempts, height(T), 1);
    rawRows{attempt} = T;

    if inWindow
        accepted = T;
        accepted.calibration_single_cell_role = "accepted_in_window";
        break;
    end

    if retryPause_s > 0
        pause(retryPause_s);
    end
end

rawTable = vertcat(rawRows{~cellfun(@isempty, rawRows)});
if isempty(accepted)
    accepted = BasicArrayReader.pickBestGuardedCandidate(rawTable, lowLimitV, highLimitV);
    accepted.calibration_single_cell_role = "accepted_best_after_retry_limit";
    accepted.calibration_single_cell_reason = "MAX_RETRY_LIMIT";
    accepted.calibration_single_cell_in_window = false;
end
accepted.calibration_single_cell_total_reads = height(rawTable);
accepted.calibration_single_cell_raw_table = {rawTable};
end

function [inWindow, reason] = classifyCalibrationCellResult(T, lowLimitV, highLimitV)
vadc = abs(T.vadc_v(1));
status = upper(string(T.status(1)));
if status ~= "OK"
    inWindow = false;
    reason = "STATUS_" + status;
elseif ~isfinite(vadc)
    inWindow = false;
    reason = "NONFINITE_ADC_RETRY";
elseif vadc < lowLimitV
    inWindow = false;
    reason = "LOW_ADC_RETRY_RF_UP_OR_SWITCH";
elseif vadc > highLimitV
    inWindow = false;
    reason = "HIGH_ADC_RETRY_RF_DOWN_OR_SWITCH";
else
    inWindow = true;
    reason = "OK_IN_WINDOW";
end
end

function [Tprev, pathUsed] = loadPreviousCalibrationTable(primaryPath, legacyPath)
Tprev = table();
pathUsed = "";
for p = [string(primaryPath), string(legacyPath)]
    if exist(p, 'file')
        S = load(p);
        if isfield(S, "calibrationTable") && istable(S.calibrationTable)
            Tprev = S.calibrationTable;
            pathUsed = p;
            return;
        end
    end
end
end

function [Tcombined, Treplaced] = mergeCalibrationTableByRF(Tprev, Tnew, rfName)
if isempty(Tprev) || height(Tprev) == 0
    Tcombined = Tnew;
    Treplaced = Tnew([],:);
    return;
end

[Tprev, Tnew] = alignTablesForVertcat(Tprev, Tnew);

replace = false(height(Tprev), 1);
vars = string(Tprev.Properties.VariableNames);
if ismember("rf_name_requested", vars)
    replace = replace | string(Tprev.rf_name_requested) == string(rfName);
end
if ismember("rf_ohm", vars) && ismember("rf_ohm", string(Tnew.Properties.VariableNames))
    newRfOhm = median(Tnew.rf_ohm, "omitnan");
    replace = replace | abs(Tprev.rf_ohm - newRfOhm) <= max(1, abs(newRfOhm) * 0.05);
end

Treplaced = Tprev(replace, :);
Tcombined = [Tprev(~replace, :); Tnew];
end

function [A, B] = alignTablesForVertcat(A, B)
varsA = string(A.Properties.VariableNames);
varsB = string(B.Properties.VariableNames);
allVars = [varsA, varsB(~ismember(varsB, varsA))];

for v = allVars
    if ~ismember(v, varsA)
        A.(v) = defaultColumnLike(B.(v), height(A));
    end
    if ~ismember(v, varsB)
        B.(v) = defaultColumnLike(A.(v), height(B));
    end
end
A = A(:, cellstr(allVars));
B = B(:, cellstr(allVars));
end

function col = defaultColumnLike(refCol, n)
if isnumeric(refCol)
    col = nan(n, 1);
elseif islogical(refCol)
    col = false(n, 1);
elseif isstring(refCol)
    col = strings(n, 1);
elseif iscell(refCol)
    col = cell(n, 1);
elseif iscategorical(refCol)
    col = categorical(strings(n, 1));
else
    col = strings(n, 1);
end
end
