%% Example 02 - Read one cell
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
packetAverageCount = 1;
averageCount = 1;
defaultRF = "100k";

row0 = 0;
col0 = 0;
modeList = "DIRECT"; % use one mode or compare several
rfMode = "manual";       % "auto" = CELL_*_AUTO, "manual" = fixed manual RF
manualRF = "100k";
readDelay_s = 1;

% Apply the per-channel/per-RF gain and offset model saved by example 03.
% Raw current_a and r_ohm are always retained in the output table.
applyCalibration = true;
calibrationFallback = "none";
calibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_multi_rf_delta_v_calibration.mat");

% MATLAB guard limits for auto-RF single-cell reading. The firmware still
% performs the RF selection for CELL_*_AUTO; MATLAB resets the start RF and
% retries until the returned ADC voltage is within this adjustable window.
autoRangeStartRF = "100k";
autoLowLimitV = 0.08;
autoHighLimitV = 0.9;
autoPrimeReadCount = 1;
autoMaxReadAttempts = 6;
autoRetryPause_s = 0.10;
autoStableRelTol = 0.05;

if applyCalibration
    if ~exist(calibrationIndexPath, 'file')
        error("Example02:MissingCalibration", ...
            "Calibration index not found. Run example_03_single_rf_calibration.m first.\nExpected: %s", ...
            calibrationIndexPath);
    end
    loadedCalibration = load(calibrationIndexPath);
    if ~isfield(loadedCalibration, "readoutModel")
        error("Example02:InvalidCalibration", ...
            "Calibration file does not contain readoutModel: %s", ...
            calibrationIndexPath);
    end
    readoutModel = loadedCalibration.readoutModel;
    unusedGlobalFields = {'globalGain', 'globalOffset_a'};
    for fieldIndex = 1:numel(unusedGlobalFields)
        if isfield(readoutModel, unusedGlobalFields{fieldIndex})
            readoutModel = rmfield(readoutModel, unusedGlobalFields{fieldIndex});
        end
    end
    fprintf("Loaded channel/RF calibration:\n%s\n", calibrationIndexPath);
end

dev = BasicArrayReader(portName, 115200);
dev.connect();
cleanupObj = onCleanup(@() dev.disconnect());

dev.restoreDefaultReadoutState(packetAverageCount, defaultRF);
status = dev.getStatus();
fprintf("VREAD from STATUS = %.6f V\n", status.VREAD);

autoRF = lower(string(rfMode)) == "auto";
if autoRF
    if autoLowLimitV <= 0 || autoHighLimitV <= autoLowLimitV
        error("Example02:InvalidAutoRangeWindow", ...
            "autoLowLimitV must be positive and lower than autoHighLimitV.");
    end
    dev.AutoCellLowLimit_v = autoLowLimitV;
    dev.AutoCellHighLimit_v = autoHighLimitV;
    dev.AutoCellPrimeReadCount = autoPrimeReadCount;
    dev.AutoCellMaxReadAttempts = autoMaxReadAttempts;
    dev.AutoCellRetryPause_s = autoRetryPause_s;
    dev.AutoCellConsistencyRelTol = autoStableRelTol;

    fprintf("MATLAB auto-RF guard: start RF %s, ADC window %.3f to %.3f V, max attempts %d.\n", ...
        autoRangeStartRF, autoLowLimitV, autoHighLimitV, autoMaxReadAttempts);
end
modeList = upper(convertCharsToStrings(modeList));
validModes = ["DIRECT", "VHALF", "FLOAT"];
if any(~ismember(modeList, validModes))
    error("Example02:InvalidMode", ...
        "modeList entries must be DIRECT, VHALF, or FLOAT.");
end

readTables = cell(numel(modeList), 1);
for k = 1:numel(modeList)
    thisMode = modeList(k);
    dev.restoreDefaultReadoutState(packetAverageCount, defaultRF);
    if ~autoRF
        dev.setRFChannel(col0, manualRF);
    end

    fprintf("\nWaiting %.1f s before %s cell read...\n", readDelay_s, thisMode);
    pause(readDelay_s);
    if autoRF
        [cellRead, autoGuardTable] = readAutoCellAveragedGuarded( ...
            dev, row0, col0, thisMode, autoRangeStartRF, averageCount);
        cellRead.auto_range_start_rf = repmat(autoRangeStartRF, height(cellRead), 1);
        cellRead.auto_low_limit_v = repmat(autoLowLimitV, height(cellRead), 1);
        cellRead.auto_high_limit_v = repmat(autoHighLimitV, height(cellRead), 1);
        cellRead.auto_guard_raw_table = {autoGuardTable};
    else
        cellRead = dev.readCellAveraged(row0, col0, thisMode, false, averageCount);
    end
    cellRead.requested_mode = repmat(thisMode, height(cellRead), 1);
    cellRead = movevars(cellRead, "requested_mode", "Before", 1);

    if applyCalibration
        calibrated = apply_basic_delta_v_calibration_model( ...
            cellRead, readoutModel, ...
            "deltaV", status.VREAD, ...
            "fallback", calibrationFallback, ...
            "numRows", dev.NumRows, "numCols", dev.NumCols);
        cellRead = calibrated.table;
        if ~all(cellRead.readout_cal_applied)
            warning("Example02:CalibrationNotApplied", ...
                "No calibration parameters were found for channel %d at RF %.6g ohm.", ...
                col0, cellRead.rf_ohm(1));
        end
    end

    readTables{k} = cellRead;
    disp(cellRead);

    printSingleCellInterpretation(cellRead, status, dev, thisMode);
end

cellReadTable = vertcat(readTables{:});
if numel(modeList) > 1
    disp("Combined single-cell mode comparison:");
    comparisonVariables = ["requested_mode", "row0", "col0", "rf_ohm", ...
        "vadc_v", "current_a", "r_ohm"];
    if applyCalibration
        comparisonVariables = [comparisonVariables, ...
            "current_readout_calibrated_a", ...
            "r_readout_calibrated_ohm", "readout_cal_applied"];
    end
    comparisonVariables = [comparisonVariables, "status", "attempts"];
    disp(cellReadTable(:, comparisonVariables));
end

function [accepted, rawGuardTable] = readAutoCellAveragedGuarded( ...
        dev, row0, col0, mode, startRF, averageCount)
validateattributes(averageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});

acceptedRows = cell(averageCount, 1);
guardRows = cell(averageCount, 1);
for rep = 1:averageCount
    [T, G] = dev.readCellAutoGuarded(row0, col0, mode, startRF);
    T.average_repeat_index = repmat(rep, height(T), 1);
    G.average_repeat_index = repmat(rep, height(G), 1);
    acceptedRows{rep} = T;
    guardRows{rep} = G;
end

rawAcceptedTable = vertcat(acceptedRows{:});
rawGuardTable = vertcat(guardRows{:});
if averageCount == 1
    accepted = rawAcceptedTable;
else
    accepted = BasicArrayReader.averageDataRows(rawAcceptedTable);
    accepted.average_raw_table = {rawAcceptedTable};
end
accepted.average_count = repmat(averageCount, height(accepted), 1);
accepted.auto_guard_total_reads = repmat(height(rawGuardTable), height(accepted), 1);
end

function printSingleCellInterpretation(cellRead, status, dev, modeUpper)
currentTotal = abs(cellRead.current_a(1));
rEquivalent = status.VREAD / currentTotal;
hasCalibrated = ismember("current_readout_calibrated_a", ...
    string(cellRead.Properties.VariableNames)) && ...
    isfinite(cellRead.current_readout_calibrated_a(1)) && ...
    cellRead.current_readout_calibrated_a(1) > 0;
if hasCalibrated
    calibratedCurrent = cellRead.current_readout_calibrated_a(1);
    calibratedEquivalentR = status.VREAD / calibratedCurrent;
else
    calibratedCurrent = nan;
    calibratedEquivalentR = nan;
end

if modeUpper == "VHALF"
    halfSelectFactor = (status.VHALF - status.VCM) / status.VREAD;
    uniformColumnFactor = 1 + (dev.NumRows - 1) * halfSelectFactor;
    rUniformColumnEstimate = rEquivalent * uniformColumnFactor;
    calibratedUniformColumnEstimate = ...
        calibratedEquivalentR * uniformColumnFactor;
    interpretation = table(currentTotal, rEquivalent, calibratedCurrent, ...
        calibratedEquivalentR, halfSelectFactor, uniformColumnFactor, ...
        rUniformColumnEstimate, calibratedUniformColumnEstimate, ...
        'VariableNames', {'total_measured_current_a', ...
        'raw_apparent_equivalent_R_ohm', ...
        'calibrated_total_current_a', ...
        'calibrated_apparent_equivalent_R_ohm', ...
        'half_select_factor', 'uniform_column_multiplier', ...
        'raw_selected_R_if_column_uniform_ohm', ...
        'calibrated_selected_R_if_column_uniform_ohm'});
    disp("VHALF interpretation:");
    disp(interpretation);
    fprintf("VHALF r_ohm is apparent/equivalent, not directly the selected cell resistance.\n");
    fprintf("For an 8x8 uniform 10k column, expected apparent R is about 10k / %.3g = %.4g ohm.\n", ...
        uniformColumnFactor, 10000 / uniformColumnFactor);
elseif modeUpper == "FLOAT"
    interpretation = table(currentTotal, rEquivalent, calibratedCurrent, ...
        calibratedEquivalentR, ...
        'VariableNames', {'total_measured_current_a', ...
        'raw_float_apparent_equivalent_R_ohm', ...
        'calibrated_total_current_a', ...
        'calibrated_float_apparent_equivalent_R_ohm'});
    disp("FLOAT interpretation:");
    disp(interpretation);
    fprintf("FLOAT r_ohm is apparent/equivalent with unselected switch lines Hi-Z.\n");
    fprintf("The unselected rows/columns are not driven, but they are still connected through the passive resistor array, so sneak paths can lower the apparent resistance.\n");
else
    interpretation = table(currentTotal, rEquivalent, calibratedCurrent, ...
        calibratedEquivalentR, ...
        'VariableNames', {'raw_selected_cell_current_a', ...
        'raw_selected_cell_R_ohm', 'calibrated_selected_cell_current_a', ...
        'calibrated_selected_cell_R_ohm'});
    disp("DIRECT interpretation:");
    disp(interpretation);
end
end
