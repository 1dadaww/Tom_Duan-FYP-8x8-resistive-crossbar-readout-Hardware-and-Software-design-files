%% Example 09 - Mixed-resistance array comparison
%
% This script does not access the ESP32. It compares the latest saved
% example-04 VCM-biased result with the latest saved example-05 VHALF
% iterative reconstruction using an 8x8 known resistance matrix.
%
% Edit known22kCellsOneBased if the physical 22 kohm locations change.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% Known board definition for the current mixed-array test.
knownLowR_ohm = 10e3;
knownHighR_ohm = 22e3;
known22kCellsOneBased = [ ...
    1, 1; ...
    3, 2; ...
    3, 4; ...
    3, 7; ...
    5, 1; ...
    5, 5; ...
    7, 3; ...
    7, 7];

% Saved result paths.
vcmResultFile = fullfile(projectRoot, 'results', ...
    'latest_full_scan_direct_auto_calibrated_basic', ...
    'direct_auto_calibrated_R_ohm.csv');
vhalfResultFile = fullfile(projectRoot, 'results', ...
    'latest_vhalf_iterative_from_example06_resistance_basic', ...
    'vhalf_iterative_reconstructed_R_ohm.csv');
legacyVhalfResultFile = fullfile(projectRoot, 'results', ...
    'latest_vhalf_iterative_from_example17_resistance_basic', ...
    'vhalf_iterative_reconstructed_R_ohm.csv');
if ~exist(vhalfResultFile, 'file') && exist(legacyVhalfResultFile, 'file')
    vhalfResultFile = legacyVhalfResultFile;
end

if ~exist(vcmResultFile, 'file')
    error("Example09:MissingVcmResult", ...
        "VCM-biased result was not found. Run example 04 first.\nExpected: %s", ...
        vcmResultFile);
end
if ~exist(vhalfResultFile, 'file')
    error("Example09:MissingVhalfResult", ...
        "VHALF iterative result was not found. Run example 05 first.\nExpected: %s", ...
        vhalfResultFile);
end

Rknown = knownLowR_ohm .* ones(8, 8);
for k = 1:size(known22kCellsOneBased, 1)
    row = known22kCellsOneBased(k, 1);
    col = known22kCellsOneBased(k, 2);
    validateattributes(row, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 8});
    validateattributes(col, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 8});
    Rknown(row, col) = knownHighR_ohm;
end

Rvcm = readmatrix(vcmResultFile);
Rvhalf = readmatrix(vhalfResultFile);
validateResistanceMatrix(Rvcm, "VCM-biased");
validateResistanceMatrix(Rvhalf, "VHALF iterative");

vcmErrorPercent = 100 .* (Rvcm - Rknown) ./ Rknown;
vhalfErrorPercent = 100 .* (Rvhalf - Rknown) ./ Rknown;
vcmAbsoluteErrorPercent = abs(vcmErrorPercent);
vhalfAbsoluteErrorPercent = abs(vhalfErrorPercent);

classificationThresholdOhm = mean([knownLowR_ohm, knownHighR_ohm]);
methodSummary = [ ...
    calculateMethodSummary("VCM biased", Rvcm, Rknown, ...
        classificationThresholdOhm); ...
    calculateMethodSummary("VHALF iterative", Rvhalf, Rknown, ...
        classificationThresholdOhm)];

groupSummary = [ ...
    calculateGroupSummary("VCM biased", knownLowR_ohm, ...
        Rvcm(Rknown == knownLowR_ohm)); ...
    calculateGroupSummary("VCM biased", knownHighR_ohm, ...
        Rvcm(Rknown == knownHighR_ohm)); ...
    calculateGroupSummary("VHALF iterative", knownLowR_ohm, ...
        Rvhalf(Rknown == knownLowR_ohm)); ...
    calculateGroupSummary("VHALF iterative", knownHighR_ohm, ...
        Rvhalf(Rknown == knownHighR_ohm))];

cellComparison = makeCellComparisonTable(Rknown, Rvcm, Rvhalf, ...
    vcmErrorPercent, vhalfErrorPercent, classificationThresholdOhm);

resultFolder = create_result_folder("mixed_array_vcm_vhalf_analysis_basic");
writematrix(Rknown, fullfile(resultFolder, "known_mixed_array_R_ohm.csv"));
writematrix(Rvcm, fullfile(resultFolder, "vcm_biased_measured_R_ohm.csv"));
writematrix(Rvhalf, fullfile(resultFolder, ...
    "vhalf_iterative_reconstructed_R_ohm.csv"));
writematrix(vcmErrorPercent, fullfile(resultFolder, ...
    "vcm_biased_error_percent_vs_mixed_known.csv"));
writematrix(vhalfErrorPercent, fullfile(resultFolder, ...
    "vhalf_iterative_error_percent_vs_mixed_known.csv"));
write_table_compatible(methodSummary, ...
    fullfile(resultFolder, "mixed_array_method_summary.csv"));
write_table_compatible(groupSummary, ...
    fullfile(resultFolder, "mixed_array_resistance_group_summary.csv"));
write_table_compatible(cellComparison, ...
    fullfile(resultFolder, "mixed_array_cell_comparison.csv"));

plotResistanceComparison(Rknown, Rvcm, Rvhalf, resultFolder);
plotErrorComparison(vcmErrorPercent, vhalfErrorPercent, resultFolder);
plotKnownAgainstMeasured(Rknown, Rvcm, Rvhalf, resultFolder);
writeDiscussion(resultFolder, methodSummary, groupSummary, ...
    known22kCellsOneBased, vcmResultFile, vhalfResultFile);

save(fullfile(resultFolder, "mixed_array_vcm_vhalf_analysis.mat"), ...
    "Rknown", "Rvcm", "Rvhalf", "vcmErrorPercent", ...
    "vhalfErrorPercent", "vcmAbsoluteErrorPercent", ...
    "vhalfAbsoluteErrorPercent", "methodSummary", "groupSummary", ...
    "cellComparison", "knownLowR_ohm", "knownHighR_ohm", ...
    "known22kCellsOneBased", "classificationThresholdOhm", ...
    "vcmResultFile", "vhalfResultFile");

disp("Mixed-array method summary:");
disp(methodSummary);
disp("Separate 10 kohm and 22 kohm group summary:");
disp(groupSummary);
fprintf("Saved mixed-array analysis and discussion to:\n%s\n", resultFolder);

function validateResistanceMatrix(R, label)
if ~isequal(size(R), [8, 8])
    error("Example09:InvalidMatrixSize", ...
        "%s result must be an 8x8 matrix; received %dx%d.", ...
        label, size(R, 1), size(R, 2));
end
if any(~isfinite(R(:))) || any(R(:) <= 0)
    error("Example09:InvalidResistance", ...
        "%s result contains invalid resistance values.", label);
end
end

function T = calculateMethodSummary(method, measuredR, knownR, threshold)
valid = isfinite(measuredR) & isfinite(knownR) & knownR > 0;
errorOhm = measuredR(valid) - knownR(valid);
errorPercent = 100 .* errorOhm ./ knownR(valid);
knownHigh = knownR(valid) > threshold;
measuredHigh = measuredR(valid) > threshold;

T = table(string(method), sum(valid(:)), ...
    mean(errorOhm), mean(abs(errorOhm)), ...
    sqrt(mean(errorOhm .^ 2)), mean(errorPercent), ...
    mean(abs(errorPercent)), max(abs(errorPercent)), ...
    100 .* mean(measuredHigh == knownHigh), ...
    'VariableNames', {'method', 'valid_cells', 'mean_error_ohm', ...
    'mean_absolute_error_ohm', 'rmse_ohm', 'mean_error_percent', ...
    'mean_absolute_error_percent', 'maximum_absolute_error_percent', ...
    'class_location_accuracy_percent'});
end

function T = calculateGroupSummary(method, knownR, measuredValues)
measuredValues = measuredValues(isfinite(measuredValues));
errorOhm = measuredValues - knownR;
errorPercent = 100 .* errorOhm ./ knownR;

T = table(string(method), knownR, numel(measuredValues), ...
    mean(measuredValues), std(measuredValues), mean(errorOhm), ...
    mean(errorPercent), mean(abs(errorPercent)), ...
    max(abs(errorPercent)), ...
    'VariableNames', {'method', 'known_resistance_ohm', 'cell_count', ...
    'mean_measured_resistance_ohm', 'standard_deviation_ohm', ...
    'mean_error_ohm', 'mean_error_percent', ...
    'mean_absolute_error_percent', 'maximum_absolute_error_percent'});
end

function T = makeCellComparisonTable(knownR, vcmR, vhalfR, ...
        vcmErrorPercent, vhalfErrorPercent, threshold)
[row, col] = ndgrid(1:size(knownR, 1), 1:size(knownR, 2));
knownClass = repmat("10k", size(knownR));
knownClass(knownR > threshold) = "22k";
vcmClass = repmat("10k", size(knownR));
vcmClass(vcmR > threshold) = "22k";
vhalfClass = repmat("10k", size(knownR));
vhalfClass(vhalfR > threshold) = "22k";

T = table(row(:), col(:), knownR(:), vcmR(:), vhalfR(:), ...
    vcmErrorPercent(:), vhalfErrorPercent(:), knownClass(:), ...
    vcmClass(:), vhalfClass(:), ...
    'VariableNames', {'row', 'column', 'known_R_ohm', ...
    'vcm_biased_R_ohm', 'vhalf_iterative_R_ohm', ...
    'vcm_error_percent', 'vhalf_error_percent', 'known_class', ...
    'vcm_detected_class', 'vhalf_detected_class'});
end

function plotResistanceComparison(knownR, vcmR, vhalfR, resultFolder)
knownR_kohm = knownR ./ 1e3;
vcmR_kohm = vcmR ./ 1e3;
vhalfR_kohm = vhalfR ./ 1e3;
allValues = [knownR_kohm(:); vcmR_kohm(:); vhalfR_kohm(:)];
limits = [min(allValues), max(allValues)];
padding = 0.03 .* diff(limits);
limits = limits + [-padding, padding];

h = figure('Color', 'w', 'Position', [100, 100, 1350, 430]);
tiledlayout(1, 3, 'Padding', 'compact', 'TileSpacing', 'compact');
plotMap(nexttile, knownR_kohm, "Known mixed array", limits, "kohm");
plotMap(nexttile, vcmR_kohm, "VCM biased measured", limits, "kohm");
plotMap(nexttile, vhalfR_kohm, ...
    "VHALF iterative reconstructed", limits, "kohm");
sgtitle({"Mixed 10 kohm / 22 kohm resistance array"; ...
    "Common color scale for direct visual comparison"}, ...
    'Interpreter', 'none');
exportgraphics(h, fullfile(resultFolder, ...
    "mixed_array_resistance_comparison.png"), 'Resolution', 300);
savefig(h, fullfile(resultFolder, "mixed_array_resistance_comparison.fig"));
end

function plotErrorComparison(vcmError, vhalfError, resultFolder)
maxAbsError = max(abs([vcmError(:); vhalfError(:)]));
limits = [-maxAbsError, maxAbsError];

h = figure('Color', 'w', 'Position', [100, 100, 950, 440]);
tiledlayout(1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
plotMap(nexttile, vcmError, "VCM biased error", limits, "%");
plotMap(nexttile, vhalfError, "VHALF iterative error", limits, "%");
sgtitle({"Error relative to the known mixed-resistance matrix"; ...
    "A common symmetric color scale is used"}, 'Interpreter', 'none');
exportgraphics(h, fullfile(resultFolder, ...
    "mixed_array_error_percent_comparison.png"), 'Resolution', 300);
savefig(h, fullfile(resultFolder, ...
    "mixed_array_error_percent_comparison.fig"));
end

function plotKnownAgainstMeasured(knownR, vcmR, vhalfR, resultFolder)
knownR_kohm = knownR ./ 1e3;
vcmR_kohm = vcmR ./ 1e3;
vhalfR_kohm = vhalfR ./ 1e3;
allValues = [knownR_kohm(:); vcmR_kohm(:); vhalfR_kohm(:)];
limits = [min(allValues), max(allValues)];
padding = 0.05 .* diff(limits);
limits = limits + [-padding, padding];

h = figure('Color', 'w');
plot(limits, limits, 'k--', 'LineWidth', 1.5, ...
    'DisplayName', 'Ideal');
hold on;
scatter(knownR_kohm(:), vcmR_kohm(:), 46, 'filled', ...
    'DisplayName', 'VCM biased');
scatter(knownR_kohm(:), vhalfR_kohm(:), 46, 'filled', ...
    'DisplayName', 'VHALF iterative');
grid on;
axis equal;
xlim(limits);
ylim(limits);
xlabel("Known resistance / kohm");
ylabel("Measured or reconstructed resistance / kohm");
title({"Known against measured resistance"; ...
    "Mixed 10 kohm / 22 kohm array"}, 'Interpreter', 'none');
legend('Location', 'northwest');
exportgraphics(h, fullfile(resultFolder, ...
    "mixed_array_known_vs_measured.png"), 'Resolution', 300);
savefig(h, fullfile(resultFolder, "mixed_array_known_vs_measured.fig"));
end

function plotMap(ax, matrix, mapTitle, limits, colorbarLabel)
imagesc(ax, matrix);
axis(ax, 'image');
set(ax, 'YDir', 'normal');
caxis(ax, limits);
title(ax, mapTitle, 'Interpreter', 'none');
xlabel(ax, "Column");
ylabel(ax, "Row");
xticks(ax, 1:size(matrix, 2));
yticks(ax, 1:size(matrix, 1));
cb = colorbar(ax);
ylabel(cb, colorbarLabel, 'Interpreter', 'none');

for row = 1:size(matrix, 1)
    for col = 1:size(matrix, 2)
        text(ax, col, row, sprintf('%.3g', matrix(row, col)), ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', 'FontSize', 8);
    end
end
end

function writeDiscussion(resultFolder, methodSummary, groupSummary, ...
        highCells, vcmSource, vhalfSource)
filePath = fullfile(resultFolder, "mixed_array_results_discussion.txt");
fid = fopen(filePath, 'w');
if fid < 0
    error("Example09:DiscussionWriteFailed", ...
        "Could not create discussion file: %s", filePath);
end
cleanup = onCleanup(@() fclose(fid));

vcm = methodSummary(methodSummary.method == "VCM biased", :);
vhalf = methodSummary(methodSummary.method == "VHALF iterative", :);
vcm10 = groupSummary(groupSummary.method == "VCM biased" & ...
    groupSummary.known_resistance_ohm == 10e3, :);
vcm22 = groupSummary(groupSummary.method == "VCM biased" & ...
    groupSummary.known_resistance_ohm == 22e3, :);
vhalf10 = groupSummary(groupSummary.method == "VHALF iterative" & ...
    groupSummary.known_resistance_ohm == 10e3, :);
vhalf22 = groupSummary(groupSummary.method == "VHALF iterative" & ...
    groupSummary.known_resistance_ohm == 22e3, :);

fprintf(fid, "MIXED-RESISTANCE ARRAY RESULTS AND DISCUSSION\n\n");
fprintf(fid, "Test board\n");
fprintf(fid, "----------\n");
fprintf(fid, "The reference contains 56 cells at 10 kohm and 8 cells at 22 kohm.\n");
fprintf(fid, "The one-based row/column positions of the 22 kohm cells are:\n");
for k = 1:size(highCells, 1)
    fprintf(fid, "  row %d, column %d\n", highCells(k, 1), highCells(k, 2));
end
fprintf(fid, "\nVCM-biased source:\n%s\n", vcmSource);
fprintf(fid, "\nVHALF iterative source:\n%s\n\n", vhalfSource);

fprintf(fid, "Quantitative result\n");
fprintf(fid, "-------------------\n");
fprintf(fid, "VCM biased: mean absolute error %.3f%%, maximum absolute error %.3f%%, RMSE %.3f ohm.\n", ...
    vcm.mean_absolute_error_percent, ...
    vcm.maximum_absolute_error_percent, vcm.rmse_ohm);
fprintf(fid, "VHALF iterative: mean absolute error %.3f%%, maximum absolute error %.3f%%, RMSE %.3f ohm.\n", ...
    vhalf.mean_absolute_error_percent, ...
    vhalf.maximum_absolute_error_percent, vhalf.rmse_ohm);
fprintf(fid, "Both methods identified %.1f%% and %.1f%% of the 10 kohm/22 kohm locations correctly, respectively.\n\n", ...
    vcm.class_location_accuracy_percent, ...
    vhalf.class_location_accuracy_percent);

fprintf(fid, "Population result\n");
fprintf(fid, "-----------------\n");
fprintf(fid, "VCM biased 10 kohm cells: mean %.3f ohm, mean absolute error %.3f%%.\n", ...
    vcm10.mean_measured_resistance_ohm, vcm10.mean_absolute_error_percent);
fprintf(fid, "VCM biased 22 kohm cells: mean %.3f ohm, mean absolute error %.3f%%.\n", ...
    vcm22.mean_measured_resistance_ohm, vcm22.mean_absolute_error_percent);
fprintf(fid, "VHALF iterative 10 kohm cells: mean %.3f ohm, mean absolute error %.3f%%.\n", ...
    vhalf10.mean_measured_resistance_ohm, vhalf10.mean_absolute_error_percent);
fprintf(fid, "VHALF iterative 22 kohm cells: mean %.3f ohm, mean absolute error %.3f%%.\n\n", ...
    vhalf22.mean_measured_resistance_ohm, vhalf22.mean_absolute_error_percent);

fprintf(fid, "Discussion\n");
fprintf(fid, "----------\n");
fprintf(fid, "The VCM-biased result is largely unaffected by the mixed resistance values. ");
fprintf(fid, "Biasing the inactive lines near VCM suppresses the voltage across many unwanted paths, ");
fprintf(fid, "so each selected-cell measurement remains close to the local cell resistance and the ");
fprintf(fid, "saved channel calibration transfers well from the uniform board.\n\n");

fprintf(fid, "The VHALF iterative reconstruction still preserves the spatial contrast: every 22 kohm ");
fprintf(fid, "cell remains distinguishable from the 10 kohm background. However, its numerical ");
fprintf(fid, "accuracy is worse and the error has a row/column pattern. VHALF measures a coupled ");
fprintf(fid, "network current, then estimates and subtracts sneak conductance using the other cells ");
fprintf(fid, "in the same reconstructed network. When the array is nonuniform, a local resistance ");
fprintf(fid, "change also changes the current redistributed through neighbouring rows and columns. ");
fprintf(fid, "Small model errors in TIA gain/offset, actual VHALF voltage, switch on-resistance, line ");
fprintf(fid, "resistance, and finite TIA virtual-ground accuracy are therefore propagated into several ");
fprintf(fid, "reconstructed cells instead of remaining local.\n\n");

fprintf(fid, "The result should therefore be reported as successful localization and resistance-class ");
fprintf(fid, "separation, but reduced quantitative accuracy for the VHALF method on a heterogeneous ");
fprintf(fid, "array. A scalar 10 kohm reference must not be used for this test because it incorrectly ");
fprintf(fid, "labels the intentional 22 kohm cells as large errors. This analysis uses the full known ");
fprintf(fid, "8x8 resistance matrix for all error calculations.\n\n");

fprintf(fid, "Recommended next calibration step\n");
fprintf(fid, "---------------------------------\n");
fprintf(fid, "Use several heterogeneous reference arrays or several known resistance levels and fit ");
fprintf(fid, "the VHALF residual error against row, column, selected resistance, and column/row total ");
fprintf(fid, "conductance. This tests whether the remaining error is a repeatable model mismatch. ");
fprintf(fid, "Do not hide the error with a single global correction factor because the saved result ");
fprintf(fid, "shows that the drift is channel- and network-state-dependent.\n");
end
