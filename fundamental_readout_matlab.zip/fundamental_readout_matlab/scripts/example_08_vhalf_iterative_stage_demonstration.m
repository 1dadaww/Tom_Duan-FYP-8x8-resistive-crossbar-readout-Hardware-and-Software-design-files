%% Example 08 - Demonstrate VHALF iterative reconstruction stages
%
% Run example_06_vhalf_tia_calibrated_iterative_test.m first.
%
% This script does not access the ESP32. It loads the calibrated VHALF scan
% saved by example 06, replays the same iterative correction equation, and
% records:
%
%   - iteration 0: initial resistance estimate
%   - six stages distributed by percentage of the completed iteration count
%   - the actual final iteration
%
% A total of eight stage images are displayed at approximately:
%   0%, 14%, 29%, 43%, 57%, 71%, 86%, and 100%.
%
% The demonstration is saved in its own example-08 result folder.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% Set this path only when the example-06 MAT file is stored elsewhere.
example06ResultFile = "";
totalSnapshotCount = 8;
showCellText = true;
snapshotsPerPage = 8;

if strlength(string(example06ResultFile)) == 0
    example06ResultFile = findLatestExample06Result(projectRoot);
end
if ~exist(example06ResultFile, 'file')
    error("Example08:MissingExample06Result", ...
        "Example-06 output MAT file was not found. Run example 06 first.\nExpected: %s", ...
        example06ResultFile);
end
validateattributes(totalSnapshotCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 2, '<=', 20});
validateattributes(snapshotsPerPage, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 20});

loaded = load(example06ResultFile);
requiredFields = ["scanVhalfTiaCal", "initialR_ohm", "status", ...
    "maxIterations", "relaxation", "tolerance", ...
    "enforcePositive", "conductanceFloor_s"];
for k = 1:numel(requiredFields)
    if ~isfield(loaded, requiredFields(k))
        error("Example08:MissingSavedVariable", ...
            "Example-06 result does not contain '%s'.", requiredFields(k));
    end
end

scanVhalfTiaCal = loaded.scanVhalfTiaCal;
initialR_ohm = loaded.initialR_ohm;
status = loaded.status;
maxIterations = loaded.maxIterations;
relaxation = loaded.relaxation;
tolerance = loaded.tolerance;
enforcePositive = loaded.enforcePositive;
conductanceFloor_s = loaded.conductanceFloor_s;

numRows = 8;
numCols = 8;
if isfield(loaded, "reconIterative")
    savedRecon = loaded.reconIterative;
else
    savedRecon = struct();
end

alpha = (status.VHALF - status.VCM) ./ status.VREAD;
[Ymeas, validMatrix] = measuredConductanceMatrixLocal( ...
    scanVhalfTiaCal.table, status.VREAD, numRows, numCols);
G = initialConductanceMatrixLocal(initialR_ohm, Ymeas, alpha, ...
    numRows, numCols, conductanceFloor_s);

[Rinitial, ~] = conductanceToResistance(G, validMatrix, ...
    conductanceFloor_s);
allIterationG = cell(maxIterations + 1, 1);
allIterationR = cell(maxIterations + 1, 1);
allIterationG{1} = G;
allIterationR{1} = Rinitial;

historyIteration = nan(maxIterations, 1);
historyMaxChange = nan(maxIterations, 1);
historyMaxResidual = nan(maxIterations, 1);
historyRmsResidual = nan(maxIterations, 1);

finalIteration = 0;
converged = false;
for iter = 1:maxIterations
    Gold = G;
    colSum = localSumOmitNan(G, 1);
    Gtarget = Ymeas - alpha .* (repmat(colSum, numRows, 1) - G);
    updateMask = validMatrix & isfinite(Gtarget);

    G(updateMask) = (1 - relaxation) .* G(updateMask) + ...
        relaxation .* Gtarget(updateMask);
    if enforcePositive
        G(updateMask) = max(G(updateMask), conductanceFloor_s);
    end

    [~, relResidualValues] = residualForModelLocal(G, Ymeas, ...
        alpha, validMatrix);
    changeValues = abs(G(updateMask) - Gold(updateMask)) ./ ...
        max(abs(Gold(updateMask)), conductanceFloor_s);

    maxRelChange = maxFiniteLocal(changeValues);
    maxRelResidual = maxFiniteLocal(relResidualValues);
    rmsRelResidual = rmsFiniteLocal(relResidualValues);
    historyIteration(iter) = iter;
    historyMaxChange(iter) = maxRelChange;
    historyMaxResidual(iter) = maxRelResidual;
    historyRmsResidual(iter) = rmsRelResidual;

    [Rstage, ~] = conductanceToResistance(G, validMatrix, ...
        conductanceFloor_s);
    allIterationG{iter + 1} = G;
    allIterationR{iter + 1} = Rstage;

    finalIteration = iter;
    if isfinite(maxRelResidual) && maxRelResidual <= tolerance
        converged = true;
        break;
    end
    if isfinite(maxRelChange) && maxRelChange <= tolerance
        converged = true;
        break;
    end
end

history = table(historyIteration(1:finalIteration), ...
    historyMaxChange(1:finalIteration), ...
    historyMaxResidual(1:finalIteration), ...
    historyRmsResidual(1:finalIteration), ...
    'VariableNames', {'iteration', 'max_relative_change', ...
    'max_relative_residual', 'rms_relative_residual'});

if finalIteration < totalSnapshotCount - 1
    error("Example08:TooFewIterations", ...
        "The solver completed only %d iterations, so %d distinct stage images cannot be selected.", ...
        finalIteration, totalSnapshotCount);
end

recordedPercentages = linspace(0, 100, totalSnapshotCount).';
recordedIterations = round(recordedPercentages .* finalIteration ./ 100);
recordedIterations(1) = 0;
recordedIterations(end) = finalIteration;
recordedIterations = enforceStrictlyIncreasingIterations( ...
    recordedIterations, finalIteration);
recordedPercentages = 100 .* recordedIterations ./ finalIteration;

snapshotG = allIterationG(recordedIterations + 1);
snapshotR = allIterationR(recordedIterations + 1);
snapshotRStack = cat(3, snapshotR{:});
snapshotGStack = cat(3, snapshotG{:});
finalR_ohm = snapshotRStack(:, :, end);
finalG_s = snapshotGStack(:, :, end);

outputFolder = create_result_folder( ...
    "vhalf_iterative_stage_demonstration_basic");

snapshotSummary = makeSnapshotSummary(recordedIterations, ...
    recordedPercentages, snapshotRStack, snapshotGStack, history, ...
    validMatrix);
write_table_compatible(snapshotSummary, ...
    fullfile(outputFolder, "iteration_stage_summary.csv"));
write_table_compatible(history, ...
    fullfile(outputFolder, "iteration_full_convergence_history.csv"));

for k = 1:numel(recordedIterations)
    iter = recordedIterations(k);
    writematrix(snapshotRStack(:, :, k), ...
        fullfile(outputFolder, sprintf("iteration_%03d_R_ohm.csv", iter)));
    writematrix(snapshotGStack(:, :, k), ...
        fullfile(outputFolder, sprintf("iteration_%03d_G_selected_s.csv", iter)));
end

finiteR = snapshotRStack(isfinite(snapshotRStack) & snapshotRStack > 0);
if isempty(finiteR)
    commonLogLimits = [];
    commonLinearLimits = [];
    resistanceScaleExponent = 0;
else
    commonLogLimits = [min(log10(finiteR)), max(log10(finiteR))];
    % Use one report-friendly resistance unit for every stage. For example,
    % an exponent of 5 displays 98483 ohm as 0.985 with a shared x10^5 ohm
    % multiplier instead of repeating scientific notation in every cell.
    resistanceScaleExponent = round(log10(median(finiteR)));
    resistanceScale = 10 .^ resistanceScaleExponent;
    commonLinearLimits = [min(finiteR), max(finiteR)] ./ resistanceScale;
    if commonLogLimits(1) == commonLogLimits(2)
        commonLogLimits = commonLogLimits + [-0.5, 0.5];
    end
    if commonLinearLimits(1) == commonLinearLimits(2)
        padding = max(0.05, abs(commonLinearLimits(1)) * 0.05);
        commonLinearLimits = commonLinearLimits + [-padding, padding];
    end
end

createSnapshotPages(snapshotRStack, recordedIterations, ...
    recordedPercentages, outputFolder, ...
    snapshotsPerPage, commonLogLimits, true, showCellText, ...
    resistanceScaleExponent);
createSnapshotPages(snapshotRStack, recordedIterations, ...
    recordedPercentages, outputFolder, ...
    snapshotsPerPage, commonLinearLimits, false, showCellText, ...
    resistanceScaleExponent);
createConvergencePlot(history, recordedIterations, outputFolder);
createSelectedCellTrajectoryPlot(snapshotRStack, recordedIterations, ...
    validMatrix, outputFolder);

maxFinalDifferenceOhm = nan;
rmsFinalDifferenceOhm = nan;
if isfield(savedRecon, "R_ohm")
    difference = finalR_ohm - savedRecon.R_ohm;
    validDifference = isfinite(difference);
    if any(validDifference(:))
        maxFinalDifferenceOhm = max(abs(difference(validDifference)));
        rmsFinalDifferenceOhm = sqrt(mean(difference(validDifference).^2));
    end
    writematrix(difference, ...
        fullfile(outputFolder, "replayed_minus_saved_final_R_ohm.csv"));
end

save(fullfile(outputFolder, "iteration_stage_demonstration_outputs.mat"), ...
    "example06ResultFile", "scanVhalfTiaCal", "initialR_ohm", ...
    "status", "alpha", "maxIterations", "relaxation", "tolerance", ...
    "enforcePositive", "conductanceFloor_s", "Ymeas", "validMatrix", ...
    "totalSnapshotCount", "recordedIterations", ...
    "recordedPercentages", "snapshotRStack", "snapshotGStack", ...
    "snapshotSummary", "history", "finalIteration", "converged", ...
    "finalR_ohm", "finalG_s", "savedRecon", ...
    "maxFinalDifferenceOhm", "rmsFinalDifferenceOhm", ...
    "commonLogLimits", "commonLinearLimits", ...
    "resistanceScaleExponent");

disp("Recorded iterative stages:");
disp(snapshotSummary);
fprintf("Example-06 source:\n%s\n", example06ResultFile);
fprintf("Half-select factor alpha = %.9g\n", alpha);
fprintf("Replay converged: %d after %d iteration(s)\n", ...
    converged, finalIteration);
if isfinite(maxFinalDifferenceOhm)
    fprintf("Maximum difference from example-06 saved final matrix: %.9g ohm\n", ...
        maxFinalDifferenceOhm);
    fprintf("RMS difference from example-06 saved final matrix: %.9g ohm\n", ...
        rmsFinalDifferenceOhm);
end
fprintf("Saved iteration-stage demonstration to:\n%s\n", outputFolder);

function resultFile = findLatestExample06Result(projectRoot)
resultsRoot = fullfile(projectRoot, "results");
preferred = fullfile(resultsRoot, ...
    "latest_vhalf_auto_tia_calibrated_iterative_basic", ...
    "vhalf_tia_calibrated_iterative_outputs.mat");
if exist(preferred, 'file')
    resultFile = preferred;
    return;
end

matches = dir(fullfile(resultsRoot, "**", ...
    "vhalf_tia_calibrated_iterative_outputs.mat"));
if isempty(matches)
    resultFile = preferred;
    return;
end

[~, newest] = max([matches.datenum]);
resultFile = fullfile(matches(newest).folder, matches(newest).name);
end

function [Y, valid] = measuredConductanceMatrixLocal(T, vread, numRows, numCols)
vars = string(T.Properties.VariableNames);
if ismember("current_a", vars)
    Ivec = abs(T.current_a);
elseif all(ismember(["vadc_v", "rf_ohm"], vars))
    Ivec = abs(T.vadc_v ./ T.rf_ohm);
else
    error("Example08:MissingCurrent", ...
        "The saved calibrated scan must contain current_a or vadc_v/rf_ohm.");
end

validStatuses = ["OK", "LOW_SIGNAL", "HIGH_SIGNAL", ...
    "MIN_RF_LIMIT", "MAX_RF_LIMIT"];
validStatus = ismember(string(T.status), validStatuses);
Y = nan(numRows, numCols);
valid = false(numRows, numCols);

for k = 1:height(T)
    r = T.row(k);
    c = T.col(k);
    if r < 1 || r > numRows || c < 1 || c > numCols
        continue;
    end
    if validStatus(k) && isfinite(Ivec(k)) && Ivec(k) > 0 && vread > 0
        Y(r, c) = Ivec(k) ./ vread;
        valid(r, c) = true;
    end
end
end

function G = initialConductanceMatrixLocal(initialR, Y, alpha, ...
        numRows, numCols, floorS)
if isstruct(initialR) && isfield(initialR, "R_ohm")
    initialR = initialR.R_ohm;
elseif isstruct(initialR) && isfield(initialR, "matrices") && ...
        isfield(initialR.matrices, "R_ohm")
    initialR = initialR.matrices.R_ohm;
end
if ~isnumeric(initialR) || ~isequal(size(initialR), [numRows, numCols])
    error("Example08:InvalidInitialResistance", ...
        "The saved initialR_ohm must be an %dx%d numeric matrix.", ...
        numRows, numCols);
end

G = 1 ./ initialR;
G(~isfinite(G) | G <= 0) = nan;
fallback = Y ./ max(1 + alpha .* (numRows - 1), eps);
missing = ~isfinite(G) | G <= 0;
G(missing) = fallback(missing);
G(~isfinite(G) | G <= 0) = floorS;
end

function [R, valid] = conductanceToResistance(G, validMatrix, floorS)
R = nan(size(G));
valid = validMatrix & isfinite(G) & G > floorS;
R(valid) = 1 ./ G(valid);
end

function [residual, relValues] = residualForModelLocal(G, Y, alpha, valid)
colSum = localSumOmitNan(G, 1);
Ypred = G + alpha .* (repmat(colSum, size(G, 1), 1) - G);
residual = Ypred - Y;
relative = abs(residual) ./ max(abs(Y), eps);
relValues = relative(valid & isfinite(relative));
end

function summary = makeSnapshotSummary(iterations, percentages, ...
        Rstack, Gstack, history, valid)
numStages = numel(iterations);
mean_R_ohm = nan(numStages, 1);
std_R_ohm = nan(numStages, 1);
min_R_ohm = nan(numStages, 1);
max_R_ohm = nan(numStages, 1);
mean_G_s = nan(numStages, 1);
max_relative_change = nan(numStages, 1);
max_relative_residual = nan(numStages, 1);
rms_relative_residual = nan(numStages, 1);

for k = 1:numStages
    R = Rstack(:, :, k);
    G = Gstack(:, :, k);
    Rvalues = R(valid & isfinite(R));
    Gvalues = G(valid & isfinite(G));
    if ~isempty(Rvalues)
        mean_R_ohm(k) = mean(Rvalues);
        std_R_ohm(k) = std(Rvalues);
        min_R_ohm(k) = min(Rvalues);
        max_R_ohm(k) = max(Rvalues);
    end
    if ~isempty(Gvalues)
        mean_G_s(k) = mean(Gvalues);
    end
    if iterations(k) > 0
        row = history(history.iteration == iterations(k), :);
        if ~isempty(row)
            max_relative_change(k) = row.max_relative_change(1);
            max_relative_residual(k) = row.max_relative_residual(1);
            rms_relative_residual(k) = row.rms_relative_residual(1);
        end
    end
end

iteration = iterations(:);
percent_of_completed_iterations = percentages(:);
stage = strings(numStages, 1);
stage(:) = "percentage_stage";
stage(iteration == 0) = "initial";
stage(end) = "final";

summary = table(iteration, percent_of_completed_iterations, stage, ...
    mean_R_ohm, std_R_ohm, ...
    min_R_ohm, max_R_ohm, mean_G_s, max_relative_change, ...
    max_relative_residual, rms_relative_residual);
end

function createSnapshotPages(Rstack, iterations, percentages, outputFolder, ...
        perPage, commonLimits, useLogScale, showCellText, scaleExponent)
numStages = numel(iterations);
numPages = ceil(numStages ./ perPage);
resistanceScale = 10 .^ scaleExponent;
scaleLabel = sprintf('\\times10^{%d} \\Omega', scaleExponent);

for page = 1:numPages
    first = (page - 1) * perPage + 1;
    last = min(page * perPage, numStages);
    count = last - first + 1;
    numColumns = min(4, count);
    numRows = ceil(count ./ numColumns);

    h = figure('Color', 'w', 'Position', [50 50 1500 900]);
    layout = tiledlayout(numRows, numColumns, ...
        'TileSpacing', 'compact', 'Padding', 'compact');

    for k = first:last
        ax = nexttile(layout);
        ax.Toolbar.Visible = 'off';
        R = Rstack(:, :, k);
        if useLogScale
            displayed = log10(R);
        else
            displayed = R ./ resistanceScale;
        end
        imagesc(ax, displayed);
        axis(ax, 'image');
        set(ax, 'YDir', 'normal');
        xticks(ax, 1:8);
        yticks(ax, 1:8);
        xlabel(ax, "Column");
        ylabel(ax, "Row");
        title(ax, stageTitle(iterations(k), percentages(k), iterations(end)), ...
            'Interpreter', 'none');
        if ~isempty(commonLimits)
            clim(ax, commonLimits);
        end

        if showCellText
            for r = 1:8
                for c = 1:8
                    if isfinite(R(r, c))
                        text(ax, c, r, sprintf('%.3g', ...
                            R(r, c) ./ resistanceScale), ...
                            'HorizontalAlignment', 'center', ...
                            'VerticalAlignment', 'middle', ...
                            'FontSize', 6);
                    end
                end
            end
        end
    end

    cb = colorbar;
    cb.Layout.Tile = 'east';
    if useLogScale
        ylabel(cb, "log10(ohm)");
        title(layout, "log10 resistance" + newline + ...
            "Grid labels use " + scaleLabel + newline + " ", ...
            'Interpreter', 'tex');
        baseName = sprintf("iteration_stage_log10_page_%02d", page);
    else
        ylabel(cb, scaleLabel, 'Interpreter', 'tex');
        title(layout, " Resistance" + newline + ...
            " Common color scale and grid unit: " + scaleLabel + ...
            newline + " ", ...
            'Interpreter', 'tex');
        baseName = sprintf("iteration_stage_decimal_page_%02d", page);
    end

    exportgraphics(h, fullfile(outputFolder, baseName + ".png"), ...
        'Resolution', 300);
    savefig(h, fullfile(outputFolder, baseName + ".fig"));
end
end

function titleText = stageTitle(iteration, percentage, finalIteration)
if iteration == 0
    titleText = "Initial estimate: 0% (iteration 0)";
elseif iteration == finalIteration
    titleText = "Final: 100% (iteration " + string(iteration) + ")";
else
    titleText = sprintf('%.1f%% (iteration %d)', percentage, iteration);
end
end

function iterations = enforceStrictlyIncreasingIterations(iterations, finalIteration)
iterations = round(iterations(:));
iterations(1) = 0;
iterations(end) = finalIteration;

for k = 2:numel(iterations)-1
    iterations(k) = max(iterations(k), iterations(k-1) + 1);
end
for k = numel(iterations)-1:-1:2
    iterations(k) = min(iterations(k), iterations(k+1) - 1);
end
end

function createConvergencePlot(history, recordedIterations, outputFolder)
h = figure('Color', 'w');
ax = axes(h);
ax.Toolbar.Visible = 'off';
semilogy(history.iteration, history.max_relative_change, ...
    'LineWidth', 1.5, 'DisplayName', 'Maximum relative change');
hold on;
semilogy(history.iteration, history.max_relative_residual, ...
    'LineWidth', 1.5, 'DisplayName', 'Maximum relative residual');
semilogy(history.iteration, history.rms_relative_residual, ...
    'LineWidth', 1.5, 'DisplayName', 'RMS relative residual');

snapshotRows = ismember(history.iteration, recordedIterations);
scatter(history.iteration(snapshotRows), ...
    history.max_relative_residual(snapshotRows), 28, 'filled', ...
    'DisplayName', 'Displayed stages');

grid on;
xlabel("Iteration");
ylabel("Relative value");
title("VHALF iterative reconstruction convergence");
legend('Location', 'best');
exportgraphics(h, fullfile(outputFolder, ...
    "iteration_convergence_with_displayed_stages.png"), 'Resolution', 300);
savefig(h, fullfile(outputFolder, ...
    "iteration_convergence_with_displayed_stages.fig"));
end

function createSelectedCellTrajectoryPlot(Rstack, iterations, valid, outputFolder)
h = figure('Color', 'w');
ax = axes(h);
ax.Toolbar.Visible = 'off';
hold on;
for r = 1:size(Rstack, 1)
    for c = 1:size(Rstack, 2)
        if valid(r, c)
            values = squeeze(Rstack(r, c, :));
            plot(iterations, values, 'LineWidth', 0.75, ...
                'HandleVisibility', 'off');
        end
    end
end

meanTrajectory = nan(numel(iterations), 1);
for k = 1:numel(iterations)
    R = Rstack(:, :, k);
    values = R(valid & isfinite(R));
    meanTrajectory(k) = mean(values, "omitnan");
end
plot(iterations, meanTrajectory, 'k-o', 'LineWidth', 2, ...
    'MarkerSize', 4, 'DisplayName', 'Array mean');

grid on;
xlabel("Iteration");
ylabel("Reconstructed resistance / ohm");
title("Selected-cell resistance progression across displayed stages");
legend('Location', 'best');
exportgraphics(h, fullfile(outputFolder, ...
    "iteration_selected_cell_resistance_trajectories.png"), ...
    'Resolution', 300);
savefig(h, fullfile(outputFolder, ...
    "iteration_selected_cell_resistance_trajectories.fig"));
end

function s = localSumOmitNan(x, dim)
if nargin < 2
    dim = 1;
end
x(~isfinite(x)) = 0;
s = sum(x, dim);
end

function out = maxFiniteLocal(x)
x = x(isfinite(x));
if isempty(x)
    out = nan;
else
    out = max(abs(x));
end
end

function out = rmsFiniteLocal(x)
x = x(isfinite(x));
if isempty(x)
    out = nan;
else
    out = sqrt(mean(x.^2));
end
end
