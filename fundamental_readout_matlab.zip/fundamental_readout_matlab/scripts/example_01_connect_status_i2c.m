%% Example 01 - Connect, STATUS, I2CSCAN
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
packetAverageCount = 1;
defaultRF = "10k";

dev = BasicArrayReader(portName, 115200);
dev.connect();
cleanupObj = onCleanup(@() dev.disconnect());

dev.restoreDefaultReadoutState(packetAverageCount, defaultRF);
fprintf("Default readout state: VCM %.2f V, VSEL %.2f V, VREAD %.2f V, RF %s, ESP avg %d.\n", ...
    dev.DefaultReadoutVCM, dev.DefaultReadoutVSEL, ...
    dev.DefaultReadoutVSEL - dev.DefaultReadoutVCM, defaultRF, packetAverageCount);

status = dev.getStatus();
disp("STATUS:");
disp(status);

i2c = dev.i2cScan();
disp("I2C expected-address check:");
disp(i2c.expectedFound);

rf = dev.getRFStatus();
disp("RF status:");
disp(rf);
