%% Example 05 - Explore iterative VHALF reconstruction from example 06
%
% Run example_06_vhalf_tia_calibrated_iterative_test.m first.
%
% This example does not read the ESP32 again. It loads only the TIA/channel
% calibrated apparent VHALF resistance from example 06. The solver input
% current is reconstructed from that resistance:
%
%   I_calibrated = VREAD ./ R_calibrated_apparent
%
% It then applies the iterative same-column sneak-current correction for
% reconstruction analysis.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
% Leave empty to use the most recent example-06 TIA-calibrated output.
sourceMatPath = "";

% Initial guess options:
%   "apparent" = start from calibrated apparent VHALF resistance.
%   "uniform"  = start from uniformInitialR_ohm everywhere.
initialGuessSource = "apparent";
uniformInitialR_ohm = 100000;

maxIterations = 3000;
relaxation = 0.20;
tolerance = 1e-7;
enforcePositive = true;
conductanceFloor_s = 1e-12;

% Relaxation sweep for algorithm investigation and report plots.
relaxationSweepValues = [0.05, 0.10, 0.20, 0.40, 0.60, 0.80, 1.00];

resultFolder = create_result_folder( ...
    "vhalf_iterative_from_example06_resistance_basic");

if strlength(string(sourceMatPath)) == 0
    sourceMatPath = findLatestExample06Output(projectRoot);
end
loaded = load(sourceMatPath);

requiredVars = ["vhalfTiaCal", "status"];
for k = 1:numel(requiredVars)
    if ~isfield(loaded, requiredVars(k))
        error("Example05:MissingSavedVariable", ...
            "Saved example-06 file does not contain '%s'.", requiredVars(k));
    end
end

calibratedApparentR_ohm = ...
    loaded.vhalfTiaCal.matrices.R_readout_calibrated_ohm;
scanFromCalibratedResistance = makeScanFromCalibratedResistance( ...
    loaded.vhalfTiaCal.table, calibratedApparentR_ohm, loaded.status.VREAD);

initialR_ohm = chooseInitialResistance(calibratedApparentR_ohm, ...
    initialGuessSource, ...
    uniformInitialR_ohm);

fprintf("Loaded saved example-06 TIA-calibrated VHALF result:\n%s\n", sourceMatPath);
fprintf("Iterative input is rebuilt only from calibrated apparent resistance using I = VREAD / R.\n");
fprintf("Initial guess source: %s\n", initialGuessSource);
fprintf("Iterative settings: maxIterations=%d, relaxation=%.3g, tolerance=%.3g\n", ...
    maxIterations, relaxation, tolerance);

reconIterative = reconstruct_vhalf_iterative(scanFromCalibratedResistance, ...
    "Vread", loaded.status.VREAD, ...
    "Vcm", loaded.status.VCM, ...
    "Vhalf", loaded.status.VHALF, ...
    "initialR_ohm", initialR_ohm, ...
    "maxIterations", maxIterations, ...
    "relaxation", relaxation, ...
    "tolerance", tolerance, ...
    "enforcePositive", enforcePositive, ...
    "conductanceFloor_s", conductanceFloor_s, ...
    "numRows", 8, ...
    "numCols", 8);

write_table_compatible(reconIterative.table, ...
    fullfile(resultFolder, "vhalf_iterative_reconstructed_table.csv"));
write_table_compatible(reconIterative.history, ...
    fullfile(resultFolder, "vhalf_iterative_convergence_history.csv"));
write_table_compatible(scanFromCalibratedResistance.table, ...
    fullfile(resultFolder, ...
    "example06_calibrated_resistance_rebuilt_solver_input.csv"));

writematrix(calibratedApparentR_ohm, ...
    fullfile(resultFolder, ...
    "example06_input_calibrated_apparent_R_ohm.csv"));
writematrix(reconIterative.R_ohm, ...
    fullfile(resultFolder, "vhalf_iterative_reconstructed_R_ohm.csv"));
writematrix(reconIterative.G_selected_s, ...
    fullfile(resultFolder, "vhalf_iterative_selected_G_s.csv"));
writematrix(reconIterative.G_sneak_est_s, ...
    fullfile(resultFolder, "vhalf_iterative_estimated_sneak_G_s.csv"));
writematrix(reconIterative.G_total_measured_s, ...
    fullfile(resultFolder, "vhalf_iterative_measured_total_G_s.csv"));
writematrix(reconIterative.G_predicted_total_s, ...
    fullfile(resultFolder, "vhalf_iterative_predicted_total_G_s.csv"));
writematrix(reconIterative.G_residual_s, ...
    fullfile(resultFolder, "vhalf_iterative_residual_G_s.csv"));
writematrix(reconIterative.closedForm.R_ohm, ...
    fullfile(resultFolder, "vhalf_closed_form_reference_R_ohm.csv"));

plot_matrix_heatmap(reconIterative.R_ohm, ...
    "VHALF mode iterative correction resistance / ohm", ...
    fullfile(resultFolder, "vhalf_iterative_reconstructed_R_map.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(reconIterative.R_ohm, ...
    "VHALF mode iterative correction decimal resistance / ohm", ...
    fullfile(resultFolder, "vhalf_iterative_reconstructed_R_map_decimal.png"), ...
    "logScale", false, "colorbarLabel", "ohm", "showText", true);
plot_matrix_heatmap(abs(reconIterative.G_residual_s), ...
    "VHALF mode iterative correction absolute residual / S", ...
    fullfile(resultFolder, "vhalf_iterative_abs_residual_G_map.png"), ...
    "logScale", false, "colorbarLabel", "S");

iterativeMinusClosedPercent = 100 .* ...
    (reconIterative.R_ohm - reconIterative.closedForm.R_ohm) ./ ...
    reconIterative.closedForm.R_ohm;
writematrix(iterativeMinusClosedPercent, ...
    fullfile(resultFolder, "vhalf_iterative_minus_closed_form_percent.csv"));

knownArrayOhmForError = [];
if isfield(loaded, "knownSelectedCellOhmForError") && ...
        ~isempty(loaded.knownSelectedCellOhmForError) && ...
        isfinite(loaded.knownSelectedCellOhmForError)
    knownArrayOhmForError = loaded.knownSelectedCellOhmForError;
    iterativeErrorPercent = 100 .* ...
        (reconIterative.R_ohm - knownArrayOhmForError) ./ knownArrayOhmForError;
    writematrix(iterativeErrorPercent, ...
        fullfile(resultFolder, "vhalf_iterative_error_percent_vs_known.csv"));
    plot_matrix_heatmap(iterativeErrorPercent, ...
        "VHALF mode iterative correction error vs known / %", ...
        fullfile(resultFolder, "vhalf_iterative_error_percent_heatmap.png"), ...
        "logScale", false, "colorbarLabel", "%", "showText", true);
end

fprintf("Running relaxation sweep: %s\n", ...
    mat2str(relaxationSweepValues));
relaxationSweepTable = runRelaxationStudy( ...
    scanFromCalibratedResistance, loaded.status, initialR_ohm, ...
    relaxationSweepValues, maxIterations, tolerance, ...
    enforcePositive, conductanceFloor_s, knownArrayOhmForError);
write_table_compatible(relaxationSweepTable, ...
    fullfile(resultFolder, "vhalf_iterative_relaxation_sweep.csv"));
createRelaxationSweepFigure(relaxationSweepTable, ...
    ~isempty(knownArrayOhmForError), resultFolder);

save(fullfile(resultFolder, "vhalf_iterative_reconstruction_outputs.mat"), ...
    "reconIterative", "sourceMatPath", "initialGuessSource", ...
    "calibratedApparentR_ohm", "scanFromCalibratedResistance", ...
    "initialR_ohm", "uniformInitialR_ohm", "maxIterations", ...
    "relaxation", "tolerance", "enforcePositive", "conductanceFloor_s", ...
    "relaxationSweepValues", "relaxationSweepTable", ...
    "knownArrayOhmForError");

disp("Iterative convergence summary:");
disp(reconIterative.history(end, :));
fprintf("Converged: %d after %d iteration(s)\n", ...
    reconIterative.converged, reconIterative.iterationsUsed);
fprintf("Saved iterative VHALF reconstruction outputs to:\n%s\n", resultFolder);

function sweepTable = runRelaxationStudy(scanInput, status, initialR, ...
        relaxationValues, maxIterations, tolerance, enforcePositive, ...
        conductanceFloor_s, knownR)
relaxationValues = unique(double(relaxationValues(:)));
if isempty(relaxationValues) || any(~isfinite(relaxationValues)) || ...
        any(relaxationValues <= 0) || any(relaxationValues > 1)
    error("Example05:InvalidRelaxationSweep", ...
        "relaxationSweepValues must contain values in the interval (0, 1].");
end

numTests = numel(relaxationValues);
converged = false(numTests, 1);
iterations_used = nan(numTests, 1);
final_max_relative_change = nan(numTests, 1);
final_max_relative_residual = nan(numTests, 1);
final_rms_relative_residual = nan(numTests, 1);
rmse_vs_closed_form_percent = nan(numTests, 1);
mean_abs_error_vs_known_percent = nan(numTests, 1);
rmse_error_vs_known_percent = nan(numTests, 1);
max_abs_error_vs_known_percent = nan(numTests, 1);

for k = 1:numTests
    recon = reconstruct_vhalf_iterative(scanInput, ...
        "Vread", status.VREAD, ...
        "Vcm", status.VCM, ...
        "Vhalf", status.VHALF, ...
        "initialR_ohm", initialR, ...
        "maxIterations", maxIterations, ...
        "relaxation", relaxationValues(k), ...
        "tolerance", tolerance, ...
        "enforcePositive", enforcePositive, ...
        "conductanceFloor_s", conductanceFloor_s, ...
        "numRows", 8, ...
        "numCols", 8);

    finalHistory = recon.history(end, :);
    converged(k) = recon.converged;
    iterations_used(k) = recon.iterationsUsed;
    final_max_relative_change(k) = finalHistory.max_relative_change;
    final_max_relative_residual(k) = finalHistory.max_relative_residual;
    final_rms_relative_residual(k) = finalHistory.rms_relative_residual;

    closedPercent = 100 .* ...
        (recon.R_ohm - recon.closedForm.R_ohm) ./ ...
        recon.closedForm.R_ohm;
    closedValues = closedPercent(isfinite(closedPercent));
    if ~isempty(closedValues)
        rmse_vs_closed_form_percent(k) = ...
            sqrt(mean(closedValues.^2));
    end

    if ~isempty(knownR)
        knownPercent = 100 .* (recon.R_ohm - knownR) ./ knownR;
        knownValues = knownPercent(isfinite(knownPercent));
        if ~isempty(knownValues)
            mean_abs_error_vs_known_percent(k) = ...
                mean(abs(knownValues));
            rmse_error_vs_known_percent(k) = ...
                sqrt(mean(knownValues.^2));
            max_abs_error_vs_known_percent(k) = ...
                max(abs(knownValues));
        end
    end

    fprintf("  relaxation %.3g | converged %d | iterations %d | final max residual %.6g\n", ...
        relaxationValues(k), converged(k), iterations_used(k), ...
        final_max_relative_residual(k));
end

relaxation = relaxationValues;
sweepTable = table(relaxation, converged, iterations_used, ...
    final_max_relative_change, final_max_relative_residual, ...
    final_rms_relative_residual, rmse_vs_closed_form_percent, ...
    mean_abs_error_vs_known_percent, rmse_error_vs_known_percent, ...
    max_abs_error_vs_known_percent);
end

function createRelaxationSweepFigure(T, hasKnownResistance, resultFolder)
h = figure('Color', 'w', 'Position', [80 80 1250 760]);
layout = tiledlayout(2, 2, 'TileSpacing', 'compact', ...
    'Padding', 'compact');

ax1 = nexttile(layout);
ax1.Toolbar.Visible = 'off';
plot(ax1, T.relaxation, T.iterations_used, '-o', ...
    'LineWidth', 1.6, 'MarkerSize', 6);
grid(ax1, 'on');
xlabel(ax1, "Relaxation");
ylabel(ax1, "Iterations used");
title(ax1, "Convergence speed");

ax2 = nexttile(layout);
ax2.Toolbar.Visible = 'off';
semilogy(ax2, T.relaxation, T.final_max_relative_residual, ...
    '-o', 'LineWidth', 1.6, 'MarkerSize', 6);
hold(ax2, 'on');
semilogy(ax2, T.relaxation, T.final_rms_relative_residual, ...
    '-s', 'LineWidth', 1.6, 'MarkerSize', 6);
grid(ax2, 'on');
xlabel(ax2, "Relaxation");
ylabel(ax2, "Final relative residual");
title(ax2, "Final model residual");
legend(ax2, ["Maximum", "RMS"], 'Location', 'best');

ax3 = nexttile(layout);
ax3.Toolbar.Visible = 'off';
if hasKnownResistance
    plot(ax3, T.relaxation, T.rmse_error_vs_known_percent, ...
        '-o', 'LineWidth', 1.6, 'MarkerSize', 6);
    hold(ax3, 'on');
    plot(ax3, T.relaxation, T.mean_abs_error_vs_known_percent, ...
        '-s', 'LineWidth', 1.6, 'MarkerSize', 6);
    ylabel(ax3, "Error vs known / %");
    title(ax3, "Final reconstruction accuracy");
    legend(ax3, ["RMSE", "Mean absolute error"], ...
        'Location', 'best');
else
    plot(ax3, T.relaxation, T.rmse_vs_closed_form_percent, ...
        '-o', 'LineWidth', 1.6, 'MarkerSize', 6);
    ylabel(ax3, "RMSE vs closed form / %");
    title(ax3, "Final iterative agreement");
end
grid(ax3, 'on');
xlabel(ax3, "Relaxation");

ax4 = nexttile(layout);
ax4.Toolbar.Visible = 'off';
stem(ax4, T.relaxation, double(T.converged), 'filled', ...
    'LineWidth', 1.4);
grid(ax4, 'on');
xlabel(ax4, "Relaxation");
ylabel(ax4, "Converged");
yticks(ax4, [0 1]);
ylim(ax4, [-0.1 1.1]);
title(ax4, "Convergence success");

title(layout, "VHALF mode iterative correction relaxation sweep");
outputBase = fullfile(resultFolder, ...
    "vhalf_iterative_relaxation_sweep");
exportgraphics(h, outputBase + ".png", 'Resolution', 300);
savefig(h, outputBase + ".fig");
end

function sourceMatPath = findLatestExample06Output(projectRoot)
files = dir(fullfile(projectRoot, "results", "**", ...
    "vhalf_tia_calibrated_iterative_outputs.mat"));
if isempty(files)
    error("Example05:MissingExample06Result", ...
        "No saved example-06 output found. Run example_06_vhalf_tia_calibrated_iterative_test.m first.");
end
[~, idx] = max([files.datenum]);
sourceMatPath = fullfile(files(idx).folder, files(idx).name);
end

function initialR = chooseInitialResistance(calibratedR, initialGuessSource, uniformInitialR)
initialGuessSource = lower(string(initialGuessSource));
switch initialGuessSource
    case "apparent"
        if ~isnumeric(calibratedR) || ~isequal(size(calibratedR), [8 8])
            error("Example05:MissingApparent", ...
                "Example-06 calibrated apparent resistance must be an 8x8 matrix.");
        end
        initialR = calibratedR;
    case "uniform"
        validateattributes(uniformInitialR, {'numeric'}, ...
            {'scalar', 'real', 'finite', 'positive'});
        initialR = uniformInitialR .* ones(8, 8);
    otherwise
        error("Example05:InvalidInitialGuess", ...
            "initialGuessSource must be apparent or uniform.");
end
end

function scan = makeScanFromCalibratedResistance(calibratedTable, Rmatrix, Vread)
if ~istable(calibratedTable)
    error("Example05:InvalidCalibrationTable", ...
        "Example-06 vhalfTiaCal.table must be a table.");
end
if ~isequal(size(Rmatrix), [8 8])
    error("Example05:InvalidResistanceMatrix", ...
        "Example-06 calibrated apparent resistance must be 8x8.");
end
validateattributes(Vread, {'numeric'}, ...
    {'scalar', 'real', 'finite', 'positive'});

T = calibratedTable;
T.example06_saved_current_a = T.current_a;
T.example06_saved_calibrated_current_a = ...
    T.current_readout_calibrated_a;
T.example06_saved_calibrated_R_ohm = ...
    T.r_readout_calibrated_ohm;

Rvec = nan(height(T), 1);
for k = 1:height(T)
    r = T.row(k);
    c = T.col(k);
    if r >= 1 && r <= 8 && c >= 1 && c <= 8
        Rvec(k) = Rmatrix(r, c);
    end
end

IfromR = Vread ./ Rvec;
IfromR(~isfinite(IfromR) | IfromR <= 0) = nan;
T.r_ohm = Rvec;
T.current_a = IfromR;
T.vadc_v = IfromR .* T.rf_ohm;
T.iterative_input_source = repmat( ...
    "example06 calibrated apparent resistance; current rebuilt as VREAD/R", ...
    height(T), 1);

scan = struct();
scan.table = T;
scan.matrices = BasicArrayReader.tableToMatrices(T, 8, 8);
scan.matrices.R_ohm = Rmatrix;
scan.matrices.current_a = Vread ./ Rmatrix;
scan.mode = "VHALF";
scan.autoRF = false;
scan.timestamp = datetime("now");
scan.header = struct("mode", ...
    "VHALF_EXAMPLE06_CALIBRATED_RESISTANCE_INPUT", ...
    "numRows", 8, "numCols", 8, "VREAD", Vread, ...
    "source", ...
    "example06 calibrated apparent resistance; current rebuilt as VREAD/R");
end
