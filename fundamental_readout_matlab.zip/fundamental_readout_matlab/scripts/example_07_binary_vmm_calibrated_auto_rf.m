%% Example 07 - Conservative calibrated binary VMM with MATLAB auto-RF
%
% Firmware VMM switching commands:
%
%   SETBIAS <VSEL> <VCM>
%   VMMBIN <8_bit_binary_string>
%
% MATLAB controls the readout RF range using the following sequence:
%
%   1. Reset VMM bias and RF before each binary vector.
%   2. Discard priming VMM reads.
%   3. Estimate each output channel's ADC voltage as abs(I_col) * RF_col.
%   4. If a column is too low, increase only that column's RF.
%      If a column is too high, decrease only that column's RF.
%   5. Re-send the VMM command until the vector is inside the voltage window
%      and, optionally, stable on two consecutive reads.
%
% The accepted VMM currents are calibrated with the fundamental multi-RF
% channel/RF model from example 03, then compared against the ideal VMM
% output from the manually defined 8x8 resistance matrix below.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
baudRate = 115200;

packetAverageCount = 1;   % ESP32-side ADC frames averaged per VMM packet
averageCount = 1;         % MATLAB-side final average after RF is selected

% Firmware VMM command order is SETBIAS <VSEL> <VCM>.
vcm = 1.65;
vsel = 1.75;

% MATLAB-side VMM auto-RF settings.
autoRangeStartRF = "100k";
rfNameLadder = ["100", "1k", "10k", "100k", "1M"];
autoLowLimitV = 0.08;
autoHighLimitV = 0.8;
maxVmmAttempts = 12;
retryPause_s = 0.05;
vectorSettle_s = 0.10;
firstVectorSettle_s = 1.0;
primeDiscardCount = 1;
firstVectorPrimeDiscardCount = 2;
requireStablePair = true;
stableRelTol = 0.03;
vmmTimeout_s = 10;

% Ideal/reference matrix used for comparison.
%
% "manual"  : use the 8x8 matrix typed below.
% "uniform" : use knownResistanceOhm * ones(8, 8).
% "csv"     : load an 8x8 resistance matrix from knownResistanceMapCsv.
referenceMatrixSource = "uniform";
knownResistanceOhm = 100e3;
knownResistanceMapCsv = "";
R_expected_manual_ohm = 100e3 * ones(8, 8);

% Fundamental TIA/channel calibration from example 03. For auto-RF, calibrate
% every RF range that this script might choose, otherwise those channels will
% be NaN after calibration.
calibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_multi_rf_delta_v_calibration.mat");
calibrationFallback = "none";

% Seven fixed VMMBIN test vectors.
%
% Binary mapping:
%   leftmost character  = physical row 7
%   rightmost character = physical row 0
%
% The default set contains one vector for each active-row count from one
% through seven, and avoids physical row 2.
rowInputs = [
    "00000001"  % 1 active: row 0
    "10000010"  % 2 active: rows 1, 7
    "01001001"  % 3 active: rows 0, 3, 6
    "10110010"  % 4 active: rows 1, 4, 5, 7
    "01101011"  % 5 active: rows 0, 1, 3, 5, 6
    "11111010"  % 6 active: rows 1, 3, 4, 5, 6, 7
    "11111011"  % 7 active: 
];

if vsel <= vcm
    error("Example07:InvalidBias", "VSEL must be greater than VCM.");
end
validateattributes(packetAverageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});
validateattributes(averageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});
validateattributes(maxVmmAttempts, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 50});
validateattributes(primeDiscardCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 0, '<=', 20});
validateattributes(firstVectorPrimeDiscardCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 0, '<=', 20});
if autoLowLimitV <= 0 || autoHighLimitV <= autoLowLimitV
    error("Example07:InvalidWindow", ...
        "autoLowLimitV must be positive and below autoHighLimitV.");
end
if ~exist(calibrationIndexPath, 'file')
    error("Example07:MissingCalibration", ...
        "Fundamental calibration index not found. Run example_03_single_rf_calibration.m first.\nExpected: %s", ...
        calibrationIndexPath);
end

referenceMatrixSource = lower(convertCharsToStrings(referenceMatrixSource));
switch referenceMatrixSource
    case "manual"
        R_expected_ohm = R_expected_manual_ohm;
    case "uniform"
        R_expected_ohm = knownResistanceOhm * ones(8, 8);
    case "csv"
        if strlength(string(knownResistanceMapCsv)) == 0
            error("Example07:MissingResistanceCsv", ...
                "Set knownResistanceMapCsv when referenceMatrixSource is 'csv'.");
        end
        R_expected_ohm = readmatrix(knownResistanceMapCsv);
    otherwise
        error("Example07:InvalidReferenceSource", ...
            "referenceMatrixSource must be 'manual', 'uniform', or 'csv'.");
end
if ~isequal(size(R_expected_ohm), [8 8])
    error("Example07:InvalidResistanceMap", ...
        "The expected resistance matrix must be 8x8.");
end

loaded = load(calibrationIndexPath);
readoutModel = loaded.readoutModel;
unusedGlobalFields = {'globalGain', 'globalOffset_a'};
for k = 1:numel(unusedGlobalFields)
    if isfield(readoutModel, unusedGlobalFields{k})
        readoutModel = rmfield(readoutModel, unusedGlobalFields{k});
    end
end
parameterTable = basic_delta_v_model_table(readoutModel);

resultFolder = create_result_folder("binary_vmm_auto_rf_conservative_basic");

dev = BasicArrayReader(portName, baudRate);
dev.connect();
cleanupObj = onCleanup(@() cleanupDevice(dev, packetAverageCount, autoRangeStartRF));

autoOpt = struct();
autoOpt.vsel = vsel;
autoOpt.vcm = vcm;
autoOpt.startRF = string(autoRangeStartRF);
autoOpt.rfNameLadder = string(rfNameLadder);
autoOpt.lowLimitV = autoLowLimitV;
autoOpt.highLimitV = autoHighLimitV;
autoOpt.maxAttempts = maxVmmAttempts;
autoOpt.retryPause_s = retryPause_s;
autoOpt.vectorSettle_s = vectorSettle_s;
autoOpt.firstVectorSettle_s = firstVectorSettle_s;
autoOpt.primeDiscardCount = primeDiscardCount;
autoOpt.firstVectorPrimeDiscardCount = firstVectorPrimeDiscardCount;
autoOpt.requireStablePair = requireStablePair;
autoOpt.stableRelTol = stableRelTol;
autoOpt.timeout_s = vmmTimeout_s;
autoOpt.averageCount = averageCount;

fprintf("Loaded fundamental calibration index:\n%s\n", calibrationIndexPath);
fprintf("Calibration RF values / ohm: %s\n", mat2str(readoutModel.rfValues(:).'));
fprintf("VMM bias request: VCM %.6f V, VSEL %.6f V, delta %.6f V\n", ...
    vcm, vsel, vsel - vcm);
fprintf("MATLAB VMM auto-RF start: %s, window %.3f to %.3f V\n", ...
    autoRangeStartRF, autoLowLimitV, autoHighLimitV);
fprintf("Fixed VMM test vectors: %d\n", numel(rowInputs));
disp(table((1:numel(rowInputs)).', rowInputs, ...
    countActiveBitsLocal(rowInputs), ...
    'VariableNames', {'test_index', 'row_input', 'active_rows'}));

dev.setPacketAverage(packetAverageCount);
i2cBefore = dev.i2cScan();
disp("I2CSCAN before VMM:");
disp(i2cBefore.expectedFound);

setVMMBiasLocal(dev, vsel, vcm, false);
statusAfterBias = dev.getStatus();
fprintf("STATUS after VMM bias: VCM %.6f V, VSEL %.6f V, VREAD %.6f V\n", ...
    statusAfterBias.VCM, statusAfterBias.VSEL, statusAfterBias.VREAD);

numTests = numel(rowInputs);
rawRows = cell(numTests, 1);
autoTraceRows = cell(numTests, 1);
measured = cell(numTests, 1);
predicted = cell(numTests, 1);

I_raw_stack = nan(numTests, 8);
I_expected_stack = nan(numTests, 8);
y_raw_stack = nan(numTests, 8);
y_expected_stack = nan(numTests, 8);
deltaV_by_test = nan(numTests, 1);
activeCount = nan(numTests, 1);
rowBits = nan(numTests, 1);
rowBitsBinary = strings(numTests, 1);
rf_ohm_stack = nan(numTests, 8);
equiv_vadc_stack = nan(numTests, 8);
acceptedReason = strings(numTests, 1);
acceptedAttempts = nan(numTests, 1);

for k = 1:numTests
    fprintf("\nRunning guarded VMMBIN %s (%d/%d)...\n", rowInputs(k), k, numTests);
    [measured{k}, autoTraceRows{k}] = runVmmAutoRfConservative( ...
        dev, rowInputs(k), k, autoOpt);
    predicted{k} = predictBinaryVMMLocal(R_expected_ohm, ...
        measured{k}.rowBits, measured{k}.VSEL, measured{k}.VCM);

    rowBits(k) = measured{k}.rowBits;
    rowBitsBinary(k) = measured{k}.rowBitsBinary;
    activeCount(k) = sum(measured{k}.x);
    deltaV_by_test(k) = measured{k}.deltaV;
    acceptedReason(k) = measured{k}.auto_rf_accept_reason;
    acceptedAttempts(k) = measured{k}.auto_rf_attempts;

    I_raw_stack(k, :) = measured{k}.current_a(:).';
    y_raw_stack(k, :) = measured{k}.y_meas_s(:).';
    I_expected_stack(k, :) = predicted{k}.current_pred_a(:).';
    y_expected_stack(k, :) = predicted{k}.y_pred_s(:).';
    rf_ohm_stack(k, :) = measured{k}.rf_ohm_by_col(:).';
    equiv_vadc_stack(k, :) = abs(measured{k}.current_a(:).') .* rf_ohm_stack(k, :);

    rawRows{k} = vmmResultToCalibrationTable(measured{k}, ...
        rowInputs(k), k, measured{k}.rf_name_by_col, measured{k}.rf_ohm_by_col);

    fprintf("accepted %s | attempts %d | RF [%s] | Vadc %.4g..%.4g V\n", ...
        char(acceptedReason(k)), acceptedAttempts(k), ...
        char(strjoin(measured{k}.rf_name_by_col(:).', " ")), ...
        min(equiv_vadc_stack(k, :), [], "omitnan"), ...
        max(equiv_vadc_stack(k, :), [], "omitnan"));
end

rawVmmTable = vertcat(rawRows{:});
autoRfTraceTable = vertcat(autoTraceRows{:});
calibrated = apply_basic_delta_v_calibration_model(rawVmmTable, readoutModel, ...
    "deltaV", rawVmmTable.delta_v, "fallback", calibrationFallback, ...
    "numRows", numTests, "numCols", 8);

detailTable = calibrated.table;
detailTable.current_expected_a = reshape(I_expected_stack.', [], 1);
detailTable.y_expected_s = reshape(y_expected_stack.', [], 1);
detailTable.y_raw_s = detailTable.current_a ./ detailTable.delta_v;
detailTable.y_calibrated_s = detailTable.current_readout_calibrated_a ./ detailTable.delta_v;
detailTable.current_raw_error_a = detailTable.current_a - detailTable.current_expected_a;
detailTable.current_calibrated_error_a = ...
    detailTable.current_readout_calibrated_a - detailTable.current_expected_a;
detailTable.current_raw_error_percent = ...
    safePercent(detailTable.current_raw_error_a, detailTable.current_expected_a);
detailTable.current_calibrated_error_percent = ...
    safePercent(detailTable.current_calibrated_error_a, detailTable.current_expected_a);
detailTable.y_raw_error_s = detailTable.y_raw_s - detailTable.y_expected_s;
detailTable.y_calibrated_error_s = detailTable.y_calibrated_s - detailTable.y_expected_s;
detailTable.y_raw_error_percent = safePercent(detailTable.y_raw_error_s, detailTable.y_expected_s);
detailTable.y_calibrated_error_percent = ...
    safePercent(detailTable.y_calibrated_error_s, detailTable.y_expected_s);

I_calibrated_stack = reshape(detailTable.current_readout_calibrated_a, 8, numTests).';
y_calibrated_stack = reshape(detailTable.y_calibrated_s, 8, numTests).';
I_raw_error_percent_stack = reshape(detailTable.current_raw_error_percent, 8, numTests).';
I_calibrated_error_percent_stack = ...
    reshape(detailTable.current_calibrated_error_percent, 8, numTests).';
y_raw_error_percent_stack = reshape(detailTable.y_raw_error_percent, 8, numTests).';
y_calibrated_error_percent_stack = ...
    reshape(detailTable.y_calibrated_error_percent, 8, numTests).';

uniformKnown = isfinite(knownResistanceOhm) && ...
    max(abs(R_expected_ohm(:) - knownResistanceOhm), [], "omitnan") < max(1, knownResistanceOhm) * 1e-9;
if uniformKnown
    G_cell_s = 1 / knownResistanceOhm;
    mult_raw_stack = y_raw_stack ./ G_cell_s;
    mult_calibrated_stack = y_calibrated_stack ./ G_cell_s;
    mult_expected_stack = y_expected_stack ./ G_cell_s;
    mult_calibrated_error_percent_stack = ...
        safePercent(mult_calibrated_stack - mult_expected_stack, mult_expected_stack);
else
    G_cell_s = nan;
    mult_raw_stack = nan(numTests, 8);
    mult_calibrated_stack = nan(numTests, 8);
    mult_expected_stack = nan(numTests, 8);
    mult_calibrated_error_percent_stack = nan(numTests, 8);
end

summaryTable = makeSummaryTable(rowInputs, rowBitsBinary, rowBits, activeCount, ...
    acceptedReason, acceptedAttempts, I_raw_error_percent_stack, ...
    I_calibrated_error_percent_stack, y_raw_error_percent_stack, ...
    y_calibrated_error_percent_stack);

rfUsageTable = summarizeCalibrationRfUse(detailTable);

write_table_compatible(parameterTable, ...
    fullfile(resultFolder, "loaded_fundamental_gain_offset_parameters.csv"));
write_table_compatible(rawVmmTable, fullfile(resultFolder, "vmm_auto_rf_accepted_raw_table.csv"));
write_table_compatible(autoRfTraceTable, fullfile(resultFolder, "vmm_auto_rf_trace_table.csv"));
write_table_compatible(detailTable, fullfile(resultFolder, "vmm_auto_rf_calibrated_detail_table.csv"));
write_table_compatible(summaryTable, fullfile(resultFolder, "vmm_auto_rf_summary_table.csv"));
write_table_compatible(rfUsageTable, fullfile(resultFolder, "vmm_auto_rf_calibration_usage.csv"));

writematrix(R_expected_ohm, fullfile(resultFolder, "ideal_R_expected_ohm.csv"));
writematrix(I_raw_stack, fullfile(resultFolder, "vmm_auto_rf_raw_current_a.csv"));
writematrix(I_calibrated_stack, fullfile(resultFolder, "vmm_auto_rf_calibrated_current_a.csv"));
writematrix(I_expected_stack, fullfile(resultFolder, "vmm_ideal_current_a.csv"));
writematrix(y_raw_stack, fullfile(resultFolder, "vmm_auto_rf_raw_conductance_output_s.csv"));
writematrix(y_calibrated_stack, fullfile(resultFolder, "vmm_auto_rf_calibrated_conductance_output_s.csv"));
writematrix(y_expected_stack, fullfile(resultFolder, "vmm_ideal_conductance_output_s.csv"));
writematrix(rf_ohm_stack, fullfile(resultFolder, "vmm_auto_rf_selected_rf_ohm.csv"));
writematrix(equiv_vadc_stack, fullfile(resultFolder, "vmm_auto_rf_equivalent_vadc_v.csv"));
writematrix(I_calibrated_error_percent_stack, ...
    fullfile(resultFolder, "vmm_auto_rf_calibrated_current_error_percent.csv"));
writematrix(y_calibrated_error_percent_stack, ...
    fullfile(resultFolder, "vmm_auto_rf_calibrated_conductance_error_percent.csv"));
if uniformKnown
    writematrix(mult_raw_stack, fullfile(resultFolder, "vmm_auto_rf_raw_multiplication_value_cells.csv"));
    writematrix(mult_calibrated_stack, ...
        fullfile(resultFolder, "vmm_auto_rf_calibrated_multiplication_value_cells.csv"));
    writematrix(mult_expected_stack, ...
        fullfile(resultFolder, "vmm_ideal_multiplication_value_cells.csv"));
    writematrix(mult_calibrated_error_percent_stack, ...
        fullfile(resultFolder, "vmm_auto_rf_calibrated_multiplication_error_percent.csv"));
end

plot_matrix_heatmap(I_calibrated_stack, "Auto-RF calibrated VMM current / A", ...
    fullfile(resultFolder, "vmm_auto_rf_calibrated_current_heatmap.png"), ...
    "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
    "colorbarLabel", "A", "showText", true);
plot_matrix_heatmap(I_expected_stack, "Ideal VMM current / A", ...
    fullfile(resultFolder, "vmm_ideal_current_heatmap.png"), ...
    "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
    "colorbarLabel", "A", "showText", true);
plot_matrix_heatmap(I_calibrated_error_percent_stack, ...
    "Auto-RF calibrated VMM current error vs ideal / %", ...
    fullfile(resultFolder, "vmm_auto_rf_calibrated_current_error_percent_heatmap.png"), ...
    "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
    "colorbarLabel", "%", "showText", true);
plot_matrix_heatmap(rf_ohm_stack, "VMM auto-RF selected feedback resistance / ohm", ...
    fullfile(resultFolder, "vmm_auto_rf_selected_rf_heatmap.png"), ...
    "logScale", true, "xLabel", "Column", "yLabel", "Test vector index", ...
    "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(equiv_vadc_stack, "VMM auto-RF equivalent ADC voltage / V", ...
    fullfile(resultFolder, "vmm_auto_rf_equivalent_vadc_heatmap.png"), ...
    "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
    "colorbarLabel", "V", "showText", true);

if uniformKnown
    plot_matrix_heatmap(mult_calibrated_stack, ...
        "Auto-RF calibrated VMM reconstructed output / active 100k cells", ...
        fullfile(resultFolder, "vmm_auto_rf_calibrated_multiplication_value_heatmap.png"), ...
        "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
        "colorbarLabel", "active cells", "showText", true);
    plot_matrix_heatmap(mult_calibrated_error_percent_stack, ...
        "Auto-RF calibrated VMM multiplication error vs ideal / %", ...
        fullfile(resultFolder, "vmm_auto_rf_calibrated_multiplication_error_percent_heatmap.png"), ...
        "logScale", false, "xLabel", "Column", "yLabel", "Test vector index", ...
        "colorbarLabel", "%", "showText", true);
end

save(fullfile(resultFolder, "vmm_auto_rf_calibrated_outputs.mat"), ...
    "rowInputs", "rowBits", "rowBitsBinary", "activeCount", ...
    "acceptedReason", "acceptedAttempts", "vcm", "vsel", ...
    "autoRangeStartRF", "rfNameLadder", "autoLowLimitV", ...
    "autoHighLimitV", "maxVmmAttempts", "retryPause_s", ...
    "vectorSettle_s", "firstVectorSettle_s", "primeDiscardCount", ...
    "firstVectorPrimeDiscardCount", "requireStablePair", "stableRelTol", ...
    "packetAverageCount", "averageCount", "R_expected_ohm", ...
    "knownResistanceOhm", "knownResistanceMapCsv", ...
    "referenceMatrixSource", "R_expected_manual_ohm", ...
    "readoutModel", "parameterTable", "calibrationIndexPath", ...
    "i2cBefore", "statusAfterBias", "measured", "predicted", ...
    "rawVmmTable", "autoRfTraceTable", "calibrated", ...
    "detailTable", "summaryTable", "rfUsageTable", ...
    "I_raw_stack", "I_calibrated_stack", "I_expected_stack", ...
    "y_raw_stack", "y_calibrated_stack", "y_expected_stack", ...
    "rf_ohm_stack", "equiv_vadc_stack", ...
    "I_raw_error_percent_stack", "I_calibrated_error_percent_stack", ...
    "y_raw_error_percent_stack", "y_calibrated_error_percent_stack", ...
    "mult_raw_stack", "mult_calibrated_stack", "mult_expected_stack", ...
    "mult_calibrated_error_percent_stack", "G_cell_s");

disp("VMM auto-RF calibration usage:");
disp(rfUsageTable);
disp("VMM auto-RF calibrated accuracy summary:");
disp(summaryTable);
if any(~detailTable.readout_cal_applied)
    warning("Example07:UncalibratedVMMRF", ...
        "Some VMM columns used an RF range not present in the loaded calibration model.");
end

dev.restoreDefaultReadoutState(packetAverageCount, autoRangeStartRF);
fprintf("Saved conservative auto-RF VMM outputs to:\n%s\n", resultFolder);

function [accepted, traceTable] = runVmmAutoRfConservative(dev, rowInput, testIndex, opt)
[rfNames, rfOhms] = normalizeRfLadder(opt.rfNameLadder);
startIdx = find(rfNames == opt.startRF, 1);
if isempty(startIdx)
    error("Example07:InvalidStartRF", ...
        "autoRangeStartRF '%s' is not in rfNameLadder.", opt.startRF);
end

rfIdx = repmat(startIdx, 8, 1);
rawRows = {};
previous = struct("isValid", false);
best = struct("score", [-Inf, -Inf, -Inf], "vmm", [], "rfIdx", rfIdx, ...
    "attempt", 0, "reason", "NO_CANDIDATE");

setVMMBiasLocal(dev, opt.vsel, opt.vcm, false);
applyRFVector(dev, rfNames(rfIdx));
if testIndex == 1
    pause_s = opt.firstVectorSettle_s;
    primeCount = max(opt.primeDiscardCount, opt.firstVectorPrimeDiscardCount);
else
    pause_s = opt.vectorSettle_s;
    primeCount = opt.primeDiscardCount;
end
if pause_s > 0
    pause(pause_s);
end

for p = 1:primeCount
    prime = runBinaryVMMLocal(dev, rowInput, opt.timeout_s);
    [inWindow, reasons, vadc] = classifyVmmWindow(prime, rfOhms(rfIdx), ...
        opt.lowLimitV, opt.highLimitV);
    rawRows{end+1, 1} = tagVmmAutoRfTable(prime, rowInput, testIndex, ...
        rfNames(rfIdx), rfOhms(rfIdx), 0, "prime_discard", inWindow, ...
        reasons, vadc, false, opt, "PRIME_DISCARD"); %#ok<AGROW>
end

accepted = [];
acceptReason = "MAX_RETRY_LIMIT";
acceptedAttempt = opt.maxAttempts;
acceptedRfIdx = rfIdx;

for attempt = 1:opt.maxAttempts
    setVMMBiasLocal(dev, opt.vsel, opt.vcm, false);
    applyRFVector(dev, rfNames(rfIdx));
    if opt.retryPause_s > 0
        pause(opt.retryPause_s);
    end

    candidate = runBinaryVMMLocal(dev, rowInput, opt.timeout_s);
    [inWindow, reasons, vadc] = classifyVmmWindow(candidate, rfOhms(rfIdx), ...
        opt.lowLimitV, opt.highLimitV);
    allInWindow = all(inWindow);
    stable = false;
    if previous.isValid && allInWindow && isequal(previous.rfIdx, rfIdx)
        stable = isStableVmmPair(previous.vmm, candidate, opt.stableRelTol);
    end

    rawRows{end+1, 1} = tagVmmAutoRfTable(candidate, rowInput, testIndex, ...
        rfNames(rfIdx), rfOhms(rfIdx), attempt, "candidate", inWindow, ...
        reasons, vadc, stable, opt, "CANDIDATE"); %#ok<AGROW>
    best = updateBestCandidate(best, candidate, rfIdx, attempt, inWindow, vadc, opt);

    if allInWindow && (~logical(opt.requireStablePair) || stable)
        accepted = candidate;
        if stable
            acceptReason = "OK_IN_WINDOW_STABLE_PAIR";
        else
            acceptReason = "OK_IN_WINDOW";
        end
        acceptedAttempt = attempt;
        acceptedRfIdx = rfIdx;
        break;
    end

    if allInWindow
        previous = struct("isValid", true, "vmm", candidate, "rfIdx", rfIdx);
    else
        previous = struct("isValid", false);
        rfIdx = adjustRfIndices(rfIdx, vadc, opt.lowLimitV, opt.highLimitV, numel(rfNames));
    end
end

if isempty(accepted)
    accepted = best.vmm;
    acceptedRfIdx = best.rfIdx;
    acceptedAttempt = best.attempt;
    acceptReason = "BEST_AFTER_RETRY_LIMIT_" + string(best.reason);
end

applyRFVector(dev, rfNames(acceptedRfIdx));
if opt.retryPause_s > 0
    pause(opt.retryPause_s);
end
if opt.averageCount > 1
    final = runBinaryVMMAveragedLocal(dev, rowInput, opt.averageCount, opt.timeout_s);
else
    final = accepted;
    final.average_count = 1;
end

[finalInWindow, finalReasons, finalVadc] = classifyVmmWindow(final, ...
    rfOhms(acceptedRfIdx), opt.lowLimitV, opt.highLimitV);
rawRows{end+1, 1} = tagVmmAutoRfTable(final, rowInput, testIndex, ...
    rfNames(acceptedRfIdx), rfOhms(acceptedRfIdx), acceptedAttempt, ...
    "accepted_final", finalInWindow, finalReasons, finalVadc, true, ...
    opt, acceptReason);

final.rf_name_by_col = rfNames(acceptedRfIdx);
final.rf_ohm_by_col = rfOhms(acceptedRfIdx);
final.auto_rf_accept_reason = acceptReason;
final.auto_rf_attempts = acceptedAttempt;
final.auto_rf_low_limit_v = opt.lowLimitV;
final.auto_rf_high_limit_v = opt.highLimitV;
final.auto_rf_start_rf = opt.startRF;
final.auto_rf_require_stable_pair = logical(opt.requireStablePair);
final.auto_rf_stable_rel_tol = opt.stableRelTol;
accepted = final;
traceTable = vertcat(rawRows{:});
end

function responseLine = setVMMBiasLocal(dev, vsel, vcm, verbose)
if nargin < 4
    verbose = true;
end
validateattributes(vsel, {'numeric'}, {'scalar', 'real', 'finite'});
validateattributes(vcm, {'numeric'}, {'scalar', 'real', 'finite'});
cmd = sprintf("SETBIAS %.9g %.9g", vsel, vcm);
dev.flushInput();
dev.sendCommand(cmd);
responseLine = dev.readUntilAny(["OK,", "ERROR,"], dev.DefaultTimeout);
if startsWith(responseLine, "ERROR,")
    error("Example07:FirmwareError", "%s", responseLine);
end
if verbose
    fprintf("SETBIAS response: %s\n", responseLine);
end
end

function out = runBinaryVMMAveragedLocal(dev, rowInput, numAverages, timeout_s)
if numAverages == 1
    out = runBinaryVMMLocal(dev, rowInput, timeout_s);
    out.average_count = 1;
    return;
end

runs = cell(numAverages, 1);
currents = nan(8, numAverages);
for rep = 1:numAverages
    runs{rep} = runBinaryVMMLocal(dev, rowInput, timeout_s);
    currents(:, rep) = runs{rep}.current_a(:);
end

out = runs{end};
out.current_a = mean(currents, 2, "omitnan");
out.current_std_a = std(currents, 0, 2, "omitnan");
out.y_meas_s = out.current_a ./ out.deltaV;
out.y_std_s = out.current_std_a ./ out.deltaV;
out.average_count = numAverages;
out.rawAverageRuns = runs;
end

function out = runBinaryVMMLocal(dev, rowInput, timeout_s)
[cmd, expectedRowBits] = binaryVMMCommandLocal(rowInput);
dev.flushInput();
dev.sendCommand(cmd);
line = dev.readUntilAny(["VMM_RESULT,", "ERROR,"], timeout_s);
if startsWith(line, "ERROR,")
    error("Example07:FirmwareError", "%s", line);
end

out = parseVMMResultLineLocal(line);
out.command = cmd;
out.expectedRowBits = expectedRowBits;
if out.rowBits ~= expectedRowBits
    warning("Example07:VMMRowBitsMismatch", ...
        "Requested rowBits %d but firmware returned %d.", ...
        expectedRowBits, out.rowBits);
end
end

function applyRFVector(dev, rfNamesByCol)
rfNamesByCol = string(rfNamesByCol(:));
if all(rfNamesByCol == rfNamesByCol(1))
    dev.setRF(rfNamesByCol(1));
    return;
end

for ch = 0:7
    dev.setRFChannel(ch, rfNamesByCol(ch + 1));
end
end

function [rfNames, rfOhms] = normalizeRfLadder(rfNameLadder)
rfNames = string(rfNameLadder(:));
rfOhms = nan(numel(rfNames), 1);
for k = 1:numel(rfNames)
    rfOhms(k) = rfNameToOhm(rfNames(k));
end
[rfOhms, idx] = sort(rfOhms);
rfNames = rfNames(idx);
end

function [inWindow, reasons, vadc] = classifyVmmWindow(vmm, rfOhmByCol, lowLimitV, highLimitV)
vadc = abs(vmm.current_a(:)) .* rfOhmByCol(:);
inWindow = isfinite(vadc) & vadc >= lowLimitV & vadc <= highLimitV;
reasons = strings(8, 1);
for k = 1:8
    if ~isfinite(vadc(k))
        reasons(k) = "NONFINITE_ADC_EQUIV_RETRY";
    elseif vadc(k) < lowLimitV
        reasons(k) = "LOW_ADC_EQUIV_RF_UP_OR_SWITCH";
    elseif vadc(k) > highLimitV
        reasons(k) = "HIGH_ADC_EQUIV_RF_DOWN_OR_SWITCH";
    else
        reasons(k) = "OK_IN_WINDOW";
    end
end
end

function rfIdx = adjustRfIndices(rfIdx, vadc, lowLimitV, highLimitV, numRanges)
for k = 1:numel(rfIdx)
    if ~isfinite(vadc(k))
        continue;
    elseif vadc(k) < lowLimitV
        rfIdx(k) = min(numRanges, rfIdx(k) + 1);
    elseif vadc(k) > highLimitV
        rfIdx(k) = max(1, rfIdx(k) - 1);
    end
end
end

function tf = isStableVmmPair(a, b, relTol)
ia = abs(a.current_a(:));
ib = abs(b.current_a(:));
valid = isfinite(ia) & isfinite(ib);
if ~all(valid)
    tf = false;
    return;
end
scale = max([ia, ib, eps .* ones(size(ia))], [], 2);
tf = all(abs(ia - ib) <= relTol .* scale);
end

function best = updateBestCandidate(best, candidate, rfIdx, attempt, inWindow, vadc, opt)
lowError = max(0, opt.lowLimitV - vadc) ./ opt.lowLimitV;
highError = max(0, vadc - opt.highLimitV) ./ opt.highLimitV;
windowError = lowError + highError;
score = [sum(inWindow), -sum(windowError, "omitnan"), -attempt];
if lexicographicGreater(score, best.score)
    if all(inWindow)
        reason = "ALL_IN_WINDOW_NOT_STABLE";
    else
        reason = "BEST_WINDOW_SCORE";
    end
    best = struct("score", score, "vmm", candidate, "rfIdx", rfIdx, ...
        "attempt", attempt, "reason", reason);
end
end

function tf = lexicographicGreater(a, b)
tf = false;
for k = 1:numel(a)
    if a(k) > b(k)
        tf = true;
        return;
    elseif a(k) < b(k)
        return;
    end
end
end

function T = tagVmmAutoRfTable(vmm, rowInput, testIndex, rfNamesByCol, ...
        rfOhmByCol, attempt, role, inWindow, reasons, vadc, stable, opt, acceptReason)
T = vmmResultToCalibrationTable(vmm, rowInput, testIndex, rfNamesByCol, rfOhmByCol);
T.vmm_auto_rf_attempt = repmat(attempt, height(T), 1);
T.vmm_auto_rf_role = repmat(string(role), height(T), 1);
T.vmm_auto_rf_in_window = logical(inWindow(:));
T.vmm_auto_rf_channel_reason = string(reasons(:));
T.vmm_auto_rf_equivalent_vadc_v = vadc(:);
T.vmm_auto_rf_stable_with_previous = repmat(logical(stable), height(T), 1);
T.vmm_auto_rf_accept_reason = repmat(string(acceptReason), height(T), 1);
T.vmm_auto_rf_start_rf = repmat(string(opt.startRF), height(T), 1);
T.vmm_auto_rf_low_limit_v = repmat(opt.lowLimitV, height(T), 1);
T.vmm_auto_rf_high_limit_v = repmat(opt.highLimitV, height(T), 1);
T.vmm_auto_rf_max_attempts = repmat(opt.maxAttempts, height(T), 1);
T.vmm_auto_rf_require_stable_pair = repmat(logical(opt.requireStablePair), height(T), 1);
T.vmm_auto_rf_stable_rel_tol = repmat(opt.stableRelTol, height(T), 1);
end

function T = vmmResultToCalibrationTable(vmm, rowInput, testIndex, rfNameByCol, rfOhmByCol)
col0 = (0:7).';
col = col0 + 1;
row = repmat(testIndex, 8, 1);
row0 = row - 1;
rf_name = string(rfNameByCol(:));
rf_ohm = rfOhmByCol(:);
current_a = vmm.current_a(:);
vadc_v = current_a .* rf_ohm;
r_ohm = vmm.deltaV ./ current_a;
status = repmat("OK", 8, 1);
attempts = zeros(8, 1);
packet_avg = repmat(vmm.packet_avg, 8, 1);
delta_v = repmat(vmm.deltaV, 8, 1);
VSEL = repmat(vmm.VSEL, 8, 1);
VCM = repmat(vmm.VCM, 8, 1);
test_index = repmat(testIndex, 8, 1);
row_input = repmat(string(rowInput), 8, 1);
rowBitsBinary = repmat(vmm.rowBitsBinary, 8, 1);
rowBits = repmat(vmm.rowBits, 8, 1);
active_count = repmat(sum(vmm.x), 8, 1);
if isfield(vmm, "average_count") && isscalar(vmm.average_count) && ...
        isfinite(vmm.average_count)
    matlabAverageCount = vmm.average_count;
else
    % Priming and retry candidates are individual VMM reads. Older parsed
    % result structures did not carry this MATLAB-side metadata.
    matlabAverageCount = 1;
end
average_count = repmat(matlabAverageCount, 8, 1);

T = table(test_index, row_input, rowBitsBinary, rowBits, active_count, ...
    row0, col0, row, col, rf_name, rf_ohm, vadc_v, current_a, r_ohm, ...
    status, attempts, packet_avg, average_count, VSEL, VCM, delta_v, ...
    'VariableNames', {'test_index', 'row_input', 'rowBitsBinary', ...
    'rowBits', 'active_count', 'row0', 'col0', 'row', 'col', ...
    'rf_name', 'rf_ohm', 'vadc_v', 'current_a', 'r_ohm', 'status', ...
    'attempts', 'packet_avg', 'average_count', 'VSEL', 'VCM', 'delta_v'});

if isfield(vmm, "current_std_a")
    T.current_std_a = vmm.current_std_a(:);
    T.y_std_s = vmm.y_std_s(:);
end
end

function out = parseVMMResultLineLocal(line)
line = strtrim(string(line));
if ~startsWith(line, "VMM_RESULT,")
    error("Example07:ParseError", "Not a VMM_RESULT line: %s", line);
end

p = split(line, ",");
if numel(p) < 13
    error("Example07:ParseError", ...
        "VMM_RESULT line has too few fields: %s", line);
end

rowBits = str2double(p(2));
vsel = str2double(p(3));
vcm = str2double(p(4));
deltaV = str2double(p(5));
current_a = nan(8, 1);
for col0 = 0:7
    current_a(col0 + 1) = str2double(p(6 + col0));
end
packet_avg = parseOptionalNumericFieldLocal(p, "AVG", nan);

out = struct();
out.rawLine = line;
out.rowBits = rowBits;
out.rowBitsBinary = string(dec2bin(rowBits, 8));
out.x = rowBitsToBinaryVectorLocal(rowBits);
out.VSEL = vsel;
out.VCM = vcm;
out.deltaV = deltaV;
out.current_a = current_a;
out.y_meas_s = current_a ./ deltaV;
out.packet_avg = packet_avg;
out.average_count = 1;
out.timestamp = datetime("now");
end

function pred = predictBinaryVMMLocal(R_ohm, rowBits, vsel, vcm)
deltaV = vsel - vcm;
if deltaV <= 0
    error("Example07:InvalidBias", "VSEL must be greater than VCM.");
end

x = rowBitsToBinaryVectorLocal(rowBits);
G_s = 1 ./ R_ohm;
G_s(~isfinite(G_s)) = nan;

y_pred_s = G_s.' * x;
current_pred_a = deltaV .* y_pred_s;

pred = struct();
pred.rowBits = rowBits;
pred.rowBitsBinary = string(dec2bin(rowBits, 8));
pred.x = x;
pred.VSEL = vsel;
pred.VCM = vcm;
pred.deltaV = deltaV;
pred.G_s = G_s;
pred.y_pred_s = y_pred_s;
pred.current_pred_a = current_pred_a;
end

function [cmd, rowBits] = binaryVMMCommandLocal(rowInput)
if isstring(rowInput) || ischar(rowInput)
    bits = char(string(rowInput));
    if numel(bits) ~= 8 || any(bits ~= '0' & bits ~= '1')
        error("Example07:InvalidVMMInput", ...
            "VMMBIN input must be an 8-character 0/1 string.");
    end
    rowBits = bin2dec(bits);
    cmd = sprintf("VMMBIN %s", bits);
    return;
end

if isnumeric(rowInput) && isscalar(rowInput)
    validateattributes(rowInput, {'numeric'}, {'integer', '>=', 0, '<=', 255});
    rowBits = double(rowInput);
    cmd = sprintf("VMM %d", rowBits);
    return;
end

if isnumeric(rowInput)
    rowBits = binaryVectorToRowBitsLocal(rowInput);
    cmd = sprintf("VMM %d", rowBits);
    return;
end

error("Example07:InvalidVMMInput", ...
    "rowInput must be decimal row bits, an 8-bit string, or an 8-element binary vector.");
end

function rowBits = binaryVectorToRowBitsLocal(x)
x = x(:);
if numel(x) ~= 8 || any(~ismember(x, [0 1]))
    error("Example07:InvalidVMMInput", ...
        "Binary VMM vector must contain exactly eight 0/1 values.");
end

rowBits = 0;
for row0 = 0:7
    if x(row0 + 1) == 1
        rowBits = rowBits + 2^row0;
    end
end
end

function x = rowBitsToBinaryVectorLocal(rowBits)
validateattributes(rowBits, {'numeric'}, {'scalar', 'integer', '>=', 0, '<=', 255});
x = zeros(8, 1);
for row0 = 0:7
    x(row0 + 1) = bitget(uint16(rowBits), row0 + 1);
end
end

function value = parseOptionalNumericFieldLocal(parts, keyName, defaultValue)
value = defaultValue;
keyName = upper(string(keyName));
for k = 1:numel(parts)-1
    if upper(string(parts(k))) == keyName
        parsed = str2double(parts(k+1));
        if isfinite(parsed)
            value = parsed;
        end
        return;
    end
end
end

function ohm = rfNameToOhm(rfName)
s = lower(strtrim(string(rfName)));
s = replace(s, "ohm", "");
s = replace(s, " ", "");
switch s
    case {"100", "100r"}
        ohm = 100;
    case {"1k", "1000"}
        ohm = 1e3;
    case {"10k", "10000"}
        ohm = 10e3;
    case {"100k", "100000"}
        ohm = 100e3;
    case {"1m", "1meg", "1000000"}
        ohm = 1e6;
    otherwise
        error("Example07:UnknownRF", "Cannot map RF name '%s' to ohms.", rfName);
end
end

function out = safePercent(numerator, denominator)
out = nan(size(numerator));
valid = isfinite(numerator) & isfinite(denominator) & denominator ~= 0;
out(valid) = 100 .* numerator(valid) ./ denominator(valid);
end

function T = makeSummaryTable(rowInputs, rowBitsBinary, rowBits, activeCount, ...
        acceptedReason, acceptedAttempts, rawCurrentErrorPercent, ...
        calCurrentErrorPercent, rawYErrorPercent, calYErrorPercent)
numTests = numel(rowInputs);
raw_mape_current_percent = nan(numTests, 1);
cal_mape_current_percent = nan(numTests, 1);
raw_max_abs_current_percent = nan(numTests, 1);
cal_max_abs_current_percent = nan(numTests, 1);
raw_mape_conductance_percent = nan(numTests, 1);
cal_mape_conductance_percent = nan(numTests, 1);
raw_max_abs_conductance_percent = nan(numTests, 1);
cal_max_abs_conductance_percent = nan(numTests, 1);

for k = 1:numTests
    rawI = abs(rawCurrentErrorPercent(k, :));
    calI = abs(calCurrentErrorPercent(k, :));
    rawY = abs(rawYErrorPercent(k, :));
    calY = abs(calYErrorPercent(k, :));

    raw_mape_current_percent(k) = mean(rawI, "omitnan");
    cal_mape_current_percent(k) = mean(calI, "omitnan");
    raw_max_abs_current_percent(k) = max(rawI, [], "omitnan");
    cal_max_abs_current_percent(k) = max(calI, [], "omitnan");
    raw_mape_conductance_percent(k) = mean(rawY, "omitnan");
    cal_mape_conductance_percent(k) = mean(calY, "omitnan");
    raw_max_abs_conductance_percent(k) = max(rawY, [], "omitnan");
    cal_max_abs_conductance_percent(k) = max(calY, [], "omitnan");
end

test_index = (1:numTests).';
T = table(test_index, string(rowInputs(:)), rowBitsBinary(:), rowBits(:), ...
    activeCount(:), acceptedReason(:), acceptedAttempts(:), ...
    raw_mape_current_percent, cal_mape_current_percent, ...
    raw_max_abs_current_percent, cal_max_abs_current_percent, ...
    raw_mape_conductance_percent, cal_mape_conductance_percent, ...
    raw_max_abs_conductance_percent, cal_max_abs_conductance_percent, ...
    'VariableNames', {'test_index', 'row_input', 'rowBitsBinary', ...
    'rowBits', 'active_count', 'auto_rf_accept_reason', ...
    'auto_rf_attempts', 'raw_MAPE_current_percent', ...
    'calibrated_MAPE_current_percent', 'raw_MaxAPE_current_percent', ...
    'calibrated_MaxAPE_current_percent', 'raw_MAPE_conductance_percent', ...
    'calibrated_MAPE_conductance_percent', ...
    'raw_MaxAPE_conductance_percent', ...
    'calibrated_MaxAPE_conductance_percent'});
end

function usage = summarizeCalibrationRfUse(T)
if isempty(T) || ~istable(T)
    usage = table();
    return;
end

actual = T.rf_ohm;
nominal = T.readout_cal_rf_nominal_ohm;
applied = T.readout_cal_applied;
channels = T.col0;
keys = unique([actual(:), nominal(:)], 'rows');

rows = cell(size(keys, 1), 1);
for k = 1:size(keys, 1)
    actualMatch = actual == keys(k, 1) | (isnan(actual) & isnan(keys(k, 1)));
    nominalMatch = nominal == keys(k, 2) | (isnan(nominal) & isnan(keys(k, 2)));
    mask = actualMatch & nominalMatch;
    actual_rf_ohm = keys(k, 1);
    calibration_rf_ohm = keys(k, 2);
    num_points = nnz(mask);
    num_calibrated = nnz(mask & applied);
    channel_list = strjoin(string(unique(channels(mask)).'), " ");
    rows{k} = table(actual_rf_ohm, calibration_rf_ohm, num_points, ...
        num_calibrated, string(channel_list), 'VariableNames', ...
        {'actual_rf_ohm', 'calibration_rf_ohm', 'num_points', ...
        'num_calibrated', 'channels0'});
end

usage = vertcat(rows{:});
end

function activeCounts = countActiveBitsLocal(rowInputs)
rowInputs = string(rowInputs(:));
activeCounts = zeros(numel(rowInputs), 1);
for k = 1:numel(rowInputs)
    bits = char(rowInputs(k));
    activeCounts(k) = sum(bits == '1');
end
end

function cleanupDevice(dev, packetAverageCount, rfName)
try
    dev.restoreDefaultReadoutState(packetAverageCount, rfName);
catch
end
try
    dev.disconnect();
catch
end
end
