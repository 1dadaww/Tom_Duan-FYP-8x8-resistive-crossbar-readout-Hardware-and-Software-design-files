%% Example 06 - VHALF iterative reconstruction using TIA/channel calibration
%
% Complete TIA-calibrated VHALF workflow using the diagonal-board channel
% calibration from example 03:
%   calibration_index/latest_multi_rf_delta_v_calibration.mat
%
% Processing sequence:
%   1. Run a guarded VHALF scan.
%   2. Apply TIA/channel current calibration from example 03.
%   3. Run the iterative VHALF selected-cell reconstruction.
clear; clc; close all;

projectRoot = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(projectRoot, 'src'));
add_basic_paths();

% User configuration:
portName = "COM3";
packetAverageCount = 1;
averageCount = 1;
readoutVCM = 1.65;
readoutVREAD = 0.1;
readoutVSEL = readoutVCM + readoutVREAD;

% TIA calibration can support multiple RF ranges if example 03 has calibrated
% them. Fixed 10k is the default here to make comparison with 10k arrays clear.
rfControlMode = "auto";   % "fixed" or "auto"
autoRangeStartRF = "100k";
fixedRF = "100k";

% Optional known selected-cell value for iterative error plot. Set [] to skip.
knownSelectedCellOhmForError = [];

% Guard/switch settings.
rowResetDelay_s = 0.05;
retryLowLimitV = 0.06;
retryHighLimitV = 0.90;
maxCellRetryAttempts = 12;
retryPause_s = 0.05;
firstCellStartRF = autoRangeStartRF;
firstCellSettle_s = 1.0;
firstCellMaxAttempts = 6;
firstCellRetryPause_s = 0.05;
firstCellStableRelTol = 0.02;
rowExtraGuardRows0 = 0:7;
rowExtraGuardDiscardCount = 10;
rowExtraGuardPause_s = 0.02;
firstColumnCorrectionRows0 = 0:7;
firstColumnCorrectionCols0 = zeros(size(firstColumnCorrectionRows0));
firstColumnCorrectionPause_s = 0.05;

% Fixed-RF mode settings.
fixedManualDiscardCount = 3;
fixedManualDiscardPause_s = 0.05;

% Iterative reconstruction settings.
initialGuessSource = "apparent"; % "apparent" or "uniform"
uniformInitialR_ohm = 10000;
maxIterations = 1000;
relaxation = 0.20;
tolerance = 1e-7;
enforcePositive = true;
conductanceFloor_s = 1e-12;

% "none" keeps readings from RF ranges absent from the TIA calibration index
% as NaN.
calibrationFallback = "none";

rfControlMode = lower(convertCharsToStrings(rfControlMode));
if rfControlMode ~= "auto" && rfControlMode ~= "fixed"
    error("Example06:InvalidRFControl", "rfControlMode must be auto or fixed.");
end
if readoutVSEL <= readoutVCM
    error("Example06:InvalidBias", "readoutVSEL must be greater than readoutVCM.");
end

primaryCalibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_multi_rf_delta_v_calibration.mat");
legacyCalibrationIndexPath = fullfile(projectRoot, "calibration_index", ...
    "latest_single_rf_3k3_delta_v_calibration.mat");
calibrationIndexPath = chooseCalibrationIndexPath(primaryCalibrationIndexPath, ...
    legacyCalibrationIndexPath);
if ~exist(calibrationIndexPath, 'file')
    error("Example06:MissingCalibration", ...
        "TIA/channel calibration index not found. Run example_03_single_rf_calibration.m first.\nExpected: %s", ...
        primaryCalibrationIndexPath);
end

loaded = load(calibrationIndexPath);
readoutModel = loaded.readoutModel;
unusedGlobalFields = {'globalGain', 'globalOffset_a'};
for k = 1:numel(unusedGlobalFields)
    if isfield(readoutModel, unusedGlobalFields{k})
        readoutModel = rmfield(readoutModel, unusedGlobalFields{k});
    end
end
parameterTable = basic_delta_v_model_table(readoutModel);

resultBaseName = "vhalf_" + rfControlMode + "_tia_calibrated_iterative";
resultFolder = create_result_folder(resultBaseName + "_basic");

dev = BasicArrayReader(portName, 115200);
dev.connect();
cleanupObj = onCleanup(@() dev.disconnect());

dev.DefaultReadoutVCM = readoutVCM;
dev.DefaultReadoutVSEL = readoutVSEL;
if rfControlMode == "auto"
    dev.restoreDefaultReadoutState(packetAverageCount, autoRangeStartRF);
else
    dev.restoreDefaultReadoutState(packetAverageCount, fixedRF);
end
status = dev.getStatus();

fprintf("Loaded TIA/channel calibration index:\n%s\n", calibrationIndexPath);
fprintf("Calibration RF values / ohm: %s\n", mat2str(readoutModel.rfValues(:).'));
fprintf("Requested VCM %.6f V, VSEL %.6f V, VREAD %.6f V\n", ...
    readoutVCM, readoutVSEL, readoutVREAD);
fprintf("Using STATUS VCM %.6f V, VSEL %.6f V, VREAD %.6f V, VHALF %.6f V\n", ...
    status.VCM, status.VSEL, status.VREAD, status.VHALF);
fprintf("VHALF RF control: %s; calibration source: example 03 TIA/channel model\n", ...
    char(rfControlMode));

write_table_compatible(parameterTable, ...
    fullfile(resultFolder, "loaded_tia_channel_gain_offset_parameters.csv"));

dev.setDefaultReadoutBias();
fprintf("Running guarded VHALF scan, then applying TIA/channel calibration...\n");
scanVhalfRaw = runGuardedVhalfScan(dev, rfControlMode, autoRangeStartRF, ...
    fixedRF, rowResetDelay_s, averageCount, retryLowLimitV, ...
    retryHighLimitV, maxCellRetryAttempts, retryPause_s, firstCellStartRF, ...
    firstCellSettle_s, firstCellMaxAttempts, firstCellRetryPause_s, ...
    firstCellStableRelTol, rowExtraGuardRows0, rowExtraGuardDiscardCount, ...
    rowExtraGuardPause_s, firstColumnCorrectionRows0, ...
    firstColumnCorrectionCols0, firstColumnCorrectionPause_s, ...
    fixedManualDiscardCount, fixedManualDiscardPause_s);

save_scan_outputs(scanVhalfRaw, resultFolder, "vhalf_raw");
saveOptionalRawTables(scanVhalfRaw, resultFolder, "vhalf");

vhalfTiaCal = apply_basic_delta_v_calibration_model(scanVhalfRaw, readoutModel, ...
    "deltaV", status.VREAD, "fallback", calibrationFallback, ...
    "numRows", dev.NumRows, "numCols", dev.NumCols);
vhalfRfUsageTable = summarizeCalibrationRfUse(vhalfTiaCal.table);
write_table_compatible(vhalfRfUsageTable, ...
    fullfile(resultFolder, "vhalf_tia_rf_calibration_usage.csv"));
disp("VHALF actual RF to TIA calibration RF usage:");
disp(vhalfRfUsageTable);
if any(~vhalfTiaCal.table.readout_cal_applied)
    warning("Example06:UncalibratedVhalfRF", ...
        "Some VHALF cells used an RF range not present in the TIA/channel calibration model.");
end

scanVhalfTiaCal = makeCalibratedCurrentScan(scanVhalfRaw, vhalfTiaCal, ...
    status.VREAD, "VHALF current calibrated with example 03 TIA/channel model");
reconVhalfApparentTiaCal = reconstruct_from_scan(scanVhalfTiaCal, "current", ...
    "Vread", status.VREAD, "mode", "VHALF");

initialR_ohm = chooseInitialResistance(scanVhalfTiaCal, initialGuessSource, ...
    uniformInitialR_ohm);
reconIterative = reconstruct_vhalf_iterative(scanVhalfTiaCal, ...
    "Vread", status.VREAD, ...
    "Vcm", status.VCM, ...
    "Vhalf", status.VHALF, ...
    "initialR_ohm", initialR_ohm, ...
    "maxIterations", maxIterations, ...
    "relaxation", relaxation, ...
    "tolerance", tolerance, ...
    "enforcePositive", enforcePositive, ...
    "conductanceFloor_s", conductanceFloor_s, ...
    "numRows", dev.NumRows, ...
    "numCols", dev.NumCols);

write_table_compatible(vhalfTiaCal.table, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_current_table.csv"));
write_table_compatible(scanVhalfTiaCal.table, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_current_scan_table_for_iterative_reconstruction.csv"));
write_table_compatible(reconIterative.table, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_reconstructed_table.csv"));
write_table_compatible(reconIterative.history, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_convergence_history.csv"));

writematrix(scanVhalfRaw.matrices.R_ohm, ...
    fullfile(resultFolder, "vhalf_raw_apparent_equivalent_R_ohm.csv"));
writematrix(vhalfTiaCal.matrices.R_readout_calibrated_ohm, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_apparent_equivalent_R_ohm.csv"));
writematrix(vhalfTiaCal.matrices.current_readout_calibrated_a, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_current_a.csv"));
writematrix(reconIterative.R_ohm, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_R_ohm.csv"));
writematrix(reconIterative.G_selected_s, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_selected_G_s.csv"));
writematrix(reconIterative.G_sneak_est_s, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_estimated_sneak_G_s.csv"));
writematrix(reconIterative.G_residual_s, ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_residual_G_s.csv"));

plot_matrix_heatmap(scanVhalfRaw.matrices.R_ohm, ...
    "VHALF raw apparent/equivalent resistance / ohm", ...
    fullfile(resultFolder, "vhalf_raw_apparent_equivalent_R_map.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(vhalfTiaCal.matrices.R_readout_calibrated_ohm, ...
    "VHALF TIA-calibrated apparent/equivalent resistance / ohm", ...
    fullfile(resultFolder, "vhalf_tia_calibrated_apparent_equivalent_R_map.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(vhalfTiaCal.matrices.R_readout_calibrated_ohm, ...
    "VHALF TIA-calibrated apparent/equivalent decimal / ohm", ...
    fullfile(resultFolder, "vhalf_tia_calibrated_apparent_equivalent_R_map_decimal.png"), ...
    "logScale", false, "colorbarLabel", "ohm", "showText", true);
plot_matrix_heatmap(reconIterative.R_ohm, ...
    "VHALF TIA-calibrated iterative reconstructed resistance / ohm", ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_R_map.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)", "showText", true);
plot_matrix_heatmap(reconIterative.R_ohm, ...
    "VHALF TIA-calibrated iterative reconstructed decimal / ohm", ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_R_map_decimal.png"), ...
    "logScale", false, "colorbarLabel", "ohm", "showText", true);
plot_matrix_heatmap(abs(reconIterative.G_residual_s), ...
    "VHALF TIA-calibrated iterative absolute residual conductance / S", ...
    fullfile(resultFolder, "vhalf_tia_calibrated_iterative_abs_residual_G_map.png"), ...
    "logScale", false, "colorbarLabel", "S");

if ~isempty(knownSelectedCellOhmForError)
    iterativeErrorPercent = 100 .* ...
        (reconIterative.R_ohm - knownSelectedCellOhmForError) ./ ...
        knownSelectedCellOhmForError;
    writematrix(iterativeErrorPercent, ...
        fullfile(resultFolder, "vhalf_tia_calibrated_iterative_error_percent_vs_known.csv"));
    plot_matrix_heatmap(iterativeErrorPercent, ...
        "VHALF TIA-calibrated iterative error vs known / %", ...
        fullfile(resultFolder, "vhalf_tia_calibrated_iterative_error_percent_heatmap.png"), ...
        "logScale", false, "colorbarLabel", "%", "showText", true);
end

save(fullfile(resultFolder, "vhalf_tia_calibrated_iterative_outputs.mat"), ...
    "scanVhalfRaw", "vhalfTiaCal", "scanVhalfTiaCal", ...
    "reconVhalfApparentTiaCal", "reconIterative", "initialR_ohm", ...
    "readoutModel", "parameterTable", "calibrationIndexPath", "status", ...
    "rfControlMode", "calibrationFallback", "knownSelectedCellOhmForError", ...
    "autoRangeStartRF", "fixedRF", "rowResetDelay_s", ...
    "retryLowLimitV", "retryHighLimitV", "maxCellRetryAttempts", ...
    "retryPause_s", "firstCellStartRF", "firstCellSettle_s", ...
    "firstCellMaxAttempts", "firstCellRetryPause_s", ...
    "firstCellStableRelTol", "rowExtraGuardRows0", ...
    "rowExtraGuardDiscardCount", "rowExtraGuardPause_s", ...
    "firstColumnCorrectionRows0", "firstColumnCorrectionCols0", ...
    "firstColumnCorrectionPause_s", "fixedManualDiscardCount", ...
    "fixedManualDiscardPause_s", "readoutVCM", "readoutVSEL", ...
    "readoutVREAD", "maxIterations", "relaxation", "tolerance", ...
    "enforcePositive", "conductanceFloor_s", "initialGuessSource", ...
    "uniformInitialR_ohm");

disp("Iterative convergence summary:");
disp(reconIterative.history(end, :));
fprintf("Converged: %d after %d iteration(s)\n", ...
    reconIterative.converged, reconIterative.iterationsUsed);
fprintf("Saved VHALF TIA-calibrated iterative outputs to:\n%s\n", resultFolder);

function scan = runGuardedVhalfScan(dev, rfControlMode, autoStartRF, fixedRF, ...
        rowResetDelay_s, averageCount, lowLimitV, highLimitV, ...
        maxCellAttempts, retryPause_s, firstCellStartRF, firstCellSettle_s, ...
        firstCellMaxAttempts, firstCellRetryPause_s, firstCellStableRelTol, ...
        rowExtraGuardRows0, rowExtraGuardDiscardCount, rowExtraGuardPause_s, ...
        postRowRereadRows0, postRowRereadCols0, postRowRereadPause_s, ...
        fixedManualDiscardCount, fixedManualDiscardPause_s)
rfControlMode = lower(string(rfControlMode));

if rfControlMode == "auto"
    scan = scan_cell_auto_retry_in_window(dev, ...
        "mode", "VHALF", ...
        "startRF", autoStartRF, ...
        "rowResetDelay_s", rowResetDelay_s, ...
        "averageCount", averageCount, ...
        "lowLimit_v", lowLimitV, ...
        "highLimit_v", highLimitV, ...
        "maxCellAttempts", maxCellAttempts, ...
        "retryPause_s", retryPause_s, ...
        "firstCellStartRF", firstCellStartRF, ...
        "firstCellSettle_s", firstCellSettle_s, ...
        "firstCellMaxAttempts", firstCellMaxAttempts, ...
        "firstCellRetryPause_s", firstCellRetryPause_s, ...
        "firstCellStableRelTol", firstCellStableRelTol, ...
        "rowExtraGuardRows0", rowExtraGuardRows0, ...
        "rowExtraGuardDiscardCount", rowExtraGuardDiscardCount, ...
        "rowExtraGuardPause_s", rowExtraGuardPause_s, ...
        "postRowRereadRows0", postRowRereadRows0, ...
        "postRowRereadCols0", postRowRereadCols0, ...
        "postRowRereadPause_s", postRowRereadPause_s);
else
    scan = scanFixedRfByCell(dev, "VHALF", fixedRF, rowResetDelay_s, ...
        averageCount, fixedManualDiscardCount, fixedManualDiscardPause_s, ...
        rowExtraGuardRows0, rowExtraGuardDiscardCount, rowExtraGuardPause_s, ...
        postRowRereadRows0, postRowRereadCols0, postRowRereadPause_s);
end
end

function scanCal = makeCalibratedCurrentScan(scanRaw, calibrated, deltaV, sourceLabel)
scanCal = scanRaw;
T = calibrated.table;
T.vadc_raw_v = T.vadc_v;
T.current_raw_a = T.current_a;
T.r_raw_ohm = T.r_ohm;
T.current_a = T.current_readout_calibrated_a;
T.vadc_v = T.current_a .* T.rf_ohm;
T.r_ohm = deltaV ./ T.current_a;
T.r_ohm(~isfinite(T.r_ohm) | T.r_ohm <= 0) = nan;
T.reconstruction_current_source = repmat(string(sourceLabel), height(T), 1);

scanCal.table = T;
numRows = max(T.row);
numCols = max(T.col);
scanCal.matrices = BasicArrayReader.tableToMatrices(T, numRows, numCols);
scanCal.matrices.R_ohm = calibrated.matrices.R_readout_calibrated_ohm;
scanCal.matrices.current_a = calibrated.matrices.current_readout_calibrated_a;
scanCal.header.calibrated_current_used_for_iterative_reconstruction = true;
scanCal.header.reconstruction_current_source = string(sourceLabel);
end

function initialR = chooseInitialResistance(scanVhalfCal, initialGuessSource, uniformInitialR)
initialGuessSource = lower(string(initialGuessSource));
switch initialGuessSource
    case "apparent"
        initialR = scanVhalfCal.matrices.R_ohm;
    case "uniform"
        validateattributes(uniformInitialR, {'numeric'}, ...
            {'scalar', 'real', 'finite', 'positive'});
        initialR = uniformInitialR .* ones(8, 8);
    otherwise
        error("Example06:InvalidInitialGuess", ...
            "initialGuessSource must be apparent or uniform.");
end
end

function saveOptionalRawTables(scan, resultFolder, baseName)
if isfield(scan, "rawRetryTable")
    write_table_compatible(scan.rawRetryTable, ...
        fullfile(resultFolder, baseName + "_raw_retry_table.csv"));
end
if isfield(scan, "rawFixedTrialTable")
    write_table_compatible(scan.rawFixedTrialTable, ...
        fullfile(resultFolder, baseName + "_fixed_raw_trial_table.csv"));
end
end

function scan = scanFixedRfByCell(dev, mode, fixedRF, rowResetDelay_s, ...
        averageCount, discardCount, discardPause_s, rowGuardRows0, ...
        rowGuardDiscardCount, rowGuardPause_s, postRowRereadRows0, ...
        postRowRereadCols0, postRowRereadPause_s)
mode = upper(string(mode));
fixedRF = string(fixedRF);
rowGuardRows0 = unique(reshape(double(rowGuardRows0), 1, []));
postRowRereadRows0 = reshape(double(postRowRereadRows0), 1, []);
postRowRereadCols0 = reshape(double(postRowRereadCols0), 1, []);
if numel(postRowRereadRows0) ~= numel(postRowRereadCols0)
    error("Example06:PostRowRereadSize", ...
        "postRowRereadRows0 and postRowRereadCols0 must have the same length.");
end
validateattributes(averageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});
discardCount = round(discardCount);
rowGuardDiscardCount = round(rowGuardDiscardCount);
discardPause_s = max(0, discardPause_s);
rowGuardPause_s = max(0, rowGuardPause_s);
postRowRereadPause_s = max(0, postRowRereadPause_s);

dev.setDefaultReadoutBias();
dev.setRF(fixedRF);
if rowResetDelay_s > 0
    pause(rowResetDelay_s);
end
status = dev.getStatus();

dataRows = cell(dev.NumRows * dev.NumCols, 1);
trialRows = cell(dev.NumRows * dev.NumCols, 1);
idx = 0;
for row0 = 0:dev.NumRows-1
    dev.setDefaultReadoutBias();
    dev.setRF(fixedRF);
    if rowResetDelay_s > 0
        pause(rowResetDelay_s);
    end

    for col0 = 0:dev.NumCols-1
        idx = idx + 1;
        [T, trials] = readFixedCell(dev, row0, col0, mode, fixedRF, ...
            averageCount, discardCount, discardPause_s, rowGuardRows0, ...
            rowGuardDiscardCount, rowGuardPause_s);
        T = tagAcceptedFixedCell(T, fixedRF, rowResetDelay_s, rowGuardRows0, ...
            rowGuardDiscardCount, rowGuardPause_s, postRowRereadRows0, ...
            postRowRereadCols0, postRowRereadPause_s, false, nan, ...
            "CELL_" + mode + "_FIXED_RF");
        dataRows{idx} = T;
        trialRows{idx} = trials;

        fprintf("row0 %d col0 %d | fixed RF %s | Vadc %.6g V | R %.6g ohm | %s\n", ...
            row0, col0, char(fixedRF), T.vadc_v(1), T.r_ohm(1), char(T.status(1)));
    end

    postTargets = find(postRowRereadRows0 == row0);
    for kk = 1:numel(postTargets)
        targetCol0 = postRowRereadCols0(postTargets(kk));
        if targetCol0 < 0 || targetCol0 >= dev.NumCols
            error("Example06:InvalidPostRowRereadCell", ...
                "post-row reread col0 %g is outside 0..%d.", targetCol0, dev.NumCols - 1);
        end

        targetIdx = row0 * dev.NumCols + targetCol0 + 1;
        if postRowRereadPause_s > 0
            pause(postRowRereadPause_s);
        end

        fprintf("Post-row reread %s fixed-RF cell row0 %d col0 %d; replacing original value...\n", ...
            char(mode), row0, targetCol0);
        [Tpost, postTrials] = readFixedCell(dev, row0, targetCol0, mode, fixedRF, ...
            averageCount, discardCount, discardPause_s, rowGuardRows0, ...
            rowGuardDiscardCount, rowGuardPause_s);
        Tpost = tagAcceptedFixedCell(Tpost, fixedRF, rowResetDelay_s, ...
            rowGuardRows0, rowGuardDiscardCount, rowGuardPause_s, ...
            postRowRereadRows0, postRowRereadCols0, postRowRereadPause_s, ...
            true, dev.NumCols - 1, "CELL_" + mode + "_FIXED_RF_POST_ROW_REREAD");

        dataRows{targetIdx} = Tpost;
        trialRows{targetIdx} = vertcat(trialRows{targetIdx}, postTrials);
    end
end

Tscan = vertcat(dataRows{:});
scan = struct();
scan.command = "CELL_" + mode + "_FIXED_RF";
scan.beginLine = "";
scan.endLine = "";
scan.lines = strings(0, 1);
scan.table = Tscan;
scan.rawFixedTrialTable = vertcat(trialRows{:});
scan.matrices = BasicArrayReader.tableToMatrices(Tscan, dev.NumRows, dev.NumCols);
scan.mode = mode;
scan.autoRF = false;
scan.timestamp = datetime("now");
scan.header = struct("mode", mode + "_FIXED_RF", ...
    "numRows", dev.NumRows, "numCols", dev.NumCols, ...
    "VREAD", status.VREAD, "packet_avg", dev.PacketAverageCount, ...
    "fixed_rf_name", fixedRF, "row_reset_delay_s", rowResetDelay_s, ...
    "discard_count", discardCount, "discard_pause_s", discardPause_s, ...
    "row_extra_guard_rows0", rowGuardRows0, ...
    "row_extra_guard_discard_count", rowGuardDiscardCount, ...
    "row_extra_guard_pause_s", rowGuardPause_s, ...
    "post_row_reread_rows0", postRowRereadRows0, ...
    "post_row_reread_cols0", postRowRereadCols0, ...
    "post_row_reread_pause_s", postRowRereadPause_s);
end

function [accepted, rawTrials] = readFixedCell(dev, row0, col0, mode, fixedRF, ...
        averageCount, discardCount, discardPause_s, rowGuardRows0, ...
        rowGuardDiscardCount, rowGuardPause_s)
rawRows = {};

if rowGuardDiscardCount > 0 && ismember(row0, rowGuardRows0)
    for k = 1:rowGuardDiscardCount
        Tguard = dev.readCell(row0, col0, mode, false);
        Tguard = tagFixedTrial(Tguard, fixedRF, "row_extra_guard_discard", k);
        rawRows{end+1, 1} = Tguard; %#ok<AGROW>
        if rowGuardPause_s > 0
            pause(rowGuardPause_s);
        end
    end
end

for k = 1:discardCount
    Tdiscard = dev.readCell(row0, col0, mode, false);
    Tdiscard = tagFixedTrial(Tdiscard, fixedRF, "manual_discard", k);
    rawRows{end+1, 1} = Tdiscard; %#ok<AGROW>
    if discardPause_s > 0
        pause(discardPause_s);
    end
end

candidateRows = cell(averageCount, 1);
for rep = 1:averageCount
    T = dev.readCell(row0, col0, mode, false);
    T = tagFixedTrial(T, fixedRF, "candidate", rep);
    T.average_repeat_index = repmat(rep, height(T), 1);
    candidateRows{rep} = T;
    rawRows{end+1, 1} = T; %#ok<AGROW>
end

if averageCount == 1
    accepted = candidateRows{1};
else
    accepted = BasicArrayReader.averageDataRows(vertcat(candidateRows{:}));
end
accepted.average_count = repmat(averageCount, height(accepted), 1);
accepted.fixed_read_total_trial_rows = repmat(numel(rawRows), height(accepted), 1);
accepted.fixed_rf_name = repmat(fixedRF, height(accepted), 1);
accepted.rf_control_mode = repmat("fixed", height(accepted), 1);
rawTrials = vertcat(rawRows{:});
end

function T = tagAcceptedFixedCell(T, fixedRF, rowResetDelay_s, rowGuardRows0, ...
        rowGuardDiscardCount, rowGuardPause_s, postRows0, postCols0, ...
        postPause_s, wasPostReread, postAfterCol0, scanMethod)
T.fixed_rf_name = repmat(string(fixedRF), height(T), 1);
T.rf_control_mode = repmat("fixed", height(T), 1);
T.row_reset_delay_s = repmat(rowResetDelay_s, height(T), 1);
T.row_extra_guard_rows0 = repmat(rowListLabelLocal(rowGuardRows0), height(T), 1);
T.row_extra_guard_discard_count_setting = repmat(rowGuardDiscardCount, height(T), 1);
T.row_extra_guard_pause_s = repmat(rowGuardPause_s, height(T), 1);
T.post_row_reread_target_cells = repmat(cellListLabelLocal(postRows0, postCols0), ...
    height(T), 1);
T.post_row_reread_replaced_value = repmat(logical(wasPostReread), height(T), 1);
T.post_row_reread_after_col0 = repmat(postAfterCol0, height(T), 1);
T.post_row_reread_pause_s = repmat(postPause_s, height(T), 1);
T.scan_method = repmat(string(scanMethod), height(T), 1);
end

function T = tagFixedTrial(T, fixedRF, role, index)
T.fixed_rf_name = repmat(string(fixedRF), height(T), 1);
T.rf_control_mode = repmat("fixed", height(T), 1);
T.fixed_trial_role = repmat(string(role), height(T), 1);
T.fixed_trial_index = repmat(index, height(T), 1);
T.average_repeat_index = nan(height(T), 1);
end

function label = rowListLabelLocal(rows0)
if isempty(rows0)
    label = "";
else
    label = strjoin(string(rows0), ";");
end
end

function label = cellListLabelLocal(rows0, cols0)
if isempty(rows0)
    label = "";
    return;
end

parts = strings(numel(rows0), 1);
for k = 1:numel(rows0)
    parts(k) = string(rows0(k)) + "," + string(cols0(k));
end
label = strjoin(parts, ";");
end

function calibrationIndexPath = chooseCalibrationIndexPath(primaryPath, legacyPath)
if exist(primaryPath, 'file')
    calibrationIndexPath = primaryPath;
elseif exist(legacyPath, 'file')
    calibrationIndexPath = legacyPath;
else
    calibrationIndexPath = primaryPath;
end
end

function summary = summarizeCalibrationRfUse(T)
actualRf = T.readout_cal_rf_actual_ohm;
matchedRf = T.readout_cal_rf_nominal_ohm;
applied = logical(T.readout_cal_applied);

actualLabel = compose("%.12g", actualRf);
matchedLabel = compose("%.12g", matchedRf);
matchedLabel(~isfinite(matchedRf)) = "uncalibrated";

[groups, rfActualLabel, rfMatchedLabel] = findgroups(actualLabel, matchedLabel);
numCells = splitapply(@numel, applied, groups);
numCalibrated = splitapply(@sum, applied, groups);
numUncalibrated = numCells - numCalibrated;
rfActual = str2double(rfActualLabel);
rfMatched = str2double(rfMatchedLabel);

summary = table(rfActual, rfMatched, numCells, numCalibrated, numUncalibrated, ...
    'VariableNames', {'actual_rf_ohm', 'matched_tia_calibration_rf_ohm', ...
    'num_cells', 'num_calibrated', 'num_uncalibrated'});
end
