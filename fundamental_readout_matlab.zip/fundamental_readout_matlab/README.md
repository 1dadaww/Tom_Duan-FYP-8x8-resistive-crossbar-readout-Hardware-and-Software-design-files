# Fundamental Readout MATLAB

MATLAB interface and example workflows for the ESP32-controlled 8x8
selectorless resistive-array readout system.

## Requirements

- MATLAB R2022 or later
- Instrument Control Toolbox
- ESP32 firmware supplied in the accompanying `esp32_firmware` folder
- USB serial connection at 115200 baud

Set the serial port and measurement parameters in the configuration section at
the beginning of each example script.

## Examples

1. `example_01_connect_status_i2c.m` checks serial communication, firmware
   status, I2C devices, and feedback-resistor state.
2. `example_02_read_single_cell.m` performs raw or calibrated single-cell
   measurements with fixed or automatic feedback selection.
3. `example_03_single_rf_calibration.m` calibrates one feedback range across
   all eight channels using a diagonal known-resistor board.
4. `example_04_full_scan_direct_calibrated.m` performs calibrated DIRECT or
   VHALF full-array scans with fixed or automatic feedback selection.
5. `example_05_vhalf_iterative_reconstruction_from_saved_example06.m`
   analyses iterative VHALF reconstruction from a saved calibrated scan.
6. `example_06_vhalf_tia_calibrated_iterative_test.m` acquires a calibrated
   VHALF scan and reconstructs selected-cell resistance iteratively.
7. `example_07_binary_vmm_calibrated_auto_rf.m` performs calibrated binary
   vector-matrix multiplication and compares it with a defined reference array.
8. `example_08_vhalf_iterative_stage_demonstration.m` plots selected stages of
   the VHALF reconstruction process.
9. `example_09_mixed_array_vcm_vhalf_analysis.m` compares VCM-biased and VHALF
   results for a defined mixed-resistance array.
10. `example_10_noise_readout_app.m` launches the ADC noise and resolution app
    with block capture, streaming, histogram, FFT, and effective-bit analysis.

## Folders

- `scripts/`: executable examples
- `src/`: serial interface, calibration, reconstruction, plotting, and saving
- `calibration_index/`: saved per-channel and per-feedback calibration models
- `results/`: generated outputs from the most recent run of each example

## Default Readout Bias

- `VCM = 1.65 V`
- `VSEL = 1.75 V`
- `VHALF = 1.70 V`
- `VREAD = 0.10 V`

Measurement scripts restore the default readout state before acquisition using
the firmware `SETAVG`, `BIAS`, and optional `RF` commands.
