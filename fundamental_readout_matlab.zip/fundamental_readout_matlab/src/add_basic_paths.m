function add_basic_paths()
%ADD_BASIC_PATHS Add this minimal readout folder to the MATLAB path.

root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src'));
addpath(fullfile(root, 'scripts'));

end

