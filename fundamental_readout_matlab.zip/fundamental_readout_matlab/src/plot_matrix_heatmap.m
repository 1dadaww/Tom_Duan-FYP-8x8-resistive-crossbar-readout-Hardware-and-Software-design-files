function h = plot_matrix_heatmap(M, plotTitle, outputFile, varargin)
%PLOT_MATRIX_HEATMAP Plot and optionally save a matrix heatmap.

p = inputParser;
addParameter(p, "logScale", false);
addParameter(p, "xLabel", "Column");
addParameter(p, "yLabel", "Row");
addParameter(p, "colorbarLabel", "");
addParameter(p, "showText", false);
parse(p, varargin{:});
opt = p.Results;

data = M;
if opt.logScale
    data = log10(abs(M));
end

h = figure('Color', 'w');
imagesc(data);
axis image;
set(gca, 'YDir', 'normal');
xlabel(opt.xLabel);
ylabel(opt.yLabel);
title(plotTitle, 'Interpreter', 'none');
cb = colorbar;
if strlength(string(opt.colorbarLabel)) > 0
    ylabel(cb, opt.colorbarLabel, 'Interpreter', 'none');
elseif opt.logScale
    ylabel(cb, 'log10(value)');
end
xticks(1:size(M,2));
yticks(1:size(M,1));

if opt.showText
    for r = 1:size(M,1)
        for c = 1:size(M,2)
            if isfinite(M(r,c))
                text(c, r, sprintf('%.3g', M(r,c)), ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'middle', ...
                    'FontSize', 8);
            end
        end
    end
end

if nargin >= 3 && ~isempty(outputFile)
    [folder, ~, ~] = fileparts(outputFile);
    if strlength(string(folder)) > 0 && ~exist(folder, 'dir')
        mkdir(folder);
    end
    exportgraphics(h, outputFile, 'Resolution', 300);
    savefig(h, replace(outputFile, ".png", ".fig"));
end

end

