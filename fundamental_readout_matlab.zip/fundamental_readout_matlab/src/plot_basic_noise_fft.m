function plot_basic_noise_fft(fftOut, ax, plotTitle)
%PLOT_BASIC_NOISE_FFT Plot a single-sided noise spectrum.

if nargin < 2 || isempty(ax)
    figure('Color', 'w');
    ax = axes();
end
if nargin < 3 || strlength(string(plotTitle)) == 0
    plotTitle = "Noise FFT: " + string(fftOut.metric);
end

plot(ax, fftOut.table.freq_hz, fftOut.table.amplitude, "-");
grid(ax, "on");
xlabel(ax, "Frequency / Hz");
ylabel(ax, "Amplitude");
title(ax, plotTitle, 'Interpreter', 'none');
xlim(ax, [0, fftOut.nyquist_hz]);
end
