function fftOut = compute_basic_noise_fft(T, metric)
%COMPUTE_BASIC_NOISE_FFT Single-sided FFT from timestamped noise samples.

if nargin < 2 || strlength(string(metric)) == 0
    metric = "vadc_v";
end
metric = string(metric);
if isempty(T) || height(T) < 4
    error("compute_basic_noise_fft:NotEnoughSamples", ...
        "At least four samples are required.");
end
if ~ismember(metric, string(T.Properties.VariableNames))
    error("compute_basic_noise_fft:MissingMetric", ...
        "Sample table does not contain '%s'.", metric);
end

y = double(T.(metric));
t = double(T.timestamp_us) .* 1e-6;
valid = isfinite(y) & isfinite(t);
y = y(valid);
t = t(valid);
dt = diff(t);
dt = dt(isfinite(dt) & dt > 0);
if numel(y) < 4 || isempty(dt)
    error("compute_basic_noise_fft:InvalidSamples", ...
        "Finite samples with increasing timestamps are required.");
end

sampleRateHz = 1 ./ median(dt);
timestampJitterS = std(dt, "omitnan");
y = y - mean(y, "omitnan");
N = numel(y);
window = 0.5 - 0.5 .* cos(2 .* pi .* (0:N-1)' ./ (N-1));
coherentGain = mean(window);
spectrum = fft(y(:) .* window);
amplitude = abs(spectrum(1:floor(N/2)+1)) ./ (N .* coherentGain);
if numel(amplitude) > 2
    amplitude(2:end-1) = 2 .* amplitude(2:end-1);
end
freq_hz = sampleRateHz .* (0:floor(N/2))' ./ N;
fftTable = table(freq_hz, amplitude);

nonDc = freq_hz > 0;
if any(nonDc)
    indices = find(nonDc);
    [peakAmplitude, relativeIndex] = max(amplitude(nonDc));
    peakFrequencyHz = freq_hz(indices(relativeIndex));
else
    peakAmplitude = nan;
    peakFrequencyHz = nan;
end

fftOut = struct("metric", metric, "table", fftTable, ...
    "sampleRate_hz", sampleRateHz, "numSamples", N, ...
    "frequencyResolution_hz", sampleRateHz ./ N, ...
    "nyquist_hz", sampleRateHz ./ 2, ...
    "timestampJitter_s", timestampJitterS, ...
    "peakFrequency_hz", peakFrequencyHz, ...
    "peakAmplitude", peakAmplitude);
end
