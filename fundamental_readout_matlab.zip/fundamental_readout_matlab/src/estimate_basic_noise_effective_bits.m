function metrics = estimate_basic_noise_effective_bits(T, adcBits)
%ESTIMATE_BASIC_NOISE_EFFECTIVE_BITS Estimate noise-free effective bits.

if nargin < 2 || isempty(adcBits)
    adcBits = 24;
end
if isempty(T) || ~ismember("adc_raw", string(T.Properties.VariableNames))
    error("estimate_basic_noise_effective_bits:MissingRawADC", ...
        "Input table must contain adc_raw.");
end

adcRaw = double(T.adc_raw);
adcRaw = adcRaw(isfinite(adcRaw));
if numel(adcRaw) < 2
    rmsNoiseCodes = nan;
    effectiveBits = nan;
else
    rmsNoiseCodes = std(adcRaw, "omitnan");
    if rmsNoiseCodes > 0
        effectiveBits = log2((2 ^ adcBits) ./ ...
            (sqrt(12) .* rmsNoiseCodes));
    elseif rmsNoiseCodes == 0
        effectiveBits = inf;
    else
        effectiveBits = nan;
    end
end

metrics = struct("adcBitsAssumed", adcBits, ...
    "rmsNoiseCodes", rmsNoiseCodes, "effectiveBits", effectiveBits);
end
