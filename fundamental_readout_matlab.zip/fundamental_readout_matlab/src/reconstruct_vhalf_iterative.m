function recon = reconstruct_vhalf_iterative(vhalfScanOrTable, varargin)
%RECONSTRUCT_VHALF_ITERATIVE Iteratively reconstruct VHALF selected cells.
%
% Model for each selected row r and column c:
%
%   Gtotal_measured(r,c) = Gselected(r,c)
%       + alpha * sum(Gselected(other rows, c))
%
% where alpha = (VHALF - VCM) / VREAD. The algorithm updates the selected
% conductance estimate by repeatedly subtracting the sneak conductance
% predicted from the previous estimate.

p = inputParser;
addParameter(p, "Vread", []);
addParameter(p, "Vcm", []);
addParameter(p, "Vhalf", []);
addParameter(p, "halfSelectFactor", []);
addParameter(p, "initialR_ohm", []);
addParameter(p, "numRows", 8);
addParameter(p, "numCols", 8);
addParameter(p, "maxIterations", 200);
addParameter(p, "relaxation", 0.20);
addParameter(p, "tolerance", 1e-7);
addParameter(p, "enforcePositive", true);
addParameter(p, "conductanceFloor_s", 1e-12);
addParameter(p, "validStatuses", ["OK", "LOW_SIGNAL", "HIGH_SIGNAL", "MIN_RF_LIMIT", "MAX_RF_LIMIT"]);
parse(p, varargin{:});
opt = p.Results;

if istable(vhalfScanOrTable)
    T = vhalfScanOrTable;
    scan = struct();
elseif isstruct(vhalfScanOrTable) && isfield(vhalfScanOrTable, "table")
    scan = vhalfScanOrTable;
    T = scan.table;
else
    error("reconstruct_vhalf_iterative:InvalidInput", ...
        "First input must be a VHALF scan struct or scan table.");
end

Vread = resolveVread(opt.Vread, scan);
alpha = resolveHalfSelectFactor(opt.halfSelectFactor, opt.Vcm, opt.Vhalf, Vread);
validateattributes(opt.maxIterations, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1});
validateattributes(opt.relaxation, {'numeric'}, ...
    {'scalar', 'real', 'finite', '>', 0, '<=', 1});
validateattributes(opt.tolerance, {'numeric'}, ...
    {'scalar', 'real', 'finite', '>', 0});
validateattributes(opt.conductanceFloor_s, {'numeric'}, ...
    {'scalar', 'real', 'finite', '>=', 0});

[Ymeas, validMatrix, currentMatrix] = measuredConductanceMatrix( ...
    T, Vread, opt.numRows, opt.numCols, opt.validStatuses);
G = initialConductanceMatrix(opt.initialR_ohm, Ymeas, alpha, ...
    opt.numRows, opt.numCols, opt.conductanceFloor_s);

history = table('Size', [0, 4], ...
    'VariableTypes', {'double', 'double', 'double', 'double'}, ...
    'VariableNames', {'iteration', 'max_relative_change', ...
    'max_relative_residual', 'rms_relative_residual'});

for iter = 1:opt.maxIterations
    Gold = G;
    colSum = localSumOmitNan(G, 1);
    Gtarget = Ymeas - alpha .* (repmat(colSum, opt.numRows, 1) - G);
    updateMask = validMatrix & isfinite(Gtarget);

    G(updateMask) = (1 - opt.relaxation) .* G(updateMask) + ...
        opt.relaxation .* Gtarget(updateMask);
    if opt.enforcePositive
        G(updateMask) = max(G(updateMask), opt.conductanceFloor_s);
    end

    [~, relResidualValues] = residualForModel(G, Ymeas, ...
        alpha, validMatrix);
    changeValues = abs(G(updateMask) - Gold(updateMask)) ./ ...
        max(abs(Gold(updateMask)), opt.conductanceFloor_s);

    maxRelChange = maxFinite(changeValues);
    maxRelResidual = maxFinite(relResidualValues);
    rmsRelResidual = rmsFinite(relResidualValues);
    history(end+1, :) = {iter, maxRelChange, maxRelResidual, rmsRelResidual}; %#ok<AGROW>

    if isfinite(maxRelResidual) && maxRelResidual <= opt.tolerance
        break;
    end
    if isfinite(maxRelChange) && maxRelChange <= opt.tolerance
        break;
    end
end

[residualMatrix, relResidualValues] = residualForModel(G, Ymeas, alpha, validMatrix);
Gclosed = closedFormConductance(Ymeas, alpha, opt.numRows, opt.numCols);
colSum = localSumOmitNan(G, 1);
Gsneak = alpha .* (repmat(colSum, opt.numRows, 1) - G);
Gpred = G + Gsneak;

R = nan(opt.numRows, opt.numCols);
validFinal = validMatrix & isfinite(G) & G > opt.conductanceFloor_s;
R(validFinal) = 1 ./ G(validFinal);

Rclosed = nan(opt.numRows, opt.numCols);
closedValid = isfinite(Gclosed) & Gclosed > 0;
Rclosed(closedValid) = 1 ./ Gclosed(closedValid);

T = appendIterativeColumns(T, G, R, Ymeas, residualMatrix, alpha, ...
    validFinal, opt.numRows, opt.numCols);

recon = struct();
recon.method = "vhalf_iterative";
recon.Vread = Vread;
recon.halfSelectFactor = alpha;
recon.relaxation = opt.relaxation;
recon.tolerance = opt.tolerance;
recon.maxIterations = opt.maxIterations;
recon.iterationsUsed = history.iteration(end);
recon.converged = history.max_relative_residual(end) <= opt.tolerance || ...
    history.max_relative_change(end) <= opt.tolerance;
recon.enforcePositive = opt.enforcePositive;
recon.conductanceFloor_s = opt.conductanceFloor_s;
recon.table = T;
recon.R_ohm = R;
recon.G_selected_s = G;
recon.G_sneak_est_s = Gsneak;
recon.current_total_a = currentMatrix;
recon.G_total_measured_s = Ymeas;
recon.G_predicted_total_s = Gpred;
recon.G_residual_s = residualMatrix;
recon.relative_residual_values = relResidualValues;
recon.valid = validFinal;
recon.numValid = nnz(validFinal);
recon.numTotal = opt.numRows * opt.numCols;
recon.history = history;
recon.closedForm.G_selected_s = Gclosed;
recon.closedForm.R_ohm = Rclosed;

recon.scan = scan;
recon.scan.table = T;
recon.scan.matrices.R_ohm = R;
recon.scan.matrices.current_a = currentMatrix;
recon.scan.matrices.RF_ohm = BasicArrayReader.tableToMatrices(T, ...
    opt.numRows, opt.numCols).RF_ohm;
recon.scan.matrices.status = BasicArrayReader.tableToMatrices(T, ...
    opt.numRows, opt.numCols).status;
end

function Vread = resolveVread(Vread, scan)
if ~isempty(Vread)
    return;
end
if isstruct(scan) && isfield(scan, "header") && ...
        isfield(scan.header, "VREAD") && isfinite(scan.header.VREAD)
    Vread = scan.header.VREAD;
    return;
end
error("reconstruct_vhalf_iterative:MissingVread", ...
    "Provide Vread or use a scan with header.VREAD.");
end

function alpha = resolveHalfSelectFactor(alpha, vcm, vhalf, vread)
if ~isempty(alpha)
    return;
end
if ~isempty(vcm) && ~isempty(vhalf) && isfinite(vcm) && ...
        isfinite(vhalf) && isfinite(vread) && vread > 0
    alpha = (vhalf - vcm) ./ vread;
else
    alpha = 0.5;
end
end

function [Y, valid, I] = measuredConductanceMatrix(T, vread, numRows, numCols, validStatuses)
vars = string(T.Properties.VariableNames);
if ismember("current_a", vars)
    Ivec = abs(T.current_a);
elseif all(ismember(["vadc_v", "rf_ohm"], vars))
    Ivec = abs(T.vadc_v ./ T.rf_ohm);
else
    error("reconstruct_vhalf_iterative:MissingCurrent", ...
        "Input table must contain current_a or vadc_v/rf_ohm.");
end

Y = nan(numRows, numCols);
I = nan(numRows, numCols);
valid = false(numRows, numCols);
validStatus = ismember(string(T.status), string(validStatuses));

for k = 1:height(T)
    r = T.row(k);
    c = T.col(k);
    if r < 1 || r > numRows || c < 1 || c > numCols
        continue;
    end
    if validStatus(k) && isfinite(Ivec(k)) && Ivec(k) > 0 && vread > 0
        I(r, c) = Ivec(k);
        Y(r, c) = Ivec(k) ./ vread;
        valid(r, c) = true;
    end
end
end

function G = initialConductanceMatrix(initialR, Y, alpha, numRows, numCols, floorS)
G = nan(numRows, numCols);
if ~isempty(initialR)
    initialR = localResistanceMatrix(initialR);
    if ~isequal(size(initialR), [numRows, numCols])
        error("reconstruct_vhalf_iterative:InitialSize", ...
            "initialR_ohm must be %dx%d.", numRows, numCols);
    end
    G = 1 ./ initialR;
    G(~isfinite(G) | G <= 0) = nan;
end

fallback = Y ./ max(1 + alpha .* (numRows - 1), eps);
missing = ~isfinite(G) | G <= 0;
G(missing) = fallback(missing);
G(~isfinite(G) | G <= 0) = floorS;
end

function R = localResistanceMatrix(value)
if isnumeric(value)
    R = value;
elseif isstruct(value) && isfield(value, "R_ohm")
    R = value.R_ohm;
elseif isstruct(value) && isfield(value, "matrices") && ...
        isfield(value.matrices, "R_ohm")
    R = value.matrices.R_ohm;
else
    error("reconstruct_vhalf_iterative:InvalidInitial", ...
        "initialR_ohm must be numeric or a struct containing R_ohm.");
end
end

function [residual, relValues] = residualForModel(G, Y, alpha, valid)
colSum = localSumOmitNan(G, 1);
Ypred = G + alpha .* (repmat(colSum, size(G, 1), 1) - G);
residual = Ypred - Y;
rel = abs(residual) ./ max(abs(Y), eps);
relValues = rel(valid & isfinite(rel));
end

function Gclosed = closedFormConductance(Y, alpha, numRows, numCols)
Gclosed = nan(numRows, numCols);
A = (1 - alpha) .* eye(numRows) + alpha .* ones(numRows, numRows);
for c = 1:numCols
    y = Y(:, c);
    if all(isfinite(y))
        Gclosed(:, c) = A \ y;
    end
end
end

function T = appendIterativeColumns(T, G, R, Y, residual, alpha, valid, numRows, numCols)
T.G_vhalf_total_measured_s = nan(height(T), 1);
T.G_iterative_selected_s = nan(height(T), 1);
T.G_iterative_sneak_est_s = nan(height(T), 1);
T.G_iterative_predicted_total_s = nan(height(T), 1);
T.G_iterative_residual_s = nan(height(T), 1);
T.R_vhalf_iterative_ohm = nan(height(T), 1);
T.vhalf_iterative_half_select_factor = repmat(alpha, height(T), 1);
T.isValidVhalfIterative = false(height(T), 1);

colSum = localSumOmitNan(G, 1);
Gpred = G + alpha .* (repmat(colSum, numRows, 1) - G);
Gsneak = alpha .* (repmat(colSum, numRows, 1) - G);

for k = 1:height(T)
    r = T.row(k);
    c = T.col(k);
    if r < 1 || r > numRows || c < 1 || c > numCols
        continue;
    end

    T.G_vhalf_total_measured_s(k) = Y(r, c);
    T.G_iterative_selected_s(k) = G(r, c);
    T.G_iterative_sneak_est_s(k) = Gsneak(r, c);
    T.G_iterative_predicted_total_s(k) = Gpred(r, c);
    T.G_iterative_residual_s(k) = residual(r, c);
    T.R_vhalf_iterative_ohm(k) = R(r, c);
    T.isValidVhalfIterative(k) = valid(r, c);
end
end

function s = localSumOmitNan(x, dim)
if nargin < 2
    dim = 1;
end
x(~isfinite(x)) = 0;
s = sum(x, dim);
end

function out = maxFinite(x)
x = x(isfinite(x));
if isempty(x)
    out = nan;
else
    out = max(abs(x));
end
end

function out = rmsFinite(x)
x = x(isfinite(x));
if isempty(x)
    out = nan;
else
    out = sqrt(mean(x.^2));
end
end
