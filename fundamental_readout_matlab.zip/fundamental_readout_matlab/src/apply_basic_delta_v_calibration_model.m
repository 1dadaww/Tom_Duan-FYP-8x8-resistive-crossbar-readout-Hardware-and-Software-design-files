function out = apply_basic_delta_v_calibration_model(scanOrTable, model, varargin)
%APPLY_BASIC_DELTA_V_CALIBRATION_MODEL Apply channel/RF current calibration.

p = inputParser;
addParameter(p, "numRows", 8);
addParameter(p, "numCols", 8);
addParameter(p, "deltaV", []);
addParameter(p, "fallback", "none");
parse(p, varargin{:});
opt = p.Results;

if ~isfield(model, "type") || string(model.type) ~= "readout_channel_rf_delta_v_linear"
    error("apply_basic_delta_v_calibration_model:InvalidModel", ...
        "Expected a readout_channel_rf_delta_v_linear calibration model.");
end

if istable(scanOrTable)
    T = scanOrTable;
    out = struct();
elseif isstruct(scanOrTable) && isfield(scanOrTable, "table")
    out = scanOrTable;
    T = scanOrTable.table;
else
    error("apply_basic_delta_v_calibration_model:InvalidInput", ...
        "Input must be a scan struct or scan table.");
end

required = ["row", "col", "col0", "rf_ohm"];
for k = 1:numel(required)
    if ~ismember(required(k), string(T.Properties.VariableNames))
        error("apply_basic_delta_v_calibration_model:MissingVariable", ...
            "Input table must contain variable '%s'.", required(k));
    end
end

if ismember("current_a", string(T.Properties.VariableNames))
    Iraw = abs(T.current_a);
elseif all(ismember(["vadc_v", "rf_ohm"], string(T.Properties.VariableNames)))
    Iraw = abs(T.vadc_v ./ T.rf_ohm);
else
    error("apply_basic_delta_v_calibration_model:MissingVariable", ...
        "Input table must contain current_a or vadc_v/rf_ohm.");
end

deltaV = opt.deltaV;
if isempty(deltaV)
    if ismember("delta_v", string(T.Properties.VariableNames))
        deltaV = T.delta_v;
    elseif isstruct(scanOrTable) && isfield(scanOrTable, "header") && ...
            isfield(scanOrTable.header, "VREAD") && isfinite(scanOrTable.header.VREAD)
        deltaV = scanOrTable.header.VREAD;
    elseif isfield(model, "defaultDeltaV") && isfinite(model.defaultDeltaV)
        deltaV = model.defaultDeltaV;
    else
        error("apply_basic_delta_v_calibration_model:MissingDeltaV", ...
            "Provide deltaV or use a scan with header.VREAD.");
    end
end
if isscalar(deltaV)
    deltaV = repmat(deltaV, height(T), 1);
end

Ical = nan(height(T), 1);
Rcal = nan(height(T), 1);
usedGain = nan(height(T), 1);
usedOffset = nan(height(T), 1);
usedRfNominal = nan(height(T), 1);
usedFallback = false(height(T), 1);

for k = 1:height(T)
    if ~isfinite(Iraw(k)) || Iraw(k) <= 0 || ~isfinite(T.rf_ohm(k)) || ...
            ~isfinite(deltaV(k)) || deltaV(k) <= 0
        continue;
    end

    ch = T.col0(k) + 1;
    [rfIndex, rfNominal] = nearest_rf_index_basic( ...
        T.rf_ohm(k), model.rfValues, model.rfTolerance);

    gain = nan;
    offset = nan;
    if ch >= 1 && ch <= model.numChannels && rfIndex > 0
        gain = model.gain(ch, rfIndex);
        offset = model.offset_a(ch, rfIndex);
    end

    if ~(isfinite(gain) && isfinite(offset))
        switch lower(string(opt.fallback))
            case "none"
                continue;
            otherwise
                error("apply_basic_delta_v_calibration_model:InvalidFallback", ...
                    "fallback must be 'none'. Global gain/offset is intentionally disabled.");
        end
    end

    Ical(k) = gain .* Iraw(k) + offset;
    if isfinite(Ical(k)) && Ical(k) > 0
        Rcal(k) = deltaV(k) ./ Ical(k);
    end
    usedGain(k) = gain;
    usedOffset(k) = offset;
    usedRfNominal(k) = rfNominal;
end

T.current_readout_calibrated_a = Ical;
T.r_readout_calibrated_ohm = Rcal;
T.readout_cal_rf_actual_ohm = T.rf_ohm;
T.readout_cal_gain = usedGain;
T.readout_cal_offset_a = usedOffset;
T.readout_cal_rf_nominal_ohm = usedRfNominal;
T.readout_cal_delta_v = deltaV(:);
T.readout_cal_applied = isfinite(Ical) & isfinite(Rcal);
T.readout_cal_used_fallback = usedFallback;

R = nan(opt.numRows, opt.numCols);
I = nan(opt.numRows, opt.numCols);
for k = 1:height(T)
    r = T.row(k);
    c = T.col(k);
    if r >= 1 && r <= opt.numRows && c >= 1 && c <= opt.numCols
        R(r, c) = T.r_readout_calibrated_ohm(k);
        I(r, c) = T.current_readout_calibrated_a(k);
    end
end

out.table = T;
out.R_readout_calibrated_ohm = R;
out.current_readout_calibrated_a = I;
out.matrices.R_readout_calibrated_ohm = R;
out.matrices.current_readout_calibrated_a = I;
end

function [idx, rfNominal] = nearest_rf_index_basic(rfMeasured, rfValues, rfTolerance)
idx = 0;
rfNominal = nan;

if isempty(rfValues)
    return;
end

[relErr, nearest] = min(abs(rfValues - rfMeasured) ./ max(abs(rfValues), 1));
if relErr <= rfTolerance
    idx = nearest;
    rfNominal = rfValues(nearest);
end
end
