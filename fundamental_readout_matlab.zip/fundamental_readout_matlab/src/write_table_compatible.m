function write_table_compatible(T, filePath)
%WRITE_TABLE_COMPATIBLE Save a table to CSV across older MATLAB versions.
%
% Some MATLAB releases reject table variables that contain cells. Fall back
% to writecell with a flattened cell matrix when writetable cannot handle it.

try
    writetable(T, filePath);
catch ME
    if ~contains(string(ME.message), "cell", "IgnoreCase", true)
        rethrow(ME);
    end

    C = table_to_cell_for_csv(T);
    writecell(C, filePath);
end
end

function C = table_to_cell_for_csv(T)
headers = T.Properties.VariableNames;
data = table2cell(T);

for r = 1:size(data, 1)
    for c = 1:size(data, 2)
        data{r, c} = value_for_csv(data{r, c});
    end
end

C = [headers; data];
end

function out = value_for_csv(value)
if iscell(value)
    if isempty(value)
        out = "";
    elseif isscalar(value)
        out = value_for_csv(value{1});
    else
        parts = strings(numel(value), 1);
        for k = 1:numel(value)
            parts(k) = string(value_for_csv(value{k}));
        end
        out = strjoin(parts, ";");
    end
elseif istable(value)
    out = sprintf("<table %dx%d>", height(value), width(value));
elseif isnumeric(value)
    if isscalar(value) || isempty(value)
        out = value;
    else
        out = mat2str(value);
    end
elseif islogical(value)
    if isscalar(value) || isempty(value)
        out = value;
    else
        out = mat2str(value);
    end
elseif isstring(value)
    if isscalar(value) || isempty(value)
        out = value;
    else
        out = strjoin(value, ";");
    end
elseif ischar(value)
    out = value;
elseif isdatetime(value) || isduration(value) || iscalendarduration(value)
    out = string(value);
else
    out = string(value);
end
end
