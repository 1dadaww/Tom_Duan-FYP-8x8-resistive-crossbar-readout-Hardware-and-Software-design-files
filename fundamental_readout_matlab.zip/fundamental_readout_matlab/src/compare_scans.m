function comparison = compare_scans(scanA, scanB, nameA, nameB)
%COMPARE_SCANS Compare two resistance scan matrices.

if nargin < 3 || isempty(nameA)
    nameA = "A";
end
if nargin < 4 || isempty(nameB)
    nameB = "B";
end

RA = scanA.matrices.R_ohm;
RB = scanB.matrices.R_ohm;
valid = isfinite(RA) & isfinite(RB) & RA > 0 & RB > 0;

diffOhm = RB - RA;
ratio = RB ./ RA;
percentDiff = 100 * diffOhm ./ RA;

summary = table(string(nameA), string(nameB), nnz(valid), ...
    mean(abs(diffOhm(valid)), "omitnan"), ...
    mean(abs(percentDiff(valid)), "omitnan"), ...
    median(abs(percentDiff(valid)), "omitnan"), ...
    max(abs(percentDiff(valid)), [], "omitnan"), ...
    'VariableNames', {'scanA', 'scanB', 'numValid', ...
    'MeanAbsDiff_ohm', 'MeanAbsPercentDiff', ...
    'MedianAbsPercentDiff', 'MaxAbsPercentDiff'});

comparison = struct();
comparison.nameA = string(nameA);
comparison.nameB = string(nameB);
comparison.diffOhm = diffOhm;
comparison.ratio = ratio;
comparison.percentDiff = percentDiff;
comparison.valid = valid;
comparison.summary = summary;

end

