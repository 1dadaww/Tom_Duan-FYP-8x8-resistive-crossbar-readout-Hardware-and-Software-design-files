function model = fit_basic_delta_v_calibration_model(calibrationTable, varargin)
%FIT_BASIC_DELTA_V_CALIBRATION_MODEL Fit channel/RF current gain + offset.
%
% The table should contain diagonal known-resistor measurements:
% channel0, rf_ohm, r_true, delta_v, and current_a or vadc_v.
% For each channel/RF it fits:
%
%   I_true = gain * I_raw + offset

p = inputParser;
addParameter(p, "numChannels", 8);
addParameter(p, "minPoints", 2);
addParameter(p, "rfTolerance", 0.05);
parse(p, varargin{:});
opt = p.Results;

required = ["channel0", "rf_ohm", "r_true", "delta_v"];
for k = 1:numel(required)
    if ~ismember(required(k), string(calibrationTable.Properties.VariableNames))
        error("fit_basic_delta_v_calibration_model:MissingVariable", ...
            "calibrationTable must contain variable '%s'.", required(k));
    end
end

if ismember("current_a", string(calibrationTable.Properties.VariableNames))
    Iraw = abs(calibrationTable.current_a);
elseif all(ismember(["vadc_v", "rf_ohm"], string(calibrationTable.Properties.VariableNames)))
    Iraw = abs(calibrationTable.vadc_v ./ calibrationTable.rf_ohm);
else
    error("fit_basic_delta_v_calibration_model:MissingVariable", ...
        "calibrationTable must contain current_a or vadc_v/rf_ohm.");
end

Itrue = calibrationTable.delta_v ./ calibrationTable.r_true;
valid = isfinite(calibrationTable.channel0) & ...
    isfinite(calibrationTable.rf_ohm) & ...
    isfinite(calibrationTable.r_true) & ...
    isfinite(calibrationTable.delta_v) & ...
    isfinite(Iraw) & isfinite(Itrue) & ...
    calibrationTable.rf_ohm > 0 & ...
    calibrationTable.r_true > 0 & ...
    calibrationTable.delta_v > 0 & ...
    Iraw > 0 & Itrue > 0;

T = calibrationTable(valid, :);
Iraw = Iraw(valid);
Itrue = Itrue(valid);

rfValues = sort(unique(T.rf_ohm));
rfValues = rfValues(:);

numChannels = opt.numChannels;
numRF = numel(rfValues);
gain = nan(numChannels, numRF);
offset_a = nan(numChannels, numRF);
numPoints = zeros(numChannels, numRF);
rmse_a = nan(numChannels, numRF);

for ch = 0:numChannels-1
    for j = 1:numRF
        rf = rfValues(j);
        rfMatch = abs(T.rf_ohm - rf) <= max(1, abs(rf) * opt.rfTolerance);
        rows = T.channel0 == ch & rfMatch;
        numPoints(ch+1, j) = nnz(rows);

        if numPoints(ch+1, j) >= opt.minPoints
            pfit = polyfit(Iraw(rows), Itrue(rows), 1);
            gain(ch+1, j) = pfit(1);
            offset_a(ch+1, j) = pfit(2);
            residual = Itrue(rows) - polyval(pfit, Iraw(rows));
            rmse_a(ch+1, j) = sqrt(mean(residual.^2, "omitnan"));
        elseif numPoints(ch+1, j) == 1
            gain(ch+1, j) = Itrue(rows) ./ Iraw(rows);
            offset_a(ch+1, j) = 0;
            rmse_a(ch+1, j) = 0;
        end
    end
end

model = struct();
model.type = "readout_channel_rf_delta_v_linear";
model.numChannels = numChannels;
model.rfValues = rfValues;
model.rfTolerance = opt.rfTolerance;
model.gain = gain;
model.offset_a = offset_a;
model.numPoints = numPoints;
model.rmse_a = rmse_a;
model.defaultDeltaV = median(T.delta_v, "omitnan");
model.created = datetime("now");
model.calibrationTable = T;
end
