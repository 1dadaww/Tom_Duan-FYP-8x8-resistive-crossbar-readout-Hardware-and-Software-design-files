function resultFolder = create_result_folder(folderName)
%CREATE_RESULT_FOLDER Replace only this example's latest result folder.
%
% Results from other examples are preserved. Running the same example again
% removes and recreates only its own latest_<folderName> directory.

if nargin < 1 || strlength(string(folderName)) == 0
    folderName = "readout";
end

root = fileparts(fileparts(mfilename('fullpath')));
resultsRoot = fullfile(root, 'results');
if ~exist(resultsRoot, 'dir')
    mkdir(resultsRoot);
end

safeName = regexprep(string(folderName), '[^\w\-]', '_');
resultFolder = fullfile(resultsRoot, "latest_" + safeName);

if exist(resultFolder, 'dir')
    rmdir(resultFolder, 's');
elseif exist(resultFolder, 'file')
    delete(resultFolder);
end

mkdir(resultFolder);

end
