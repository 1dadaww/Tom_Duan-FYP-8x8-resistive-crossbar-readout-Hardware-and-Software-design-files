classdef BasicArrayReader < handle
    %BASICARRAYREADER Minimal serial reader for fundamental array readout only.

    properties
        Port string
        BaudRate double = 115200
        Terminator string = "LF"
        DefaultTimeout double = 5
        ScanTimeout double = 90
        NumRows double = 8
        NumCols double = 8
        DefaultReadoutVCM double = 1.65
        DefaultReadoutVSEL double = 1.75
        PacketAverageCount double = 1
        ManualCellReadDiscardCount double = 1
        ManualCellReadDiscardPause_s double = 0.05
        AutoCellPrimeReadCount double = 1
        AutoCellMaxReadAttempts double = 3
        AutoCellRetryPause_s double = 0.10
        AutoCellLowLimit_v double = 0.04
        AutoCellHighLimit_v double = 1.08
        AutoCellConsistencyRelTol double = 0.25
        Serial
        LastStatus struct = struct()
    end

    methods
        function obj = BasicArrayReader(portName, baudRate)
            if nargin < 1 || strlength(string(portName)) == 0
                error("BasicArrayReader:MissingPort", ...
                    "Provide a serial port name, for example ""COM3"".");
            end
            obj.Port = string(portName);
            if nargin >= 2 && ~isempty(baudRate)
                obj.BaudRate = baudRate;
            end
        end

        function connect(obj)
            if ~isempty(obj.Serial)
                try
                    flush(obj.Serial);
                    return;
                catch
                    obj.Serial = [];
                end
            end

            obj.Serial = serialport(obj.Port, obj.BaudRate, "Timeout", obj.DefaultTimeout);
            configureTerminator(obj.Serial, obj.Terminator);
            pause(0.5);
            flush(obj.Serial);
        end

        function disconnect(obj)
            if ~isempty(obj.Serial)
                try
                    flush(obj.Serial);
                catch
                end
                try
                    delete(obj.Serial);
                catch
                end
                obj.Serial = [];
            end
        end

        function delete(obj)
            obj.disconnect();
        end

        function flushInput(obj)
            obj.assertConnected();
            flush(obj.Serial);
        end

        function sendCommand(obj, command)
            obj.assertConnected();
            writeline(obj.Serial, string(command));
        end

        function lines = readUntilMarker(obj, endMarker, timeout_s)
            obj.assertConnected();
            if nargin < 3 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end

            endMarker = string(endMarker);
            lines = strings(0, 1);
            originalTimeout = obj.Serial.Timeout;
            obj.Serial.Timeout = min(max(timeout_s, 1), 10);
            cleanup = onCleanup(@() setSerialTimeout(obj.Serial, originalTimeout));

            t0 = tic;
            while toc(t0) < timeout_s
                try
                    raw = readline(obj.Serial);
                catch
                    continue;
                end

                line = strtrim(string(raw));
                if strlength(line) == 0
                    continue;
                end

                lines(end+1, 1) = line; %#ok<AGROW>
                if line == endMarker || startsWith(line, endMarker)
                    return;
                end
                if startsWith(line, "ERROR,")
                    error("BasicArrayReader:FirmwareError", "%s", line);
                end
            end

            error("BasicArrayReader:Timeout", ...
                "Timed out waiting for marker %s after %.1f s.", endMarker, timeout_s);
        end

        function line = readUntilAny(obj, markerList, timeout_s)
            obj.assertConnected();
            if nargin < 3 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end

            markerList = string(markerList);
            originalTimeout = obj.Serial.Timeout;
            obj.Serial.Timeout = min(max(timeout_s, 1), 10);
            cleanup = onCleanup(@() setSerialTimeout(obj.Serial, originalTimeout));

            t0 = tic;
            while toc(t0) < timeout_s
                try
                    raw = readline(obj.Serial);
                catch
                    continue;
                end

                line = strtrim(string(raw));
                if strlength(line) == 0
                    continue;
                end

                for k = 1:numel(markerList)
                    if startsWith(line, markerList(k))
                        return;
                    end
                end
                if startsWith(line, "ERROR,")
                    error("BasicArrayReader:FirmwareError", "%s", line);
                end
            end

            error("BasicArrayReader:Timeout", ...
                "Timed out waiting for one of: %s", strjoin(markerList, ", "));
        end

        function lines = commandBlock(obj, command, endMarker, timeout_s)
            if nargin < 4 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end
            obj.flushInput();
            obj.sendCommand(command);
            lines = obj.readUntilMarker(endMarker, timeout_s);
        end

        function responseLine = setPacketAverage(obj, numSamples)
            validateattributes(numSamples, {'numeric'}, ...
                {'scalar', 'integer', '>=', 1, '<=', 1000});
            cmd = sprintf("SETAVG %d", numSamples);
            obj.flushInput();
            obj.sendCommand(cmd);
            responseLine = obj.readUntilAny(["OK,SETAVG", "ERROR,"], obj.DefaultTimeout);
            if startsWith(responseLine, "ERROR,")
                error("BasicArrayReader:FirmwareError", "%s", responseLine);
            end
            obj.PacketAverageCount = numSamples;
        end

        function responseLine = setBias(obj, vcm, vsel)
            validateattributes(vcm, {'numeric'}, {'scalar', 'real', 'finite'});
            validateattributes(vsel, {'numeric'}, {'scalar', 'real', 'finite', '>', vcm});
            cmd = sprintf("BIAS %.9g %.9g", vcm, vsel);
            obj.flushInput();
            obj.sendCommand(cmd);
            responseLine = obj.readUntilAny(["OK,BIAS", "ERROR,"], obj.DefaultTimeout);
            if startsWith(responseLine, "ERROR,")
                error("BasicArrayReader:FirmwareError", "%s", responseLine);
            end
        end

        function responseLine = setDefaultReadoutBias(obj)
            responseLine = obj.setBias(obj.DefaultReadoutVCM, obj.DefaultReadoutVSEL);
        end

        function restoreDefaultReadoutState(obj, packetAverageCount, rfName)
            if nargin < 2 || isempty(packetAverageCount)
                packetAverageCount = obj.PacketAverageCount;
            end
            if nargin < 3
                rfName = "";
            end

            obj.setPacketAverage(packetAverageCount);
            obj.setDefaultReadoutBias();
            if strlength(string(rfName)) > 0
                obj.setRF(rfName);
            end
        end

        function status = getStatus(obj)
            lines = obj.commandBlock("STATUS", "END_STATUS", obj.DefaultTimeout);
            status = BasicArrayReader.parseStatusLines(lines);
            obj.LastStatus = status;
        end

        function out = i2cScan(obj)
            lines = obj.commandBlock("I2CSCAN", "END_I2CSCAN", obj.DefaultTimeout);
            addresses = strings(0, 1);
            for k = 1:numel(lines)
                line = lines(k);
                if startsWith(line, "I2C,")
                    parts = split(line, ",");
                    if numel(parts) >= 2
                        addresses(end+1, 1) = parts(2); %#ok<AGROW>
                    end
                end
            end

            expected = ["0x20"; "0x21"; "0x22"; "0x23"];
            found = ismember(expected, addresses);
            out = struct();
            out.lines = lines;
            out.addresses = addresses;
            out.expected = expected;
            out.expectedFound = table(expected, found, ...
                'VariableNames', {'ExpectedAddress', 'Found'});
        end

        function responseLine = setRF(obj, rangeName)
            cmd = sprintf("RF %s", char(string(rangeName)));
            obj.flushInput();
            obj.sendCommand(cmd);
            responseLine = obj.readUntilAny(["OK,RF_GLOBAL", "ERROR,"], obj.DefaultTimeout);
            if startsWith(responseLine, "ERROR,")
                error("BasicArrayReader:FirmwareError", "%s", responseLine);
            end
        end

        function responseLine = setRFChannel(obj, ch, rangeName)
            validateattributes(ch, {'numeric'}, {'integer', '>=', 0, '<=', 7});
            cmd = sprintf("RFCH %d %s", ch, char(string(rangeName)));
            obj.flushInput();
            obj.sendCommand(cmd);
            responseLine = obj.readUntilAny(["OK,RFCH", "ERROR,"], obj.DefaultTimeout);
            if startsWith(responseLine, "ERROR,")
                error("BasicArrayReader:FirmwareError", "%s", responseLine);
            end
        end

        function rfTable = getRFStatus(obj)
            lines = obj.commandBlock("RFSTATUS", "END_RFSTATUS", obj.DefaultTimeout);
            rfTable = BasicArrayReader.parseRFStatusLines(lines);
        end

        function row = readCell(obj, rowIndex, colIndex, mode, autoRF)
            if nargin < 4 || isempty(mode)
                mode = "DIRECT";
            end
            if nargin < 5 || isempty(autoRF)
                autoRF = true;
            end

            validateattributes(rowIndex, {'numeric'}, {'integer', '>=', 0, '<=', 7});
            validateattributes(colIndex, {'numeric'}, {'integer', '>=', 0, '<=', 7});
            mode = upper(string(mode));
            if mode ~= "DIRECT" && mode ~= "VHALF" && mode ~= "FLOAT"
                error("BasicArrayReader:InvalidMode", ...
                    "mode must be DIRECT, VHALF, or FLOAT.");
            end

            if autoRF
                cmd = sprintf("CELL_%s_AUTO %d %d", mode, rowIndex, colIndex);
            else
                cmd = sprintf("CELL_%s %d %d", mode, rowIndex, colIndex);
            end

            obj.flushInput();
            obj.sendCommand(cmd);
            line = obj.readUntilAny(["DATA,", "ERROR,"], obj.DefaultTimeout);
            if startsWith(line, "ERROR,")
                error("BasicArrayReader:FirmwareError", "%s", line);
            end
            row = BasicArrayReader.parseDataLine(line);
        end

        function row = readCellAveraged(obj, rowIndex, colIndex, mode, autoRF, numAverages)
            if nargin < 5 || isempty(autoRF)
                autoRF = true;
            end
            if nargin < 6 || isempty(numAverages)
                numAverages = 1;
            end
            validateattributes(numAverages, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 1000});

            [discardCount, discardTable, discardPause_s] = obj.discardManualCellReads( ...
                rowIndex, colIndex, mode, autoRF);

            if numAverages == 1
                row = obj.readCell(rowIndex, colIndex, mode, autoRF);
                row.average_count = 1;
                row.discard_count = discardCount;
                row.discard_pause_s = discardPause_s;
                row.discard_raw_table = {discardTable};
                return;
            end

            rows = cell(numAverages, 1);
            for rep = 1:numAverages
                T = obj.readCell(rowIndex, colIndex, mode, autoRF);
                T.average_repeat_index = rep;
                rows{rep} = T;
            end

            rawRows = vertcat(rows{:});
            row = BasicArrayReader.averageDataRows(rawRows);
            row.average_count = numAverages;
            row.average_raw_table = {rawRows};
            row.discard_count = discardCount;
            row.discard_pause_s = discardPause_s;
            row.discard_raw_table = {discardTable};
        end

        function [row, guardRows] = readCellAutoGuarded(obj, rowIndex, colIndex, mode, startRF)
            %READCELLAUTOGUARDED Auto-RF cell read with switch re-apply/retry.
            %
            % The first read after switching can be stale on this hardware.
            % This method discards a priming read, re-applies the requested
            % RF start state before each candidate, and accepts a stable pair.
            if nargin < 4 || isempty(mode)
                mode = "DIRECT";
            end
            if nargin < 5
                startRF = "";
            end

            startRF = string(startRF);
            primeCount = round(obj.AutoCellPrimeReadCount);
            maxAttempts = round(obj.AutoCellMaxReadAttempts);
            retryPause_s = max(0, obj.AutoCellRetryPause_s);
            relTol = max(0, obj.AutoCellConsistencyRelTol);
            validateattributes(primeCount, {'numeric'}, {'scalar', 'integer', '>=', 0, '<=', 10});
            validateattributes(maxAttempts, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 10});

            allRows = {};
            candidateRows = {};
            previousCandidate = table();

            for k = 1:primeCount
                if strlength(startRF) > 0
                    obj.setRF(startRF);
                end
                if retryPause_s > 0
                    pause(retryPause_s);
                end
                T = obj.readCell(rowIndex, colIndex, mode, true);
                T.guard_role = "prime_discard";
                T.guard_attempt = 0;
                T.guard_limit_like = BasicArrayReader.isLimitLikeRead( ...
                    T, obj.AutoCellLowLimit_v, obj.AutoCellHighLimit_v);
                T.guard_stable_with_previous = false;
                allRows{end+1, 1} = T; %#ok<AGROW>
            end

            accepted = table();
            acceptReason = "last_retry";
            for attempt = 1:maxAttempts
                if strlength(startRF) > 0
                    obj.setRF(startRF);
                end
                if retryPause_s > 0
                    pause(retryPause_s);
                end

                T = obj.readCell(rowIndex, colIndex, mode, true);
                limitLike = BasicArrayReader.isLimitLikeRead( ...
                    T, obj.AutoCellLowLimit_v, obj.AutoCellHighLimit_v);
                stable = false;
                if ~isempty(previousCandidate)
                    stable = BasicArrayReader.isStableReadPair(previousCandidate, T, relTol);
                end

                T.guard_role = "candidate";
                T.guard_attempt = attempt;
                T.guard_limit_like = limitLike;
                T.guard_stable_with_previous = stable;
                allRows{end+1, 1} = T; %#ok<AGROW>
                candidateRows{end+1, 1} = T; %#ok<AGROW>

                if numel(candidateRows) >= 2 && stable && ~limitLike
                    accepted = T;
                    acceptReason = "stable_pair";
                    break;
                end

                previousCandidate = T;
            end

            if isempty(accepted)
                candidates = vertcat(candidateRows{:});
                accepted = BasicArrayReader.pickBestGuardedCandidate( ...
                    candidates, obj.AutoCellLowLimit_v, obj.AutoCellHighLimit_v);
            end

            guardRows = vertcat(allRows{:});
            row = accepted;
            row.guard_role = "accepted";
            row.guard_total_reads = height(guardRows);
            row.guard_candidate_count = numel(candidateRows);
            row.guard_limit_like = BasicArrayReader.isLimitLikeRead( ...
                row, obj.AutoCellLowLimit_v, obj.AutoCellHighLimit_v);
            row.guard_accept_reason = acceptReason;
        end

        function scan = scanArray(obj, mode, autoRF, timeout_s)
            if nargin < 2 || isempty(mode)
                mode = "DIRECT";
            end
            if nargin < 3 || isempty(autoRF)
                autoRF = true;
            end
            if nargin < 4 || isempty(timeout_s)
                timeout_s = obj.ScanTimeout;
            end

            mode = upper(string(mode));
            if mode ~= "DIRECT" && mode ~= "VHALF" && mode ~= "FLOAT"
                error("BasicArrayReader:InvalidMode", ...
                    "mode must be DIRECT, VHALF, or FLOAT.");
            end

            if autoRF
                cmd = sprintf("SCAN_%s_AUTO", mode);
            else
                cmd = sprintf("SCAN_%s", mode);
            end

            obj.flushInput();
            obj.sendCommand(cmd);
            lines = obj.readUntilMarker("END_SCAN", timeout_s);

            dataRows = {};
            beginLine = "";
            endLine = "";
            for k = 1:numel(lines)
                line = lines(k);
                if startsWith(line, "BEGIN_SCAN,")
                    beginLine = line;
                elseif startsWith(line, "END_SCAN")
                    endLine = line;
                elseif startsWith(line, "DATA,")
                    dataRows{end+1, 1} = BasicArrayReader.parseDataLine(line); %#ok<AGROW>
                end
            end

            if isempty(dataRows)
                error("BasicArrayReader:NoData", "No DATA lines were received in scan.");
            end

            T = vertcat(dataRows{:});
            scan = struct();
            scan.command = cmd;
            scan.beginLine = beginLine;
            scan.endLine = endLine;
            scan.lines = lines;
            scan.table = T;
            scan.matrices = BasicArrayReader.tableToMatrices(T, obj.NumRows, obj.NumCols);
            scan.mode = mode;
            scan.autoRF = autoRF;
            scan.timestamp = datetime("now");
            if strlength(beginLine) > 0
                scan.header = BasicArrayReader.parseBeginScanLine(beginLine);
            else
                scan.header = struct();
            end
        end

        function scan = rowScanDirect(obj, rowIndex, timeout_s)
            %ROWSCANDIRECT Read one full row using firmware ROW_DIRECT.
            if nargin < 3 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end
            validateattributes(rowIndex, {'numeric'}, {'integer', '>=', 0, '<=', 7});

            cmd = sprintf("ROW_DIRECT %d", rowIndex);
            obj.flushInput();
            obj.sendCommand(cmd);
            lines = obj.readUntilMarker("END_ROW", timeout_s);

            dataRows = {};
            for k = 1:numel(lines)
                line = lines(k);
                if startsWith(line, "DATA,")
                    dataRows{end+1, 1} = BasicArrayReader.parseDataLine(line); %#ok<AGROW>
                end
            end
            if isempty(dataRows)
                error("BasicArrayReader:NoData", "No DATA lines were received in row read.");
            end

            T = vertcat(dataRows{:});
            scan = struct();
            scan.command = cmd;
            scan.lines = lines;
            scan.table = T;
            scan.matrices = BasicArrayReader.tableToMatrices(T, obj.NumRows, obj.NumCols);
            scan.mode = "DIRECT";
            scan.autoRF = false;
            scan.timestamp = datetime("now");
        end

        function scan = scanArrayAveraged(obj, mode, autoRF, timeout_s, numAverages)
            if nargin < 5 || isempty(numAverages)
                numAverages = 1;
            end
            validateattributes(numAverages, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 1000});

            if numAverages == 1
                scan = obj.scanArray(mode, autoRF, timeout_s);
                scan.average_count = 1;
                return;
            end

            scans = cell(numAverages, 1);
            rows = cell(numAverages, 1);
            for rep = 1:numAverages
                scans{rep} = obj.scanArray(mode, autoRF, timeout_s);
                T = scans{rep}.table;
                T.average_repeat_index = repmat(rep, height(T), 1);
                rows{rep} = T;
            end

            rawTable = vertcat(rows{:});
            avgRows = cell(obj.NumRows * obj.NumCols, 1);
            idx = 0;
            for row0 = 0:obj.NumRows-1
                for col0 = 0:obj.NumCols-1
                    idx = idx + 1;
                    cellRows = rawTable(rawTable.row0 == row0 & rawTable.col0 == col0, :);
                    avgRows{idx} = BasicArrayReader.averageDataRows(cellRows);
                end
            end

            Tavg = vertcat(avgRows{:});
            scan = scans{end};
            scan.command = scans{end}.command + "_MATLAB_AVG_" + string(numAverages);
            scan.table = Tavg;
            scan.rawAverageTable = rawTable;
            scan.average_count = numAverages;
            scan.matrices = BasicArrayReader.tableToMatrices(Tavg, obj.NumRows, obj.NumCols);
            scan.timestamp = datetime("now");
        end

        function scan = scanArrayAutoByCell(obj, mode, startRF, rowResetDelay_s)
            %SCANARRAYAUTOBYCELL Safe MATLAB-controlled auto-RF full scan.
            %
            % This avoids firmware SCAN_*_AUTO. It resets bias/RF at the
            % start of each row, then uses CELL_*_AUTO for each cell.
            if nargin < 2 || isempty(mode)
                mode = "DIRECT";
            end
            if nargin < 3
                startRF = "100";
            end
            if nargin < 4 || isempty(rowResetDelay_s)
                rowResetDelay_s = 1;
            end

            mode = upper(string(mode));
            if mode ~= "DIRECT" && mode ~= "VHALF" && mode ~= "FLOAT"
                error("BasicArrayReader:InvalidMode", ...
                    "mode must be DIRECT, VHALF, or FLOAT.");
            end
            startRF = string(startRF);

            obj.setDefaultReadoutBias();
            if strlength(startRF) > 0
                obj.setRF(startRF);
            end
            if rowResetDelay_s > 0
                pause(rowResetDelay_s);
            end
            status = obj.getStatus();

            dataRows = cell(obj.NumRows * obj.NumCols, 1);
            guardRows = cell(obj.NumRows * obj.NumCols, 1);
            idx = 0;
            for row0 = 0:obj.NumRows-1
                obj.setDefaultReadoutBias();
                if strlength(startRF) > 0
                    obj.setRF(startRF);
                end
                if rowResetDelay_s > 0
                    pause(rowResetDelay_s);
                end

                for col0 = 0:obj.NumCols-1
                    idx = idx + 1;
                    [T, G] = obj.readCellAutoGuarded(row0, col0, mode, startRF);
                    T.auto_start_rf_name = startRF;
                    T.row_reset_delay_s = rowResetDelay_s;
                    T.scan_method = "MATLAB_CELL_AUTO_GUARDED";
                    dataRows{idx} = T;
                    guardRows{idx} = G;
                end
            end

            Tscan = vertcat(dataRows{:});
            scan = struct();
            scan.command = "MATLAB_CELL_" + mode + "_AUTO_GUARDED";
            scan.beginLine = "";
            scan.endLine = "";
            scan.lines = strings(0, 1);
            scan.table = Tscan;
            scan.rawGuardTable = vertcat(guardRows{:});
            scan.matrices = BasicArrayReader.tableToMatrices(Tscan, obj.NumRows, obj.NumCols);
            scan.mode = mode;
            scan.autoRF = true;
            scan.timestamp = datetime("now");
            scan.header = struct("mode", mode + "_AUTO_GUARDED", ...
                "numRows", obj.NumRows, "numCols", obj.NumCols, ...
                "VREAD", status.VREAD, "packet_avg", obj.PacketAverageCount, ...
                "auto_start_rf_name", startRF, "row_reset_delay_s", rowResetDelay_s, ...
                "prime_reads", obj.AutoCellPrimeReadCount, ...
                "max_attempts", obj.AutoCellMaxReadAttempts, ...
                "retry_pause_s", obj.AutoCellRetryPause_s, ...
                "low_limit_v", obj.AutoCellLowLimit_v, ...
                "high_limit_v", obj.AutoCellHighLimit_v);
        end

        function scan = scanArrayAutoByCellAveraged(obj, mode, startRF, rowResetDelay_s, numAverages)
            %SCANARRAYAUTOBYCELLAVERAGED Repeat safe auto-RF scan and average.
            if nargin < 5 || isempty(numAverages)
                numAverages = 1;
            end
            validateattributes(numAverages, {'numeric'}, {'scalar', 'integer', '>=', 1, '<=', 1000});

            if numAverages == 1
                scan = obj.scanArrayAutoByCell(mode, startRF, rowResetDelay_s);
                scan.average_count = 1;
                return;
            end

            scans = cell(numAverages, 1);
            rows = cell(numAverages, 1);
            guardRows = cell(numAverages, 1);
            for rep = 1:numAverages
                scans{rep} = obj.scanArrayAutoByCell(mode, startRF, rowResetDelay_s);
                T = scans{rep}.table;
                T.average_repeat_index = repmat(rep, height(T), 1);
                rows{rep} = T;
                if isfield(scans{rep}, "rawGuardTable")
                    G = scans{rep}.rawGuardTable;
                    G.average_repeat_index = repmat(rep, height(G), 1);
                    guardRows{rep} = G;
                end
            end

            rawTable = vertcat(rows{:});
            avgRows = cell(obj.NumRows * obj.NumCols, 1);
            idx = 0;
            for row0 = 0:obj.NumRows-1
                for col0 = 0:obj.NumCols-1
                    idx = idx + 1;
                    cellRows = rawTable(rawTable.row0 == row0 & rawTable.col0 == col0, :);
                    avgRows{idx} = BasicArrayReader.averageDataRows(cellRows);
                end
            end

            Tavg = vertcat(avgRows{:});
            scan = scans{end};
            scan.command = scans{end}.command + "_MATLAB_AVG_" + string(numAverages);
            scan.table = Tavg;
            scan.rawAverageTable = rawTable;
            nonemptyGuard = guardRows(~cellfun(@isempty, guardRows));
            if ~isempty(nonemptyGuard)
                scan.rawGuardTable = vertcat(nonemptyGuard{:});
            end
            scan.average_count = numAverages;
            scan.matrices = BasicArrayReader.tableToMatrices(Tavg, obj.NumRows, obj.NumCols);
            scan.timestamp = datetime("now");
        end
    end

    methods (Access = private)
        function [discardCount, discardTable, discardPause_s] = discardManualCellReads(obj, rowIndex, colIndex, mode, autoRF)
            discardCount = 0;
            discardPause_s = 0;
            discardTable = table();
            if logical(autoRF)
                return;
            end

            discardCount = round(obj.ManualCellReadDiscardCount);
            if discardCount <= 0
                discardCount = 0;
                return;
            end
            validateattributes(discardCount, {'numeric'}, {'scalar', 'integer', '>=', 0, '<=', 10});

            discardRows = cell(discardCount, 1);
            for k = 1:discardCount
                discardRows{k} = obj.readCell(rowIndex, colIndex, mode, false);
            end
            discardTable = vertcat(discardRows{:});

            discardPause_s = max(0, obj.ManualCellReadDiscardPause_s);
            if discardPause_s > 0
                pause(discardPause_s);
            end
        end

        function assertConnected(obj)
            if isempty(obj.Serial)
                error("BasicArrayReader:NotConnected", ...
                    "Serial port is not connected. Call connect() first.");
            end
        end
    end

    methods (Static)
        function tf = isLimitLikeRead(T, lowLimit_v, highLimit_v)
            vadc = T.vadc_v(1);
            status = upper(string(T.status(1)));
            tf = ~isfinite(vadc) || vadc <= lowLimit_v || vadc >= highLimit_v || status ~= "OK";
        end

        function tf = isStableReadPair(a, b, relTol)
            ia = abs(a.current_a(1));
            ib = abs(b.current_a(1));
            if ~isfinite(ia) || ~isfinite(ib)
                tf = false;
                return;
            end

            scale = max([ia, ib, eps]);
            tf = abs(ia - ib) <= relTol * scale;
        end

        function Tbest = pickBestGuardedCandidate(T, lowLimit_v, highLimit_v)
            if height(T) == 1
                Tbest = T;
                return;
            end

            good = true(height(T), 1);
            for k = 1:height(T)
                good(k) = ~BasicArrayReader.isLimitLikeRead(T(k, :), lowLimit_v, highLimit_v);
            end

            if any(good)
                candidateIndex = find(good);
            else
                candidateIndex = (1:height(T)).';
            end

            currents = abs(T.current_a(candidateIndex));
            finiteCurrent = isfinite(currents);
            if any(finiteCurrent)
                candidateIndex = candidateIndex(finiteCurrent);
                currents = currents(finiteCurrent);
                [~, localIdx] = max(currents);
                Tbest = T(candidateIndex(localIdx), :);
            else
                Tbest = T(end, :);
            end
        end

        function T = parseDataLine(line)
            line = strtrim(string(line));
            if ~startsWith(line, "DATA,")
                error("BasicArrayReader:ParseError", "Not a DATA line: %s", line);
            end

            p = split(line, ",");
            if numel(p) < 9
                error("BasicArrayReader:ParseError", ...
                    "DATA line has too few fields: %s", line);
            end

            row0 = str2double(p(2));
            col0 = str2double(p(3));
            rf_ohm = str2double(p(4));
            vadc_v = str2double(p(5));
            current_a = str2double(p(6));
            r_ohm = str2double(p(7));
            status = string(p(8));
            attempts = str2double(p(9));
            packet_avg = BasicArrayReader.parseOptionalNumericField(p, "AVG", nan);

            T = table(row0, col0, row0+1, col0+1, rf_ohm, vadc_v, current_a, ...
                r_ohm, status, attempts, packet_avg, ...
                'VariableNames', {'row0', 'col0', 'row', 'col', 'rf_ohm', ...
                'vadc_v', 'current_a', 'r_ohm', 'status', 'attempts', ...
                'packet_avg'});
        end

        function Tavg = averageDataRows(T)
            if isempty(T) || height(T) == 0
                Tavg = table();
                return;
            end

            Tavg = T(1, :);
            vars = string(T.Properties.VariableNames);
            numericVars = vars(varfun(@isnumeric, T, 'OutputFormat', 'uniform'));
            identityVars = ["row0", "col0", "row", "col"];

            for v = numericVars
                values = T.(v);
                if ismember(v, identityVars)
                    Tavg.(v) = values(1);
                else
                    Tavg.(v) = mean(values, "omitnan");
                    stdName = matlab.lang.makeValidName(v + "_std");
                    Tavg.(stdName) = std(values, 0, "omitnan");
                end
            end

            if ismember("status", vars)
                statusValues = string(T.status);
                if all(statusValues == statusValues(1))
                    Tavg.status = statusValues(1);
                else
                    Tavg.status = "AVERAGED_MIXED";
                end
            end
        end

        function matrices = tableToMatrices(T, numRows, numCols)
            R = nan(numRows, numCols);
            Vadc = nan(numRows, numCols);
            I = nan(numRows, numCols);
            RF = nan(numRows, numCols);
            attempts = nan(numRows, numCols);
            status = strings(numRows, numCols);
            status(:) = "MISSING";

            for k = 1:height(T)
                r = T.row(k);
                c = T.col(k);
                if r >= 1 && r <= numRows && c >= 1 && c <= numCols
                    R(r, c) = T.r_ohm(k);
                    Vadc(r, c) = T.vadc_v(k);
                    I(r, c) = T.current_a(k);
                    RF(r, c) = T.rf_ohm(k);
                    attempts(r, c) = T.attempts(k);
                    status(r, c) = T.status(k);
                end
            end

            matrices = struct();
            matrices.R_ohm = R;
            matrices.Vadc_v = Vadc;
            matrices.current_a = I;
            matrices.RF_ohm = RF;
            matrices.attempts = attempts;
            matrices.status = status;
        end

        function status = parseStatusLines(lines)
            status = struct();
            status.rawLines = lines;
            status.VCM = nan;
            status.VSEL = nan;
            status.VHALF = nan;
            status.VREAD = nan;
            status.PACKET_AVG = nan;
            status.RF = table();
            rfRows = {};

            for k = 1:numel(lines)
                p = split(string(lines(k)), ",");
                if numel(p) < 2
                    continue;
                end
                key = upper(string(p(1)));
                switch key
                    case "VCM"
                        status.VCM = str2double(p(2));
                    case "VSEL"
                        status.VSEL = str2double(p(2));
                    case "VHALF"
                        status.VHALF = str2double(p(2));
                    case "VREAD"
                        status.VREAD = str2double(p(2));
                    case "PACKET_AVG"
                        status.PACKET_AVG = str2double(p(2));
                    case "RFCH"
                        if numel(p) >= 4
                            rfRows{end+1, 1} = table(str2double(p(2)), string(p(3)), ...
                                str2double(p(4)), 'VariableNames', ...
                                {'channel', 'rf_name', 'rf_ohm'}); %#ok<AGROW>
                        end
                end
            end

            if ~isempty(rfRows)
                status.RF = vertcat(rfRows{:});
            end
        end

        function rfTable = parseRFStatusLines(lines)
            rows = {};
            for k = 1:numel(lines)
                line = string(lines(k));
                if startsWith(line, "RFCH,")
                    p = split(line, ",");
                    if numel(p) >= 4
                        rows{end+1, 1} = table(str2double(p(2)), string(p(3)), ...
                            str2double(p(4)), 'VariableNames', ...
                            {'channel', 'rf_name', 'rf_ohm'}); %#ok<AGROW>
                    end
                end
            end

            if isempty(rows)
                rfTable = table();
            else
                rfTable = vertcat(rows{:});
            end
        end

        function header = parseBeginScanLine(line)
            p = split(string(line), ",");
            header = struct();
            header.raw = string(line);
            header.mode = "";
            header.numRows = nan;
            header.numCols = nan;
            header.VREAD = nan;
            header.packet_avg = nan;

            if numel(p) >= 4
                header.mode = string(p(2));
                header.numRows = str2double(p(3));
                header.numCols = str2double(p(4));
            end

            for k = 5:2:numel(p)-1
                key = upper(string(p(k)));
                value = str2double(p(k+1));
                switch key
                    case "VREAD"
                        header.VREAD = value;
                    case "AVG"
                        header.packet_avg = value;
                end
            end
        end

        function value = parseOptionalNumericField(parts, keyName, defaultValue)
            value = defaultValue;
            keyName = upper(string(keyName));
            for k = 1:numel(parts)-1
                if upper(string(parts(k))) == keyName
                    parsed = str2double(parts(k+1));
                    if isfinite(parsed)
                        value = parsed;
                    end
                    return;
                end
            end
        end
    end
end

function setSerialTimeout(serialObj, timeoutValue)
try
    serialObj.Timeout = timeoutValue;
catch
end
end
