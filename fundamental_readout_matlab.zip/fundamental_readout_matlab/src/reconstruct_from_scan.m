function recon = reconstruct_from_scan(scanOrTable, method, varargin)
%RECONSTRUCT_FROM_SCAN Reconstruct DIRECT or apparent-equivalent resistance.
%
% For DIRECT readout, R = VREAD / I is the selected-cell resistance under
% the DIRECT clamp condition. For VHALF readout, the same equation is only
% an apparent/equivalent resistance because the measured current can include
% half-selected cells. Use reconstruct_vhalf_iterative with saved calibrated
% VHALF current data when selected-cell VHALF reconstruction is needed.

p = inputParser;
addParameter(p, "Vread", []);
addParameter(p, "numRows", 8);
addParameter(p, "numCols", 8);
addParameter(p, "mode", "");
addParameter(p, "validStatuses", ["OK", "LOW_SIGNAL", "HIGH_SIGNAL", "MIN_RF_LIMIT", "MAX_RF_LIMIT"]);
parse(p, varargin{:});
opt = p.Results;

method = lower(string(method));
if istable(scanOrTable)
    T = scanOrTable;
    scan = struct();
elseif isstruct(scanOrTable) && isfield(scanOrTable, "table")
    scan = scanOrTable;
    T = scan.table;
else
    error("reconstruct_from_scan:InvalidInput", ...
        "Input must be a scan struct or scan table.");
end

readMode = upper(string(opt.mode));
if strlength(readMode) == 0 && exist("scan", "var") && isfield(scan, "mode")
    readMode = upper(string(scan.mode));
end
if strlength(readMode) == 0 && ismember("mode", string(T.Properties.VariableNames))
    readMode = upper(string(T.mode(1)));
end

Vread = opt.Vread;
if isempty(Vread)
    if exist("scan", "var") && isfield(scan, "header") && ...
            isfield(scan.header, "VREAD") && isfinite(scan.header.VREAD)
        Vread = scan.header.VREAD;
    else
        error("reconstruct_from_scan:MissingVread", ...
            "Vread was not provided and could not be parsed from scan.header.");
    end
end

valid = ismember(string(T.status), string(opt.validStatuses)) & ...
    isfinite(T.vadc_v) & isfinite(T.rf_ohm);

switch method
    case "firmware"
        Rvec = T.r_ohm;
        Ivec = T.current_a;
        Vcorr = T.vadc_v;
    case "ohm"
        Vcorr = T.vadc_v;
        Ivec = Vcorr ./ T.rf_ohm;
        Rvec = Vread ./ Ivec;
    case "current"
        Ivec = T.current_a;
        Rvec = Vread ./ Ivec;
        Vcorr = T.vadc_v;
    otherwise
        error("reconstruct_from_scan:UnknownMethod", ...
            "Unknown reconstruction method: %s", method);
end

Rvec = abs(Rvec);
Ivec = abs(Ivec);
Rvec(~valid | ~isfinite(Rvec)) = nan;

Tout = T;
Tout.R_recon_ohm = Rvec;
Tout.R_apparent_ohm = Rvec;
Tout.I_recon_a = Ivec;
Tout.Vadc_corrected_v = Vcorr;
Tout.isValidForReconstruction = valid & isfinite(Rvec);

R = nan(opt.numRows, opt.numCols);
I = nan(opt.numRows, opt.numCols);
V = nan(opt.numRows, opt.numCols);
validMatrix = false(opt.numRows, opt.numCols);

for k = 1:height(Tout)
    r = Tout.row(k);
    c = Tout.col(k);
    if r >= 1 && r <= opt.numRows && c >= 1 && c <= opt.numCols
        R(r, c) = Tout.R_recon_ohm(k);
        I(r, c) = Tout.I_recon_a(k);
        V(r, c) = Tout.Vadc_corrected_v(k);
        validMatrix(r, c) = Tout.isValidForReconstruction(k);
    end
end

recon = struct();
recon.method = method;
recon.mode = readMode;
if contains(readMode, "VHALF")
    recon.quantity = "apparent_equivalent_resistance";
    recon.note = "VHALF R_ohm is VREAD divided by total measured current; it is not the selected-cell resistance unless sneak current is negligible or separately corrected.";
else
    recon.quantity = "selected_cell_resistance";
    recon.note = "DIRECT R_ohm is the selected-cell resistance under the DIRECT row/column clamp condition.";
end
recon.Vread = Vread;
recon.table = Tout;
recon.R_ohm = R;
recon.current_a = I;
recon.Vadc_corrected_v = V;
recon.valid = validMatrix;
recon.numValid = nnz(validMatrix);
recon.numTotal = opt.numRows * opt.numCols;

end
