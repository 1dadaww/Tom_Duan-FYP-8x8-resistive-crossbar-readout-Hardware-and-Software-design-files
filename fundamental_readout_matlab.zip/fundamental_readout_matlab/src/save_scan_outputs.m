function save_scan_outputs(scan, resultFolder, baseName)
%SAVE_SCAN_OUTPUTS Save scan tables, matrices, and basic figures.

if nargin < 3 || isempty(baseName)
    baseName = "scan";
end
if ~exist(resultFolder, 'dir')
    mkdir(resultFolder);
end

T = scan.table;
writetable(T, fullfile(resultFolder, baseName + "_table.csv"));
if isfield(scan, "rawGuardTable") && ~isempty(scan.rawGuardTable)
    writetable(scan.rawGuardTable, fullfile(resultFolder, baseName + "_guard_raw_table.csv"));
end

matrices = scan.matrices;
save(fullfile(resultFolder, baseName + "_scan.mat"), "scan", "matrices");

writematrix(matrices.R_ohm, fullfile(resultFolder, baseName + "_R_ohm.csv"));
writematrix(matrices.Vadc_v, fullfile(resultFolder, baseName + "_Vadc_v.csv"));
writematrix(matrices.current_a, fullfile(resultFolder, baseName + "_current_a.csv"));
writematrix(matrices.RF_ohm, fullfile(resultFolder, baseName + "_RF_ohm.csv"));

plot_matrix_heatmap(matrices.R_ohm, baseName + " resistance / ohm", ...
    fullfile(resultFolder, baseName + "_R_ohm_heatmap.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)");

plot_matrix_heatmap(matrices.R_ohm, baseName + " raw resistance decimal / ohm", ...
    fullfile(resultFolder, baseName + "_R_ohm_heatmap_decimal.png"), ...
    "logScale", false, "colorbarLabel", "ohm", "showText", true);

plot_matrix_heatmap(matrices.Vadc_v, baseName + " ADC voltage / V", ...
    fullfile(resultFolder, baseName + "_Vadc_heatmap.png"), ...
    "logScale", false, "colorbarLabel", "V");

plot_matrix_heatmap(matrices.RF_ohm, baseName + " RF / ohm", ...
    fullfile(resultFolder, baseName + "_RF_heatmap.png"), ...
    "logScale", true, "colorbarLabel", "log10(ohm)");

end
