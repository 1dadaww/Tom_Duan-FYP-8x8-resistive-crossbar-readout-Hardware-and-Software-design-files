function scan = scan_cell_auto_retry_in_window(dev, varargin)
%SCAN_CELL_AUTO_RETRY_IN_WINDOW Guarded MATLAB-controlled auto-RF scan.
%
% This helper uses CELL_DIRECT_AUTO, CELL_VHALF_AUTO, or CELL_FLOAT_AUTO per
% cell, then retries a cell when the returned ADC voltage is outside the
% requested window.

p = inputParser;
addParameter(p, "mode", "DIRECT");
addParameter(p, "startRF", "10k");
addParameter(p, "rowResetDelay_s", 0.005);
addParameter(p, "averageCount", 1);
addParameter(p, "lowLimit_v", 0.08);
addParameter(p, "highLimit_v", 1.05);
addParameter(p, "maxCellAttempts", 12);
addParameter(p, "retryPause_s", 0.05);
addParameter(p, "firstCellStartRF", "10k");
addParameter(p, "firstCellSettle_s", 1.0);
addParameter(p, "firstCellMaxAttempts", 6);
addParameter(p, "firstCellRetryPause_s", 0.05);
addParameter(p, "firstCellStableRelTol", 0.02);
addParameter(p, "rowExtraGuardRows0", []);
addParameter(p, "rowExtraGuardDiscardCount", 0);
addParameter(p, "rowExtraGuardPause_s", 0.02);
addParameter(p, "postRowRereadRows0", []);
addParameter(p, "postRowRereadCols0", []);
addParameter(p, "postRowRereadPause_s", 0.05);
parse(p, varargin{:});
opt = p.Results;

opt.mode = upper(string(opt.mode));
if opt.mode ~= "DIRECT" && opt.mode ~= "VHALF" && opt.mode ~= "FLOAT"
    error("scan_cell_auto_retry_in_window:InvalidMode", ...
        "mode must be DIRECT, VHALF, or FLOAT.");
end

validateattributes(opt.averageCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 1, '<=', 1000});
opt.rowExtraGuardRows0 = unique(reshape(double(opt.rowExtraGuardRows0), 1, []));
validateattributes(opt.rowExtraGuardDiscardCount, {'numeric'}, ...
    {'scalar', 'integer', '>=', 0, '<=', 10});
opt.rowExtraGuardPause_s = max(0, opt.rowExtraGuardPause_s);
opt.postRowRereadRows0 = reshape(double(opt.postRowRereadRows0), 1, []);
opt.postRowRereadCols0 = reshape(double(opt.postRowRereadCols0), 1, []);
if numel(opt.postRowRereadRows0) ~= numel(opt.postRowRereadCols0)
    error("scan_cell_auto_retry_in_window:PostRowRereadSize", ...
        "postRowRereadRows0 and postRowRereadCols0 must have the same length.");
end
opt.postRowRereadPause_s = max(0, opt.postRowRereadPause_s);

if opt.averageCount == 1
    scan = scanOnce(dev, opt);
    scan.average_count = 1;
    return;
end

scans = cell(opt.averageCount, 1);
rows = cell(opt.averageCount, 1);
retryRows = cell(opt.averageCount, 1);
for rep = 1:opt.averageCount
    scans{rep} = scanOnce(dev, opt);
    T = scans{rep}.table;
    T.average_repeat_index = repmat(rep, height(T), 1);
    rows{rep} = T;

    R = scans{rep}.rawRetryTable;
    R.average_repeat_index = repmat(rep, height(R), 1);
    retryRows{rep} = R;
end

rawTable = vertcat(rows{:});
avgRows = cell(dev.NumRows * dev.NumCols, 1);
idx = 0;
for row0 = 0:dev.NumRows-1
    for col0 = 0:dev.NumCols-1
        idx = idx + 1;
        cellRows = rawTable(rawTable.row0 == row0 & rawTable.col0 == col0, :);
        avgRows{idx} = BasicArrayReader.averageDataRows(cellRows);
    end
end

scan = scans{end};
scan.command = scans{end}.command + "_MATLAB_AVG_" + string(opt.averageCount);
scan.table = vertcat(avgRows{:});
scan.rawAverageTable = rawTable;
scan.rawRetryTable = vertcat(retryRows{:});
scan.average_count = opt.averageCount;
scan.matrices = BasicArrayReader.tableToMatrices(scan.table, dev.NumRows, dev.NumCols);
scan.timestamp = datetime("now");
end

function scan = scanOnce(dev, opt)
startRF = string(opt.startRF);
firstCellStartRF = string(opt.firstCellStartRF);

dev.setDefaultReadoutBias();
resetRF(dev, startRF);
if opt.rowResetDelay_s > 0
    pause(opt.rowResetDelay_s);
end
status = dev.getStatus();

dataRows = cell(dev.NumRows * dev.NumCols, 1);
retryRows = cell(dev.NumRows * dev.NumCols, 1);
idx = 0;
for row0 = 0:dev.NumRows-1
    dev.setDefaultReadoutBias();
    if opt.rowResetDelay_s > 0
        pause(opt.rowResetDelay_s);
    end

    for col0 = 0:dev.NumCols-1
        idx = idx + 1;
        useFirstCellSequence = row0 == 0 && col0 == 0 && strlength(firstCellStartRF) > 0;
        if useFirstCellSequence
            fprintf("First %s cell row0 0 col0 0: RF %s, wait %.3g s, then read until stable...\n", ...
                opt.mode, firstCellStartRF, opt.firstCellSettle_s);
            [T, rawRetries] = readFirstCellSingleStyle(dev, row0, col0, opt, firstCellStartRF);
            if strlength(startRF) > 0 && startRF ~= firstCellStartRF
                dev.setRF(startRF);
            end
            T.first_cell_settle_s = opt.firstCellSettle_s;
            T.first_cell_start_rf = firstCellStartRF;
            T.first_cell_stable_rel_tol = opt.firstCellStableRelTol;
        else
            [T, rawRetries] = readAutoUntilInWindow(dev, row0, col0, opt);
            T.first_cell_settle_s = 0;
            T.first_cell_start_rf = "";
            T.first_cell_stable_rel_tol = NaN;
        end

        T.first_cell_sequence_used = useFirstCellSequence;
        T = tagAcceptedScanRow(T, opt, startRF, useFirstCellSequence, false, NaN);
        dataRows{idx} = T;
        retryRows{idx} = rawRetries;

        fprintf("row0 %d col0 %d | tries %d | RF %.6g ohm | Vadc %.6g V | R %.6g ohm | %s | %s\n", ...
            row0, col0, T.retry_attempt(1), T.rf_ohm(1), T.vadc_v(1), ...
            T.r_ohm(1), char(T.status(1)), char(T.retry_reason(1)));
    end

    postTargets = find(opt.postRowRereadRows0 == row0);
    for kk = 1:numel(postTargets)
        targetCol0 = opt.postRowRereadCols0(postTargets(kk));
        if targetCol0 < 0 || targetCol0 >= dev.NumCols
            error("scan_cell_auto_retry_in_window:InvalidPostRowRereadCell", ...
                "post-row reread col0 %g is outside 0..%d.", targetCol0, dev.NumCols - 1);
        end

        targetIdx = row0 * dev.NumCols + targetCol0 + 1;
        if opt.postRowRereadPause_s > 0
            pause(opt.postRowRereadPause_s);
        end

        fprintf("Post-row reread %s cell row0 %d col0 %d after row0 %d col0 %d; replacing original value...\n", ...
            opt.mode, row0, targetCol0, row0, dev.NumCols - 1);
        [Tpost, rawPost] = readAutoUntilInWindow(dev, row0, targetCol0, opt);
        Tpost.first_cell_settle_s = 0;
        Tpost.first_cell_start_rf = "";
        Tpost.first_cell_stable_rel_tol = NaN;
        Tpost.first_cell_sequence_used = false;
        Tpost = tagAcceptedScanRow(Tpost, opt, startRF, false, true, dev.NumCols - 1);
        Tpost.scan_method = "CELL_" + opt.mode + "_AUTO_RETRY_IN_WINDOW_POST_ROW_REREAD";

        dataRows{targetIdx} = Tpost;
        retryRows{targetIdx} = vertcat(retryRows{targetIdx}, rawPost);

        fprintf("replaced row0 %d col0 %d | tries %d | RF %.6g ohm | Vadc %.6g V | R %.6g ohm | %s | %s\n", ...
            row0, targetCol0, Tpost.retry_attempt(1), Tpost.rf_ohm(1), ...
            Tpost.vadc_v(1), Tpost.r_ohm(1), char(Tpost.status(1)), ...
            char(Tpost.retry_reason(1)));
    end
end

scan = struct();
scan.command = "CELL_" + opt.mode + "_AUTO_RETRY_IN_WINDOW";
scan.beginLine = "";
scan.endLine = "";
scan.lines = strings(0, 1);
scan.table = vertcat(dataRows{:});
scan.rawRetryTable = vertcat(retryRows{:});
scan.matrices = BasicArrayReader.tableToMatrices(scan.table, dev.NumRows, dev.NumCols);
scan.mode = opt.mode;
scan.autoRF = true;
scan.timestamp = datetime("now");
scan.header = struct("mode", opt.mode + "_AUTO_RETRY_IN_WINDOW", ...
    "numRows", dev.NumRows, "numCols", dev.NumCols, ...
    "VREAD", status.VREAD, "packet_avg", dev.PacketAverageCount, ...
    "auto_start_rf_name", startRF, "row_reset_delay_s", opt.rowResetDelay_s, ...
    "low_limit_v", opt.lowLimit_v, "high_limit_v", opt.highLimit_v, ...
    "max_cell_retry_attempts", opt.maxCellAttempts, ...
    "retry_pause_s", opt.retryPause_s, ...
    "first_cell_start_rf", firstCellStartRF, ...
    "first_cell_settle_s", opt.firstCellSettle_s, ...
    "first_cell_max_attempts", opt.firstCellMaxAttempts, ...
    "first_cell_retry_pause_s", opt.firstCellRetryPause_s, ...
    "first_cell_stable_rel_tol", opt.firstCellStableRelTol, ...
    "row_extra_guard_rows0", opt.rowExtraGuardRows0, ...
    "row_extra_guard_discard_count", opt.rowExtraGuardDiscardCount, ...
    "row_extra_guard_pause_s", opt.rowExtraGuardPause_s, ...
    "post_row_reread_rows0", opt.postRowRereadRows0, ...
    "post_row_reread_cols0", opt.postRowRereadCols0, ...
    "post_row_reread_pause_s", opt.postRowRereadPause_s);
end

function [accepted, rawRetries] = readAutoUntilInWindow(dev, row0, col0, opt)
rawRows = {};
accepted = table();
for k = 1:opt.maxCellAttempts
    guardRows = readRowExtraGuardDiscards(dev, row0, col0, opt, k);
    for g = 1:numel(guardRows)
        rawRows{end+1, 1} = guardRows{g}; %#ok<AGROW>
    end

    resetRF(dev, opt.startRF);
    T = dev.readCell(row0, col0, opt.mode, true);
    [inWindow, reason] = classifyRetryResult(T, opt.lowLimit_v, opt.highLimit_v);
    T.retry_attempt = repmat(k, height(T), 1);
    T.retry_in_window = repmat(inWindow, height(T), 1);
    T.retry_reason = repmat(reason, height(T), 1);
    T.retry_role = repmat("candidate", height(T), 1);
    T = tagRowExtraGuard(T, isRowExtraGuardEnabled(row0, opt), ...
        "candidate", 0, opt.rowExtraGuardDiscardCount);
    rawRows{end+1, 1} = T; %#ok<AGROW>

    if inWindow
        accepted = T;
        accepted.retry_role = "accepted_in_window";
        break;
    end

    if opt.retryPause_s > 0
        pause(opt.retryPause_s);
    end
end

rawRetries = vertcat(rawRows{:});
if isempty(accepted)
    accepted = BasicArrayReader.pickBestGuardedCandidate( ...
        rawRetries, opt.lowLimit_v, opt.highLimit_v);
    accepted.retry_role = "accepted_best_after_retry_limit";
    accepted.retry_reason = "MAX_RETRY_LIMIT";
    accepted.retry_in_window = false;
end
accepted.retry_total_reads = height(rawRetries);
end

function T = tagAcceptedScanRow(T, opt, startRF, useFirstCellSequence, ...
        postRowRereadReplacedValue, postRowRereadAfterCol0)
T.first_cell_sequence_used = repmat(logical(useFirstCellSequence), height(T), 1);
T.auto_start_rf_name = repmat(string(startRF), height(T), 1);
T.row_reset_delay_s = repmat(opt.rowResetDelay_s, height(T), 1);
T.retry_low_limit_v = repmat(opt.lowLimit_v, height(T), 1);
T.retry_high_limit_v = repmat(opt.highLimit_v, height(T), 1);
T.max_cell_retry_attempts = repmat(opt.maxCellAttempts, height(T), 1);
T.row_extra_guard_rows0 = repmat(rowListLabel(opt.rowExtraGuardRows0), height(T), 1);
T.row_extra_guard_discard_count_setting = repmat(opt.rowExtraGuardDiscardCount, height(T), 1);
T.row_extra_guard_pause_s = repmat(opt.rowExtraGuardPause_s, height(T), 1);
T.post_row_reread_target_cells = repmat(cellListLabel( ...
    opt.postRowRereadRows0, opt.postRowRereadCols0), height(T), 1);
T.post_row_reread_replaced_value = repmat(logical(postRowRereadReplacedValue), height(T), 1);
T.post_row_reread_after_col0 = repmat(postRowRereadAfterCol0, height(T), 1);
T.post_row_reread_pause_s = repmat(opt.postRowRereadPause_s, height(T), 1);
T.scan_method = repmat("CELL_" + opt.mode + "_AUTO_RETRY_IN_WINDOW", height(T), 1);
end

function [accepted, rawReads] = readFirstCellSingleStyle(dev, row0, col0, opt, startRF)
startRF = string(startRF);
dev.restoreDefaultReadoutState(dev.PacketAverageCount, startRF);
if opt.firstCellSettle_s > 0
    pause(opt.firstCellSettle_s);
end

rawRows = cell(opt.firstCellMaxAttempts, 1);
accepted = table();
previous = table();
for k = 1:opt.firstCellMaxAttempts
    resetRF(dev, startRF);
    T = dev.readCell(row0, col0, opt.mode, true);
    [inWindow, limitReason] = classifyRetryResult(T, opt.lowLimit_v, opt.highLimit_v);
    stable = false;
    if ~isempty(previous)
        stable = BasicArrayReader.isStableReadPair(previous, T, opt.firstCellStableRelTol);
    end

    T.retry_attempt = repmat(k, height(T), 1);
    T.retry_in_window = repmat(inWindow, height(T), 1);
    T.retry_role = repmat("first_cell_candidate", height(T), 1);
    T = tagRowExtraGuard(T, isRowExtraGuardEnabled(row0, opt), ...
        "first_cell_candidate", 0, opt.rowExtraGuardDiscardCount);
    if inWindow && stable
        T.retry_reason = repmat("FIRST_CELL_STABLE_ACCEPT", height(T), 1);
        accepted = T;
        accepted.retry_role = "accepted_first_cell_stable";
        rawRows{k} = T;
        break;
    elseif inWindow
        T.retry_reason = repmat("FIRST_CELL_WAIT_STABLE", height(T), 1);
    else
        T.retry_reason = repmat(limitReason, height(T), 1);
    end

    rawRows{k} = T;
    previous = T;
    if opt.firstCellRetryPause_s > 0
        pause(opt.firstCellRetryPause_s);
    end
end

rawReads = vertcat(rawRows{~cellfun(@isempty, rawRows)});
if isempty(accepted)
    goodRows = rawReads(rawReads.retry_in_window, :);
    if ~isempty(goodRows)
        accepted = goodRows(end, :);
    else
        accepted = BasicArrayReader.pickBestGuardedCandidate( ...
            rawReads, opt.lowLimit_v, opt.highLimit_v);
    end
    accepted.retry_role = "accepted_first_cell_best_after_retry_limit";
    accepted.retry_reason = "FIRST_CELL_MAX_STABILITY_RETRY";
    accepted.retry_in_window = ~BasicArrayReader.isLimitLikeRead( ...
        accepted, opt.lowLimit_v, opt.highLimit_v);
end
accepted.retry_total_reads = height(rawReads);
end

function discardRows = readRowExtraGuardDiscards(dev, row0, col0, opt, attempt)
discardRows = {};
if ~isRowExtraGuardEnabled(row0, opt)
    return;
end

for d = 1:opt.rowExtraGuardDiscardCount
    resetRF(dev, opt.startRF);
    Tdiscard = dev.readCell(row0, col0, opt.mode, true);
    Tdiscard.retry_attempt = repmat(attempt, height(Tdiscard), 1);
    Tdiscard.retry_in_window = false(height(Tdiscard), 1);
    Tdiscard.retry_reason = repmat("ROW_EXTRA_GUARD_DISCARD", height(Tdiscard), 1);
    Tdiscard.retry_role = repmat("row_extra_guard_discard", height(Tdiscard), 1);
    Tdiscard = tagRowExtraGuard(Tdiscard, true, ...
        "row_extra_guard_discard", d, opt.rowExtraGuardDiscardCount);
    discardRows{end+1, 1} = Tdiscard; %#ok<AGROW>
    if opt.rowExtraGuardPause_s > 0
        pause(opt.rowExtraGuardPause_s);
    end
end
end

function resetRF(dev, rfName)
rfName = string(rfName);
if strlength(rfName) > 0
    dev.setRF(rfName);
end
end

function tf = isRowExtraGuardEnabled(row0, opt)
tf = opt.rowExtraGuardDiscardCount > 0 && ismember(row0, opt.rowExtraGuardRows0);
end

function T = tagRowExtraGuard(T, enabled, role, readIndex, discardCount)
T.row_extra_guard_enabled = repmat(logical(enabled), height(T), 1);
T.row_extra_guard_role = repmat(string(role), height(T), 1);
T.row_extra_guard_read_index = repmat(readIndex, height(T), 1);
T.row_extra_guard_discard_count = repmat(discardCount, height(T), 1);
end

function label = rowListLabel(rows0)
if isempty(rows0)
    label = "";
else
    label = strjoin(string(rows0), ";");
end
end

function label = cellListLabel(rows0, cols0)
if isempty(rows0)
    label = "";
    return;
end

parts = strings(numel(rows0), 1);
for k = 1:numel(rows0)
    parts(k) = string(rows0(k)) + "," + string(cols0(k));
end
label = strjoin(parts, ";");
end

function [inWindow, reason] = classifyRetryResult(T, lowLimit_v, highLimit_v)
vadc = abs(T.vadc_v(1));
status = upper(string(T.status(1)));
if status ~= "OK"
    inWindow = false;
    reason = "STATUS_" + status;
elseif ~isfinite(vadc)
    inWindow = false;
    reason = "NONFINITE_ADC_RETRY";
elseif vadc < lowLimit_v
    inWindow = false;
    reason = "LOW_ADC_RETRY_RF_UP_OR_SWITCH";
elseif vadc > highLimit_v
    inWindow = false;
    reason = "HIGH_ADC_RETRY_RF_DOWN_OR_SWITCH";
else
    inWindow = true;
    reason = "OK_IN_WINDOW";
end
end
