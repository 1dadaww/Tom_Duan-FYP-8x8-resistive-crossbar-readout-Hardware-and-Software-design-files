classdef FundamentalNoiseReadoutApp < handle
    %FUNDAMENTALNOISEREADOUTAPP Live ADC noise, FFT, and resolution app.

    properties
        Fig
        LogArea
        PlotAxes
        HistAxes
        FFTAxes
        SampleTable
        SummaryTable
        PortField
        BaudField
        RowField
        ColField
        ModeDrop
        RFNameField
        NumSamplesField
        DelayUsField
        PacketAverageField
        MaxStreamSamplesField
        PlotDrop
        StatusLabel
        Dev
        ResultFolder string
        StopRequested logical = false
        LastSamples table = table()
        LastSummary table = table()
    end

    methods
        function app = FundamentalNoiseReadoutApp()
            app.ResultFolder = create_result_folder( ...
                "noise_readout_app_basic");
            app.buildUI();
            app.log("Noise app started. Results: " + app.ResultFolder);
        end

        function delete(app)
            app.disconnectDevice();
        end
    end

    methods (Access = private)
        function buildUI(app)
            app.Fig = uifigure('Name', ...
                'Fundamental ADC Noise and Resolution Readout', ...
                'Position', [60, 60, 1320, 800]);
            app.Fig.CloseRequestFcn = @(~, ~) app.closeApp();

            main = uigridlayout(app.Fig, [2, 3]);
            main.RowHeight = {'1x', 135};
            main.ColumnWidth = {330, '1x', '1x'};

            controls = uigridlayout(main, [18, 2]);
            controls.Layout.Row = 1;
            controls.Layout.Column = 1;
            controls.RowHeight = repmat({30}, 1, 18);
            controls.ColumnWidth = {120, '1x'};

            uilabel(controls, 'Text', 'Port');
            app.PortField = uieditfield(controls, 'text', 'Value', 'COM3');
            uilabel(controls, 'Text', 'Baud');
            app.BaudField = uieditfield(controls, 'numeric', ...
                'Value', 115200);
            app.addButton(controls, 'Connect', ...
                @(~, ~) app.onConnect(), [3, 1]);
            app.addButton(controls, 'Disconnect', ...
                @(~, ~) app.onDisconnect(), [3, 2]);
            app.addButton(controls, 'STATUS', ...
                @(~, ~) app.onStatus(), [4, 1]);
            app.addButton(controls, 'I2CSCAN', ...
                @(~, ~) app.onI2CScan(), [4, 2]);

            app.StatusLabel = uilabel(controls, 'Text', 'Disconnected');
            app.StatusLabel.Layout.Row = 5;
            app.StatusLabel.Layout.Column = [1, 2];

            uilabel(controls, 'Text', 'Row 0..7');
            app.RowField = uieditfield(controls, 'numeric', 'Value', 0, ...
                'Limits', [0, 7], 'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'Channel 0..7');
            app.ColField = uieditfield(controls, 'numeric', 'Value', 0, ...
                'Limits', [0, 7], 'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'Mode');
            app.ModeDrop = uidropdown(controls, ...
                'Items', {'DIRECT', 'VHALF'}, 'Value', 'DIRECT');
            uilabel(controls, 'Text', 'RF name');
            app.RFNameField = uieditfield(controls, 'text', 'Value', '10k');
            app.addButton(controls, 'Setup Path', ...
                @(~, ~) app.onSetupNoise(), [10, 1]);

            uilabel(controls, 'Text', 'Samples');
            app.NumSamplesField = uieditfield(controls, 'numeric', ...
                'Value', 1000, 'Limits', [1, Inf], ...
                'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'Delay / us');
            app.DelayUsField = uieditfield(controls, 'numeric', ...
                'Value', 1000, 'Limits', [0, Inf], ...
                'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'ESP avg');
            app.PacketAverageField = uieditfield(controls, 'numeric', ...
                'Value', 1, 'Limits', [1, 1000], ...
                'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'Stream max');
            app.MaxStreamSamplesField = uieditfield(controls, 'numeric', ...
                'Value', 5000, 'Limits', [1, Inf], ...
                'RoundFractionalValues', 'on');
            uilabel(controls, 'Text', 'Plot');
            app.PlotDrop = uidropdown(controls, ...
                'Items', {'vadc_v', 'adc_raw', 'current_a'}, ...
                'Value', 'vadc_v');

            app.addButton(controls, 'Read Block', ...
                @(~, ~) app.onReadBlock(), [15, 1]);
            app.addButton(controls, 'Start Stream', ...
                @(~, ~) app.onStartStream(), [15, 2]);
            app.addButton(controls, 'Stop', ...
                @(~, ~) app.onStop(), [16, 1]);
            app.addButton(controls, 'Save', ...
                @(~, ~) app.onSave(), [16, 2]);
            app.addButton(controls, 'FFT', ...
                @(~, ~) app.onFFT(), [17, 1]);

            plots = uigridlayout(main, [3, 1]);
            plots.Layout.Row = 1;
            plots.Layout.Column = 2;
            plots.RowHeight = {'1x', '1x', '1x'};
            app.PlotAxes = uiaxes(plots);
            app.HistAxes = uiaxes(plots);
            app.FFTAxes = uiaxes(plots);
            title(app.PlotAxes, 'Live readout');
            title(app.HistAxes, 'Histogram');
            title(app.FFTAxes, 'FFT');
            grid(app.PlotAxes, 'on');
            grid(app.HistAxes, 'on');
            grid(app.FFTAxes, 'on');

            right = uigridlayout(main, [2, 1]);
            right.Layout.Row = 1;
            right.Layout.Column = 3;
            right.RowHeight = {'1x', 180};
            app.SampleTable = uitable(right);
            app.SummaryTable = uitable(right);

            app.LogArea = uitextarea(main, 'Editable', 'off');
            app.LogArea.Layout.Row = 2;
            app.LogArea.Layout.Column = [1, 3];
        end

        function onConnect(app)
            app.runSafe(@connectImpl);
            function connectImpl()
                app.disconnectDevice();
                app.Dev = BasicNoiseArrayReader( ...
                    string(app.PortField.Value), app.BaudField.Value);
                app.Dev.connect();
                app.Dev.setDefaultReadoutBias();
                app.StatusLabel.Text = ...
                    "Connected to " + string(app.PortField.Value);
                app.log("Connected.");
            end
        end

        function onDisconnect(app)
            app.runSafe(@disconnectImpl);
            function disconnectImpl()
                app.disconnectDevice();
                app.StatusLabel.Text = "Disconnected";
                app.log("Disconnected.");
            end
        end

        function onStatus(app)
            app.runSafe(@statusImpl);
            function statusImpl()
                app.assertConnected();
                status = app.Dev.getStatus();
                app.log(sprintf( ...
                    "STATUS: VREAD %.6g V, VCM %.6g V, VSEL %.6g V", ...
                    status.VREAD, status.VCM, status.VSEL));
            end
        end

        function onI2CScan(app)
            app.runSafe(@scanImpl);
            function scanImpl()
                app.assertConnected();
                out = app.Dev.i2cScan();
                app.SummaryTable.Data = out.expectedFound;
                app.log("I2CSCAN complete.");
            end
        end

        function onSetupNoise(app)
            app.runSafe(@setupImpl);
            function setupImpl()
                app.assertConnected();
                app.Dev.setDefaultReadoutBias();
                setup = app.Dev.setupNoiseReadout( ...
                    round(app.RowField.Value), round(app.ColField.Value), ...
                    string(app.ModeDrop.Value), ...
                    string(app.RFNameField.Value));
                app.log(sprintf( ...
                    "Path set: row %d, channel %d, %s, RF %s (%.6g ohm)", ...
                    setup.row0, setup.col0, setup.mode, ...
                    setup.rfName, setup.rf_ohm));
            end
        end

        function onReadBlock(app)
            app.runSafe(@readImpl);
            function readImpl()
                app.assertConnected();
                app.applyPacketAverage();
                app.StopRequested = false;
                out = app.Dev.readNoiseSamples( ...
                    round(app.NumSamplesField.Value), ...
                    round(app.DelayUsField.Value));
                app.LastSamples = out.table;
                app.updateViews();
                app.log(sprintf("Read %d samples.", ...
                    height(app.LastSamples)));
            end
        end

        function onStartStream(app)
            app.runSafe(@streamImpl);
            function streamImpl()
                app.assertConnected();
                app.applyPacketAverage();
                app.StopRequested = false;
                maxSamples = round(app.MaxStreamSamplesField.Value);
                rows = cell(maxSamples, 1);
                count = 0;
                app.LastSamples = table();
                app.Dev.startNoiseStream(round(app.DelayUsField.Value));
                app.log("Noise stream started.");

                while ~app.StopRequested && count < maxSamples
                    item = app.Dev.readNoiseStreamItem(1);
                    if istable(item)
                        count = count + 1;
                        rows{count} = item;
                        if count == 1 || mod(count, 10) == 0
                            app.LastSamples = vertcat(rows{1:count});
                            app.updateViews(false);
                        end
                    elseif isstruct(item) && isfield(item, "type") && ...
                            item.type == "end_stream"
                        break;
                    end
                    drawnow;
                end

                if app.StopRequested
                    try
                        app.Dev.stopNoiseStream(2);
                    catch ME
                        app.log("Stop warning: " + string(ME.message));
                    end
                end
                if count > 0
                    app.LastSamples = vertcat(rows{1:count});
                else
                    app.LastSamples = table();
                end
                app.updateViews();
                app.StopRequested = false;
                app.log(sprintf("Captured %d streamed samples.", count));
            end
        end

        function onStop(app)
            app.StopRequested = true;
            app.log("Stop requested.");
        end

        function onSave(app)
            app.runSafe(@saveImpl);
            function saveImpl()
                app.assertSamples();
                folder = app.createOutputFolder("save");
                write_table_compatible(app.LastSamples, ...
                    fullfile(folder, "noise_samples.csv"));
                write_table_compatible(app.LastSummary, ...
                    fullfile(folder, "noise_summary.csv"));
                samples = app.LastSamples;
                summary = app.LastSummary;
                save(fullfile(folder, "noise_readout_outputs.mat"), ...
                    "samples", "summary");
                app.log("Saved noise outputs to " + folder);
            end
        end

        function onFFT(app)
            app.runSafe(@fftImpl);
            function fftImpl()
                app.assertSamples();
                metric = string(app.PlotDrop.Value);
                fftOut = compute_basic_noise_fft(app.LastSamples, metric);
                bits = estimate_basic_noise_effective_bits(app.LastSamples);
                plot_basic_noise_fft(fftOut, app.FFTAxes, ...
                    "FFT: " + metric);
                fftSummary = table(fftOut.numSamples, ...
                    fftOut.sampleRate_hz, ...
                    fftOut.frequencyResolution_hz, fftOut.nyquist_hz, ...
                    fftOut.timestampJitter_s, fftOut.peakFrequency_hz, ...
                    fftOut.peakAmplitude, bits.effectiveBits, ...
                    bits.rmsNoiseCodes, bits.adcBitsAssumed, ...
                    'VariableNames', {'numSamples', 'sampleRate_hz', ...
                    'frequencyResolution_hz', 'nyquist_hz', ...
                    'timestampJitter_s', 'peakFrequency_hz', ...
                    'peakAmplitude', 'effective_bits', ...
                    'rms_noise_codes', 'adc_bits_assumed'});
                app.SummaryTable.Data = fftSummary;

                folder = app.createOutputFolder("fft");
                write_table_compatible(fftOut.table, ...
                    fullfile(folder, "noise_fft_spectrum.csv"));
                write_table_compatible(fftSummary, ...
                    fullfile(folder, "noise_fft_summary.csv"));
                exportgraphics(app.FFTAxes, ...
                    fullfile(folder, "noise_fft_plot.png"), ...
                    'Resolution', 300);
                app.log(sprintf( ...
                    "FFT: Fs %.3f Hz, resolution %.3f Hz, peak %.3f Hz.", ...
                    fftOut.sampleRate_hz, ...
                    fftOut.frequencyResolution_hz, ...
                    fftOut.peakFrequency_hz));
            end
        end

        function updateViews(app, updateTable)
            if nargin < 2
                updateTable = true;
            end
            T = app.LastSamples;
            if isempty(T) || height(T) == 0
                return;
            end
            metric = string(app.PlotDrop.Value);
            y = T.(metric);
            plot(app.PlotAxes, T.sampleIndex, y, "-");
            title(app.PlotAxes, "Live " + metric, 'Interpreter', 'none');
            xlabel(app.PlotAxes, "Sample index");
            ylabel(app.PlotAxes, metric, 'Interpreter', 'none');
            grid(app.PlotAxes, "on");

            histogram(app.HistAxes, y);
            title(app.HistAxes, "Histogram: " + metric, ...
                'Interpreter', 'none');
            xlabel(app.HistAxes, metric, 'Interpreter', 'none');
            ylabel(app.HistAxes, "Count");
            grid(app.HistAxes, "on");

            if height(T) >= 4
                fftOut = compute_basic_noise_fft(T, metric);
                plot_basic_noise_fft(fftOut, app.FFTAxes, ...
                    "FFT preview: " + metric);
            end
            app.LastSummary = app.computeSummary(T);
            app.SummaryTable.Data = app.LastSummary;
            if updateTable
                app.SampleTable.Data = T;
            end
            drawnow limitrate;
        end

        function S = computeSummary(~, T)
            dtUs = diff(T.timestamp_us);
            if isempty(dtUs)
                meanDtUs = nan;
                stdDtUs = nan;
            else
                meanDtUs = mean(dtUs, "omitnan");
                stdDtUs = std(dtUs, "omitnan");
            end
            bits = estimate_basic_noise_effective_bits(T);
            S = table(height(T), T.channel0(1), ...
                mean(T.adc_raw, "omitnan"), std(T.adc_raw, "omitnan"), ...
                max(T.adc_raw) - min(T.adc_raw), ...
                mean(T.vadc_v, "omitnan"), std(T.vadc_v, "omitnan"), ...
                max(T.vadc_v) - min(T.vadc_v), ...
                mean(T.current_a, "omitnan"), ...
                std(T.current_a, "omitnan"), ...
                max(T.current_a) - min(T.current_a), ...
                meanDtUs, stdDtUs, bits.effectiveBits, ...
                bits.rmsNoiseCodes, bits.adcBitsAssumed, ...
                'VariableNames', {'numSamples', 'channel0', ...
                'mean_raw', 'std_raw', 'pp_raw', 'mean_v', 'std_v', ...
                'pp_v', 'mean_i', 'std_i', 'pp_i', 'mean_dt_us', ...
                'std_dt_us', 'effective_bits', 'rms_noise_codes', ...
                'adc_bits_assumed'});
        end

        function applyPacketAverage(app)
            count = round(app.PacketAverageField.Value);
            app.Dev.setPacketAverage(count);
            app.log(sprintf("ESP packet average set to %d.", count));
        end

        function addButton(~, parent, label, callback, location)
            button = uibutton(parent, 'Text', label, ...
                'ButtonPushedFcn', callback);
            button.Layout.Row = location(1);
            button.Layout.Column = location(2);
        end

        function assertConnected(app)
            if isempty(app.Dev) || isempty(app.Dev.Serial)
                error("Connect to the ESP32 first.");
            end
        end

        function assertSamples(app)
            if isempty(app.LastSamples) || height(app.LastSamples) == 0
                error("Read a block or capture a stream first.");
            end
        end

        function folder = createOutputFolder(app, prefix)
            stamp = string(datetime("now", ...
                "Format", "yyyyMMdd_HHmmss_SSS"));
            folder = string(fullfile(app.ResultFolder, ...
                prefix + "_" + stamp));
            suffix = 1;
            while exist(folder, 'dir')
                suffix = suffix + 1;
                folder = string(fullfile(app.ResultFolder, ...
                    prefix + "_" + stamp + "_" + string(suffix)));
            end
            mkdir(folder);
        end

        function disconnectDevice(app)
            try
                if ~isempty(app.Dev)
                    app.Dev.disconnect();
                end
            catch
            end
            app.Dev = [];
        end

        function runSafe(app, callback)
            try
                callback();
            catch ME
                app.log("ERROR: " + string(ME.message));
                try
                    if isvalid(app.Fig)
                        uialert(app.Fig, ME.message, "Error");
                    end
                catch
                end
            end
        end

        function log(app, message)
            if isempty(app.LogArea) || ~isvalid(app.LogArea)
                return;
            end
            stamp = string(datetime("now", "Format", "HH:mm:ss"));
            app.LogArea.Value = [app.LogArea.Value; ...
                stamp + "  " + string(message)];
            drawnow limitrate;
        end

        function closeApp(app)
            app.StopRequested = true;
            app.disconnectDevice();
            if ~isempty(app.Fig) && isvalid(app.Fig)
                app.Fig.CloseRequestFcn = [];
                delete(app.Fig);
            end
        end
    end
end
