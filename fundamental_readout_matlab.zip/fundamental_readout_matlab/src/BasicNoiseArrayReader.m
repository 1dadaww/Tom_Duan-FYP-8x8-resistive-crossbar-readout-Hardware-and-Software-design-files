classdef BasicNoiseArrayReader < BasicArrayReader
    %BASICNOISEARRAYREADER Fundamental reader extended with noise commands.

    methods
        function obj = BasicNoiseArrayReader(portName, baudRate)
            obj@BasicArrayReader(portName, baudRate);
        end

        function setup = setupNoiseReadout(obj, row0, col0, mode, rfName)
            validateattributes(row0, {'numeric'}, {'integer', '>=', 0, '<=', 7});
            validateattributes(col0, {'numeric'}, {'integer', '>=', 0, '<=', 7});
            mode = upper(string(mode));
            if mode ~= "DIRECT" && mode ~= "VHALF"
                error("BasicNoiseArrayReader:InvalidMode", ...
                    "mode must be DIRECT or VHALF.");
            end

            cmd = sprintf("NOISE_SETUP %d %d %s %s", ...
                row0, col0, mode, char(string(rfName)));
            obj.flushInput();
            obj.sendCommand(cmd);
            line = obj.readUntilAny(["NOISE_SETUP_OK,", "ERROR,"], ...
                obj.DefaultTimeout);
            if startsWith(line, "ERROR,")
                error("BasicNoiseArrayReader:FirmwareError", "%s", line);
            end
            setup = BasicNoiseArrayReader.parseNoiseSetupLine(line);
        end

        function out = readNoiseSamples(obj, numSamples, sampleDelayUs, timeout_s)
            validateattributes(numSamples, {'numeric'}, ...
                {'scalar', 'integer', '>=', 1});
            validateattributes(sampleDelayUs, {'numeric'}, ...
                {'scalar', 'integer', '>=', 0});
            if nargin < 4 || isempty(timeout_s)
                timeout_s = max(obj.DefaultTimeout, ...
                    2 + double(numSamples) * double(sampleDelayUs) / 1e6);
            end

            cmd = sprintf("NOISE_READ %d %d", numSamples, sampleDelayUs);
            obj.flushInput();
            obj.sendCommand(cmd);
            out = obj.collectNoiseRead(numSamples, timeout_s);
            out.command = cmd;
        end

        function response = startNoiseStream(obj, sampleDelayUs)
            validateattributes(sampleDelayUs, {'numeric'}, ...
                {'scalar', 'integer', '>=', 0});
            cmd = sprintf("NOISE_STREAM %d", sampleDelayUs);
            obj.flushInput();
            obj.sendCommand(cmd);
            line = obj.readUntilAny(["NOISE_STREAM_OK,", "ERROR,"], ...
                obj.DefaultTimeout);
            if startsWith(line, "ERROR,")
                error("BasicNoiseArrayReader:FirmwareError", "%s", line);
            end
            p = split(line, ",");
            response = struct("rawLine", line, ...
                "channel0", str2double(p(2)), ...
                "sampleDelayUs", str2double(p(3)));
        end

        function out = stopNoiseStream(obj, timeout_s)
            if nargin < 2 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end
            obj.sendCommand("NOISE_STOP");
            line = obj.readUntilAny(["END_NOISE_STREAM,", "ERROR,"], timeout_s);
            if startsWith(line, "ERROR,")
                error("BasicNoiseArrayReader:FirmwareError", "%s", line);
            end
            p = split(line, ",");
            out = struct("rawLine", line, "numSamples", str2double(p(2)));
        end

        function item = readNoiseStreamItem(obj, timeout_s)
            if nargin < 2 || isempty(timeout_s)
                timeout_s = obj.DefaultTimeout;
            end
            line = obj.readUntilAny(["ADC_SAMPLE,", "ADC_SUMMARY,", ...
                "END_NOISE_STREAM,", "ERROR,"], timeout_s);
            if startsWith(line, "ERROR,")
                error("BasicNoiseArrayReader:FirmwareError", "%s", line);
            elseif startsWith(line, "ADC_SAMPLE,")
                item = BasicNoiseArrayReader.parseADCSampleLine(line);
            elseif startsWith(line, "ADC_SUMMARY,")
                item = BasicNoiseArrayReader.parseADCSummaryLine(line);
            else
                p = split(line, ",");
                item = struct("type", "end_stream", "rawLine", line, ...
                    "numSamples", str2double(p(2)));
            end
        end
    end

    methods (Access = private)
        function out = collectNoiseRead(obj, expectedSamples, timeout_s)
            samples = {};
            summary = struct();
            endLine = "";
            originalTimeout = obj.Serial.Timeout;
            obj.Serial.Timeout = min(max(timeout_s, 1), 10);
            cleanup = onCleanup(@() restoreSerialTimeout( ...
                obj.Serial, originalTimeout)); %#ok<NASGU>

            t0 = tic;
            while toc(t0) < timeout_s
                try
                    line = strtrim(string(readline(obj.Serial)));
                catch
                    continue;
                end
                if strlength(line) == 0
                    continue;
                elseif startsWith(line, "ADC_SAMPLE,")
                    samples{end+1, 1} = ...
                        BasicNoiseArrayReader.parseADCSampleLine(line); %#ok<AGROW>
                elseif startsWith(line, "ADC_SUMMARY,")
                    summary = BasicNoiseArrayReader.parseADCSummaryLine(line);
                elseif startsWith(line, "END_NOISE_READ,")
                    endLine = line;
                    break;
                elseif startsWith(line, "ERROR,")
                    error("BasicNoiseArrayReader:FirmwareError", "%s", line);
                end
            end

            if strlength(endLine) == 0
                error("BasicNoiseArrayReader:Timeout", ...
                    "Timed out waiting for END_NOISE_READ after %.1f s.", ...
                    timeout_s);
            end
            if isempty(samples)
                T = table();
            else
                T = vertcat(samples{:});
            end
            out = struct("table", T, "summary", summary, ...
                "endLine", endLine, "expectedSamples", expectedSamples);
        end
    end

    methods (Static)
        function setup = parseNoiseSetupLine(line)
            line = strtrim(string(line));
            if ~startsWith(line, "NOISE_SETUP_OK,")
                error("BasicNoiseArrayReader:ParseError", ...
                    "Not a NOISE_SETUP_OK line: %s", line);
            end
            p = split(line, ",");
            if numel(p) < 6
                error("BasicNoiseArrayReader:ParseError", ...
                    "NOISE_SETUP_OK line has too few fields: %s", line);
            end
            setup = struct("rawLine", line, "row0", str2double(p(2)), ...
                "col0", str2double(p(3)), "mode", string(p(4)), ...
                "rfName", string(p(5)), "rf_ohm", str2double(p(6)));
        end

        function T = parseADCSampleLine(line)
            line = strtrim(string(line));
            if ~startsWith(line, "ADC_SAMPLE,")
                error("BasicNoiseArrayReader:ParseError", ...
                    "Not an ADC_SAMPLE line: %s", line);
            end
            p = split(line, ",");
            if numel(p) < 8
                error("BasicNoiseArrayReader:ParseError", ...
                    "ADC_SAMPLE line has too few fields: %s", line);
            end
            sampleIndex = str2double(p(2));
            channel0 = str2double(p(3));
            adc_raw = str2double(p(4));
            vadc_v = str2double(p(5));
            current_a = str2double(p(6));
            rf_ohm = str2double(p(7));
            timestamp_us = str2double(p(8));
            packet_avg = BasicArrayReader.parseOptionalNumericField( ...
                p, "AVG", nan);
            T = table(sampleIndex, channel0, adc_raw, vadc_v, current_a, ...
                rf_ohm, timestamp_us, packet_avg);
        end

        function summary = parseADCSummaryLine(line)
            line = strtrim(string(line));
            if ~startsWith(line, "ADC_SUMMARY,")
                error("BasicNoiseArrayReader:ParseError", ...
                    "Not an ADC_SUMMARY line: %s", line);
            end
            p = split(line, ",");
            if numel(p) < 12
                error("BasicNoiseArrayReader:ParseError", ...
                    "ADC_SUMMARY line has too few fields: %s", line);
            end
            summary = struct("rawLine", line, ...
                "channel0", str2double(p(2)), ...
                "numSamples", str2double(p(3)), ...
                "mean_raw", str2double(p(4)), ...
                "std_raw", str2double(p(5)), ...
                "pp_raw", str2double(p(6)), ...
                "mean_v", str2double(p(7)), ...
                "std_v", str2double(p(8)), ...
                "pp_v", str2double(p(9)), ...
                "mean_i", str2double(p(10)), ...
                "std_i", str2double(p(11)), ...
                "pp_i", str2double(p(12)), ...
                "packet_avg", BasicArrayReader.parseOptionalNumericField( ...
                    p, "AVG", nan));
        end
    end
end

function restoreSerialTimeout(serialObject, timeoutValue)
try
    serialObject.Timeout = timeoutValue;
catch
end
end
