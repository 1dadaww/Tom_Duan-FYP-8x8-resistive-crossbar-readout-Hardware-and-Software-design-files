# ESP32 Resistive-Array Readout Firmware

PlatformIO firmware for the ESP32-controlled 8x8 selectorless resistive-array
readout board. The firmware controls the bias DAC, analogue switch matrix,
feedback-resistor selection, eight-channel ADC acquisition, noise capture, and
binary vector-matrix multiplication.

## Build

Requirements:

- Visual Studio Code with PlatformIO, or PlatformIO Core
- DFRobot FireBeetle ESP32 board
- USB serial connection at 115200 baud

Build and upload the normal firmware:

```text
pio run -e firebeetle32
pio run -e firebeetle32 -t upload
```

Build the hardware-diagnostic firmware:

```text
pio run -e hardware_debug
```

## Project Structure

- `src/main.cpp`: normal serial-command firmware
- `src/hardware_debug.cpp`: interactive hardware diagnostic build
- `include/`: board pin, switch-map, configuration, and data definitions
- `lib/ADS131M08/`: ADC driver
- `lib/DAC80502/`: DAC driver
- `lib/SwitchMatrix/`: row, column, and feedback-switch control
- `lib/MeasurementEngine/`: bias, acquisition, auto-ranging, and VMM logic
- `platformio.ini`: build environments and dependencies

## Serial Interface

Send `HELP` after connecting to list all supported commands. Principal command
groups include:

- status and diagnostics: `STATUS`, `I2CSCAN`, `RFSTATUS`
- bias and averaging: `BIAS`, `SETBIAS`, `SETAVG`
- feedback selection: `RF`, `RFCH`
- cell measurements: `CELL_DIRECT`, `CELL_VHALF`, `CELL_FLOAT` and auto-RF variants
- full scans: `SCAN_DIRECT`, `SCAN_VHALF`, `SCAN_FLOAT` and auto-RF variants
- noise acquisition: `NOISE_SETUP`, `NOISE_READ`, `NOISE_STREAM`, `NOISE_STOP`
- binary VMM: `VMM`, `VMMBIN`

The MATLAB project supplied alongside this firmware provides example scripts
for these measurement workflows.
