#pragma once

#include <Arduino.h>

// -----------------------------------------------------------------------------
// Measurement configuration
// -----------------------------------------------------------------------------

static constexpr float DAC_REF_VOLTS = 2.500f;        // DAC80502 external reference voltage
static constexpr float DAC_OUTPUT_GAIN = 1.0f;        // effective full-scale gain after DAC config below

// DAC80502 startup configuration.
// Current board assumption: external 2.5 V reference connected to VREFIO.
// CONFIG 0x0100 disables the internal reference for external-reference operation.
// GAIN 0x0103 enables reference divide-by-2 and 2x buffer gain for 3.3 V operation,
// giving an effective 0 V to 2.5 V DAC output range with a 2.5 V reference.
static constexpr bool DAC_USE_EXTERNAL_REFERENCE = true;
static constexpr uint16_t DAC_CONFIG_REGISTER_VALUE = 0x0100;
static constexpr uint16_t DAC_GAIN_REGISTER_VALUE = 0x0103;

static constexpr float ADC_REF_VOLTS = 1.200f;        // ADS131M08 internal reference typical nominal
static constexpr float ADC_PGA_GAIN = 1.0f;

static constexpr uint32_t ANALOG_SETTLE_US = 200000;  // baseline settle time after row/column changes
static constexpr uint32_t ADC_DRDY_TIMEOUT_US = 100000;

// Binary VMM safety and settling settings used by SETBIAS, VMM, and VMMBIN.
static constexpr float VMM_MAX_SAFE_DELTA_V = 0.200f;
static constexpr float VMM_MIN_SAFE_BIAS_V = 0.0f;
static constexpr float VMM_MAX_SAFE_BIAS_V = DAC_REF_VOLTS * DAC_OUTPUT_GAIN;
static constexpr uint32_t VMM_DAC_SETTLE_US = 1000;
static constexpr uint32_t VMM_ROW_SETTLE_US = 500;
static constexpr uint32_t VMM_COLUMN_SETTLE_US = 500;

// ADC/readout noise-test mode. The analogue path is configured once by
// NOISE_SETUP, then the ADC is sampled repeatedly without row/column/RF changes.
static constexpr uint32_t MAX_NOISE_SAMPLES = 20000;
static constexpr uint32_t MIN_NOISE_SAMPLE_DELAY_US = 0;

// Small denominator guard used when converting ADC voltage to resistance.
static constexpr float MIN_VALID_ADC_DIFF_VOLTS = 1.0e-6f;

// Serial output formatting
static constexpr uint32_t SERIAL_BAUD = 115200;

// -----------------------------------------------------------------------------
// Operation-mode switch polarity
// -----------------------------------------------------------------------------
// IC2 ADG734 operation-mode switch wiring:
//   IN1 = ROW_IDLE_MODE, S1A = VCM_DIST, S1B = VHALF_DIST, D1 = ROW_IDLE_BUS.
// For the current firmware convention:
//   Direct mode -> GPIO27 HIGH -> ROW_IDLE_BUS = VCM_DIST.
//   V/2 mode    -> GPIO27 LOW  -> ROW_IDLE_BUS = VHALF_DIST.
// Verify this with TP6 before array measurements.
static constexpr uint8_t ROW_IDLE_MODE_DIRECT_LEVEL = HIGH;
static constexpr uint8_t ROW_IDLE_MODE_VHALF_LEVEL  = LOW;

// ADG734 selector logic used for row-idle and column-mode switches. These are
// kept configurable because they are easy to verify with a DMM during bring-up.
static constexpr bool ROW_IDLE_ENABLE_ACTIVE_HIGH = true; // true: ROWx_IDLE_EN high connects row to ROW_IDLE_BUS
static constexpr bool COL_MODE_TIA_LEVEL_HIGH = true;     // true: COLx_MODE high connects column to TIAx_SUM

// -----------------------------------------------------------------------------
// RF auto-ranging configuration
// -----------------------------------------------------------------------------
// Auto-ranging tries to keep |VADC_DIFF| between LOW and HIGH. If the amplitude
// is too low, it increases RF. If the amplitude is too high or saturated, it
// decreases RF. For unknown cells, start low-gain at RF=100 ohm.
static constexpr float AUTORANGE_VADC_LOW  = 0.080f;   // 80 mV: increase RF below this
static constexpr float AUTORANGE_VADC_HIGH = 1.050f;   // 1.05 V: decrease RF above this
static constexpr float AUTORANGE_VADC_SAT  = 1.050f;   // saturation guard, adjust to ADC setup
static constexpr uint8_t AUTORANGE_MAX_STEPS = 7;
static constexpr uint32_t AUTORANGE_SETTLE_US = 2000;
static constexpr uint16_t AUTORANGE_ADC_AVG = 4;

// Default ADC averaging for normal manual scans.
static constexpr uint16_t DEFAULT_ADC_AVG = 1;
static constexpr uint16_t MAX_PACKET_ADC_AVG = 1000;
