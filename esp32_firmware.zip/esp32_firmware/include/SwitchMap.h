#pragma once

#include <Arduino.h>
#include "ReadTypes.h"
#include "ProjectConfig.h"

// -----------------------------------------------------------------------------
// SwitchMap.h for the uploaded schematic
//
// MCP23017 addresses inferred from the A0/A1/A2 strap pattern in the schematic:
//   U7 -> 0x20: row idle + row select
//   U8 -> 0x21: column mode + RF 1M
//   U4 -> 0x22: RF 100 + RF 1k
//   U5 -> 0x23: RF 100k + RF 10k
//
// Adafruit_MCP23X17 pin numbering:
//   0..7   = GPA0..GPA7
//   8..15  = GPB0..GPB7
//
// ADG734 convention used by this firmware is configurable in ProjectConfig.h.
// Verify ROW_IDLE_MODE at TP6 before measurements.
//
// Based on the schematic connections:
//   ROW_IDLE_EN uses ADG734 with ROW_IDLE_BUS on one throw and NC on the other.
//       activeHigh comes from ROW_IDLE_ENABLE_ACTIVE_HIGH in ProjectConfig.h.
//   COLx_MODE uses ADG734 with TIAx_SUM on SxA and VHALF_DIST on SxB.
//       LOW = TIA, HIGH = VHALF.
//   ROWx_SEL_EN and RFx_EN use TMUX1112 switches and are treated active-high.
// -----------------------------------------------------------------------------

struct SwitchLine {
    uint8_t chip;
    uint8_t pin;
    bool activeHigh;
};

static constexpr SwitchLine UNUSED_SWITCH = {255, 255, true};

// U7, address 0x20
// GPA0..GPA7 = ROW0_IDLE_EN..ROW7_IDLE_EN, active-low through ADG734 SxA.
static constexpr SwitchLine ROW_IDLE_EN[NUM_ROWS] = {
    {0, 0, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 1, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 2, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 3, ROW_IDLE_ENABLE_ACTIVE_HIGH},
    {0, 4, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 5, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 6, ROW_IDLE_ENABLE_ACTIVE_HIGH}, {0, 7, ROW_IDLE_ENABLE_ACTIVE_HIGH}
};

// U7, address 0x20
// GPB0..GPB7 = ROW0_SEL_EN..ROW7_SEL_EN, active-high TMUX1112 select.
static constexpr SwitchLine ROW_SEL_EN[NUM_ROWS] = {
    {0, 8, true},  {0, 9, true},  {0, 10, true}, {0, 11, true},
    {0, 12, true}, {0, 13, true}, {0, 14, true}, {0, 15, true}
};

// U8, address 0x21
// GPA0..GPA7 = COL0_MODE..COL7_MODE.
// LOW = connect COLx to TIAx_SUM. HIGH = park COLx at VHALF_DIST.
static constexpr SwitchLine COL_MODE[NUM_COLS] = {
    {1, 0, true}, {1, 1, true}, {1, 2, true}, {1, 3, true},
    {1, 4, true}, {1, 5, true}, {1, 6, true}, {1, 7, true}
};

// RF feedback branch switches.
// Range order in ReadTypes.h:
//   0 = 100 ohm, 1 = 1k, 2 = 10k, 3 = 100k, 4 = 1M
//
// U4, address 0x22: GPB0..GPB7 = RF100_EN0..7, GPA0..GPA7 = RF1K_EN0..7
// U5, address 0x23: GPA0..GPA7 = RF10K_EN0..7, GPB0..GPB7 = RF100K_EN0..7
// U8, address 0x21: GPB0..GPB7 = RF1M_EN0..7
static constexpr SwitchLine RF_EN[NUM_COLS][NUM_RF_RANGES] = {
    { {2, 8, true}, {2, 0, true}, {3, 0, true}, {3, 8, true}, {1, 8, true} },
    { {2, 9, true}, {2, 1, true}, {3, 1, true}, {3, 9, true}, {1, 9, true} },
    { {2,10, true}, {2, 2, true}, {3, 2, true}, {3,10, true}, {1,10, true} },
    { {2,11, true}, {2, 3, true}, {3, 3, true}, {3,11, true}, {1,11, true} },
    { {2,12, true}, {2, 4, true}, {3, 4, true}, {3,12, true}, {1,12, true} },
    { {2,13, true}, {2, 5, true}, {3, 5, true}, {3,13, true}, {1,13, true} },
    { {2,14, true}, {2, 6, true}, {3, 6, true}, {3,14, true}, {1,14, true} },
    { {2,15, true}, {2, 7, true}, {3, 7, true}, {3,15, true}, {1,15, true} }
};
