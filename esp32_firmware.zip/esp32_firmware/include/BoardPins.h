#pragma once

#include <Arduino.h>

// -----------------------------------------------------------------------------
// BoardPins.h for DFRobot DFR0478 FireBeetle ESP32
// Project: selectorless 8x8 resistive-array reader
//
// This version uses your updated hardware change:
//   ROW_IDLE_MODE -> IO27 / D4
//
// IC2 operation-mode ADG734 wiring from the schematic:
//   IN1 = ROW_IDLE_MODE
//   S1A = VCM_DIST
//   D1  = ROW_IDLE_BUS
//   S1B = VHALF_DIST
//
// Firmware convention used after IO27 reroute:
//   ROW_IDLE_MODE HIGH -> ROW_IDLE_BUS = VCM_DIST    (direct/simple mode)
//   ROW_IDLE_MODE LOW  -> ROW_IDLE_BUS = VHALF_DIST  (V/2 mode)
// Verify this at TP6 during bring-up.
// -----------------------------------------------------------------------------

// I2C bus for the four MCP23017 GPIO expanders
static constexpr int PIN_I2C_SDA = 21;        // DFR0478 SDA / IO21, schematic net SDA
static constexpr int PIN_I2C_SCL = 22;        // DFR0478 SCL / IO22, schematic net SCL
static constexpr uint32_t I2C_HZ = 400000;    // 400 kHz fast mode

// Shared SPI bus for DAC80502 and ADS131M08
static constexpr int PIN_SPI_SCLK = 18;       // DFR0478 SCK / IO18, schematic net SPI_SCLK
static constexpr int PIN_SPI_MISO = 19;       // DFR0478 MISO / IO19, schematic net SPI_MISO
static constexpr int PIN_SPI_MOSI = 23;       // DFR0478 MOSI / IO23, schematic net SPI_MOSI

// Chip-selects from the schematic
static constexpr int PIN_DAC_CS_N = 15;       // DFR0478 A4 / IO15 -> DAC_CS_N
static constexpr int PIN_ADC_CS_N = 4;       // DFR0478 LRCK / IO4 -> ADC_CS_N

// ADS131M08 control pins from the schematic
static constexpr int PIN_ADC_DRDY_N = 16;         // DFR0478 DI / IO16 -> ADC_DRDY
static constexpr int PIN_ADC_SYNC_RESET_N = 17;    // DFR0478 DO / IO17 -> ADC_SYNC_RESET_N

// Operation-mode control for IC2 ADG734
static constexpr int PIN_ROW_IDLE_MODE = 27;      // DFR0478 D4 / IO27 -> ROW_IDLE_MODE

// Optional status LED. Disable with -1 if GPIO2 is unavailable on your assembly.
static constexpr int PIN_STATUS_LED = 2;

// SPI clock rates. Start conservatively; increase after validating signal integrity.
static constexpr uint32_t DAC_SPI_HZ = 1000000;
static constexpr uint32_t ADC_SPI_HZ = 2000000;
