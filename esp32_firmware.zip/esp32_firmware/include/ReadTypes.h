#pragma once

#include <Arduino.h>

static constexpr uint8_t NUM_ROWS = 8;
static constexpr uint8_t NUM_COLS = 8;
static constexpr uint8_t NUM_RF_RANGES = 5;

struct BiasConfig {
    float vcm = 1.650f;
    float vsel = 1.750f;
    float vhalf = 1.700f;

    float vread() const {
        return vsel - vcm;
    }
};

struct RfRangeInfo {
    const char* name;
    float ohms;
};

enum class RfRange : uint8_t {
    RF_100 = 0,
    RF_1K = 1,
    RF_10K = 2,
    RF_100K = 3,
    RF_1M = 4
};

static constexpr RfRangeInfo RF_RANGES[NUM_RF_RANGES] = {
    {"100", 100.0f},
    {"1k", 1.0e3f},
    {"10k", 10.0e3f},
    {"100k", 100.0e3f},
    {"1M", 1.0e6f},
};

enum class ReadMode : uint8_t {
    Direct = 0,
    VHalf = 1,
    Zero = 2,
    Float = 3
};

enum class RowDriveLevel : uint8_t {
    Vcm = 0,
    Vsel = 1,
    Hiz = 2
};

enum class ColumnState : uint8_t {
    Readout = 0,
    VHalfPark = 1,
    Hiz = 2
};

enum class AutoRangeStatus : uint8_t {
    OK = 0,
    LOW_SIGNAL = 1,
    HIGH_SIGNAL = 2,
    SATURATED = 3,
    MIN_RF_LIMIT = 4,
    MAX_RF_LIMIT = 5,
    ADC_TIMEOUT = 6,
    INVALID_ARGUMENT = 7,
    ERROR = 8
};

struct AdcFrame {
    uint32_t status = 0;
    int32_t raw[NUM_COLS] = {0};
    float volts[NUM_COLS] = {0};
};

struct CellReading {
    uint8_t row = 0;
    uint8_t col = 0;
    ReadMode mode = ReadMode::Direct;
    uint8_t rfIndex = 2;
    float rfOhms = 10.0e3f;
    float adcDiffVolts = 0.0f;
    float currentAmps = 0.0f;
    float resistanceOhms = NAN;
    AutoRangeStatus status = AutoRangeStatus::OK;
    uint8_t autorangeAttempts = 0;
};

struct NoiseReading {
    uint32_t sampleIndex = 0;
    uint8_t channel = 0;
    int32_t adcRaw = 0;
    float adcVolts = 0.0f;
    float currentAmps = 0.0f;
    float rfOhms = 10.0e3f;
    uint32_t timestampUs = 0;
};

static inline float rfOhmsFromIndex(uint8_t idx) {
    return idx < NUM_RF_RANGES ? RF_RANGES[idx].ohms : NAN;
}

static inline const char* rfNameFromIndex(uint8_t idx) {
    return idx < NUM_RF_RANGES ? RF_RANGES[idx].name : "INVALID";
}

static inline const char* readModeName(ReadMode mode) {
    switch (mode) {
        case ReadMode::Direct: return "DIRECT";
        case ReadMode::VHalf: return "VHALF";
        case ReadMode::Zero: return "ZERO";
        case ReadMode::Float: return "FLOAT";
        default: return "UNKNOWN";
    }
}

static inline const char* autoRangeStatusName(AutoRangeStatus status) {
    switch (status) {
        case AutoRangeStatus::OK: return "OK";
        case AutoRangeStatus::LOW_SIGNAL: return "LOW_SIGNAL";
        case AutoRangeStatus::HIGH_SIGNAL: return "HIGH_SIGNAL";
        case AutoRangeStatus::SATURATED: return "SATURATED";
        case AutoRangeStatus::MIN_RF_LIMIT: return "MIN_RF_LIMIT";
        case AutoRangeStatus::MAX_RF_LIMIT: return "MAX_RF_LIMIT";
        case AutoRangeStatus::ADC_TIMEOUT: return "ADC_TIMEOUT";
        case AutoRangeStatus::INVALID_ARGUMENT: return "INVALID_ARGUMENT";
        case AutoRangeStatus::ERROR: return "ERROR";
        default: return "UNKNOWN";
    }
}
