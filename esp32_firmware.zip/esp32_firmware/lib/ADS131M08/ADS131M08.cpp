#include "ADS131M08.h"

// ADS131M08 command words.
static constexpr uint16_t CMD_NULL    = 0x0000;
static constexpr uint16_t CMD_RESET   = 0x0011;
static constexpr uint16_t CMD_STANDBY = 0x0022;
static constexpr uint16_t CMD_WAKEUP  = 0x0033;
static constexpr uint16_t CMD_LOCK    = 0x0555;
static constexpr uint16_t CMD_UNLOCK  = 0x0655;

static constexpr uint16_t CMD_RREG_BASE = 0xA000; // 101a aaaa annn nnnn
static constexpr uint16_t CMD_WREG_BASE = 0x6000; // 011a aaaa annn nnnn

bool ADS131M08::begin(SPIClass& spi,
                      int csPin,
                      int drdyPin,
                      int syncResetPin,
                      uint32_t spiHz,
                      float refVolts,
                      float pgaGain) {
    _spi = &spi;
    _csPin = csPin;
    _drdyPin = drdyPin;
    _syncResetPin = syncResetPin;
    _spiHz = spiHz;
    _refVolts = refVolts;
    _pgaGain = pgaGain;
    _settings = SPISettings(_spiHz, MSBFIRST, SPI_MODE1);

    pinMode(_csPin, OUTPUT);
    digitalWrite(_csPin, HIGH);

    pinMode(_drdyPin, INPUT_PULLUP);
    pinMode(_syncResetPin, OUTPUT);
    digitalWrite(_syncResetPin, HIGH);

    hardwareReset();
    delay(10);

    // Unlock writes in case the part is locked.
    sendCommand(CMD_UNLOCK);
    delay(2);

    return true;
}

void ADS131M08::hardwareReset() {
    if (_syncResetPin < 0) return;
    digitalWrite(_syncResetPin, LOW);
    delayMicroseconds(10);
    digitalWrite(_syncResetPin, HIGH);
}

bool ADS131M08::waitForDataReady(uint32_t timeoutUs) const {
    const uint32_t t0 = micros();
    while (digitalRead(_drdyPin) != LOW) {
        if ((micros() - t0) > timeoutUs) return false;
        yield();
    }
    return true;
}

uint32_t ADS131M08::transferWord24(uint32_t tx) {
    const uint8_t b2 = static_cast<uint8_t>((tx >> 16) & 0xFF);
    const uint8_t b1 = static_cast<uint8_t>((tx >> 8) & 0xFF);
    const uint8_t b0 = static_cast<uint8_t>(tx & 0xFF);

    const uint8_t r2 = _spi->transfer(b2);
    const uint8_t r1 = _spi->transfer(b1);
    const uint8_t r0 = _spi->transfer(b0);

    return (static_cast<uint32_t>(r2) << 16) |
           (static_cast<uint32_t>(r1) << 8)  |
           static_cast<uint32_t>(r0);
}

uint32_t ADS131M08::sendCommand(uint16_t command) {
    if (_spi == nullptr || _csPin < 0) return 0;

    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);

    // Command is left-aligned into the 24-bit word.
    const uint32_t response = transferWord24(static_cast<uint32_t>(command) << 8);

    // Clock out the remaining frame words so CS framing remains valid.
    for (uint8_t i = 0; i < 8; ++i) {
        transferWord24(0x000000);
    }

    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();
    return response;
}

bool ADS131M08::readFrame(AdcFrame& frame, uint32_t timeoutUs) {
    if (_spi == nullptr || _csPin < 0) return false;
    if (!waitForDataReady(timeoutUs)) return false;

    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);

    frame.status = transferWord24(static_cast<uint32_t>(CMD_NULL) << 8);

    for (uint8_t ch = 0; ch < 8; ++ch) {
        const uint32_t raw24 = transferWord24(0x000000);
        frame.raw[ch] = signExtend24(raw24);
        frame.volts[ch] = rawToVolts(frame.raw[ch]);
    }

    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();
    return true;
}

float ADS131M08::rawToVolts(int32_t raw) const {
    // ADS131M08 output is signed two's complement. With gain = 1, approximate full-scale
    // differential range is +/-VREF. Use this as the board-level conversion constant and
    // refine after calibration.
    const float denom = 8388608.0f; // 2^23
    return (static_cast<float>(raw) / denom) * (_refVolts / _pgaGain);
}

int32_t ADS131M08::signExtend24(uint32_t raw24) {
    raw24 &= 0x00FFFFFFUL;
    if (raw24 & 0x00800000UL) {
        raw24 |= 0xFF000000UL;
    }
    return static_cast<int32_t>(raw24);
}

bool ADS131M08::writeRegister(uint8_t address, uint16_t value) {
    if (_spi == nullptr || _csPin < 0) return false;

    const uint16_t cmd = CMD_WREG_BASE |
                         ((static_cast<uint16_t>(address) & 0x7F) << 7) |
                         0x0000; // one register: count minus one = 0

    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);
    transferWord24(static_cast<uint32_t>(cmd) << 8);
    transferWord24(static_cast<uint32_t>(value) << 8);
    for (uint8_t i = 0; i < 7; ++i) transferWord24(0x000000);
    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();

    return true;
}

uint16_t ADS131M08::readRegister(uint8_t address) {
    if (_spi == nullptr || _csPin < 0) return 0;

    const uint16_t cmd = CMD_RREG_BASE |
                         ((static_cast<uint16_t>(address) & 0x7F) << 7) |
                         0x0000; // one register: count minus one = 0

    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);
    transferWord24(static_cast<uint32_t>(cmd) << 8);
    for (uint8_t i = 0; i < 8; ++i) transferWord24(0x000000);
    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();

    // ADS131M08 commands are pipelined. Send one NULL frame to receive the register data.
    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);
    const uint32_t response = transferWord24(static_cast<uint32_t>(CMD_NULL) << 8);
    for (uint8_t i = 0; i < 8; ++i) transferWord24(0x000000);
    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();

    return static_cast<uint16_t>((response >> 8) & 0xFFFF);
}
