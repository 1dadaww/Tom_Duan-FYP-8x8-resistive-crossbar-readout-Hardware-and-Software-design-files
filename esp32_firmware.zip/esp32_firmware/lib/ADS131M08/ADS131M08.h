#pragma once

#include <Arduino.h>
#include <SPI.h>
#include "ReadTypes.h"

class ADS131M08 {
public:
    bool begin(SPIClass& spi,
               int csPin,
               int drdyPin,
               int syncResetPin,
               uint32_t spiHz,
               float refVolts,
               float pgaGain);

    void hardwareReset();
    bool waitForDataReady(uint32_t timeoutUs) const;

    uint32_t transferWord24(uint32_t tx);
    uint32_t sendCommand(uint16_t command);
    bool readFrame(AdcFrame& frame, uint32_t timeoutUs);

    float rawToVolts(int32_t raw) const;
    static int32_t signExtend24(uint32_t raw24);

    // Basic register helpers. These assume default 24-bit word length and CRC disabled.
    bool writeRegister(uint8_t address, uint16_t value);
    uint16_t readRegister(uint8_t address);

private:
    SPIClass* _spi = nullptr;
    int _csPin = -1;
    int _drdyPin = -1;
    int _syncResetPin = -1;
    uint32_t _spiHz = 2000000;
    float _refVolts = 1.2f;
    float _pgaGain = 1.0f;

    SPISettings _settings = SPISettings(2000000, MSBFIRST, SPI_MODE1);
};
