#pragma once

#include <Arduino.h>
#include <SPI.h>

class DAC80502 {
public:
    enum Channel : uint8_t {
        ChannelA = 0,
        ChannelB = 1
    };

    bool begin(SPIClass& spi, int csPin, uint32_t spiHz, float refVolts, float outputGain);

    bool writeRegister(uint8_t reg, uint16_t value);
    bool setCode(Channel ch, uint16_t code);
    bool setVoltage(Channel ch, float volts);

    float refVolts() const { return _refVolts; }
    float outputGain() const { return _outputGain; }

private:
    SPIClass* _spi = nullptr;
    int _csPin = -1;
    uint32_t _spiHz = 1000000;
    float _refVolts = 2.5f;
    float _outputGain = 1.0f;

    SPISettings _settings = SPISettings(1000000, MSBFIRST, SPI_MODE1);

    uint16_t voltsToCode(float volts) const;
};
