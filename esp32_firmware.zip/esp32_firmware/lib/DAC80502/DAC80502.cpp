#include "DAC80502.h"
#include "ProjectConfig.h"

// DACx0502-family register addresses.
// Verify these against your exact DAC80502 package/configuration before hardware bring-up.
static constexpr uint8_t REG_NOOP    = 0x00;
static constexpr uint8_t REG_DEVID   = 0x01;
static constexpr uint8_t REG_SYNC    = 0x02;
static constexpr uint8_t REG_CONFIG  = 0x03;
static constexpr uint8_t REG_GAIN    = 0x04;
static constexpr uint8_t REG_TRIGGER = 0x05;
static constexpr uint8_t REG_STATUS  = 0x07;
static constexpr uint8_t REG_DAC_A   = 0x08;
static constexpr uint8_t REG_DAC_B   = 0x09;

bool DAC80502::begin(SPIClass& spi, int csPin, uint32_t spiHz, float refVolts, float outputGain) {
    _spi = &spi;
    _csPin = csPin;
    _spiHz = spiHz;
    _refVolts = refVolts;
    _outputGain = outputGain;
    _settings = SPISettings(_spiHz, MSBFIRST, SPI_MODE1);

    pinMode(_csPin, OUTPUT);
    digitalWrite(_csPin, HIGH);

    bool ok = true;

    ok = writeRegister(REG_CONFIG, DAC_CONFIG_REGISTER_VALUE) && ok;
    delay(2);

    ok = writeRegister(REG_GAIN, DAC_GAIN_REGISTER_VALUE) && ok;
    delay(2);

    // Safe startup: write both DAC outputs to 0 V equivalent code after reference/gain setup.
    ok = setCode(ChannelA, 0) && ok;
    ok = setCode(ChannelB, 0) && ok;
    delay(2);
    return ok;
}

bool DAC80502::writeRegister(uint8_t reg, uint16_t value) {
    if (_spi == nullptr || _csPin < 0) return false;

    _spi->beginTransaction(_settings);
    digitalWrite(_csPin, LOW);

    // DACx0502 SPI write frame is 24 bits: command/address byte + 16-bit data.
    _spi->transfer(reg);
    _spi->transfer(static_cast<uint8_t>((value >> 8) & 0xFF));
    _spi->transfer(static_cast<uint8_t>(value & 0xFF));

    digitalWrite(_csPin, HIGH);
    _spi->endTransaction();
    delayMicroseconds(1);
    return true;
}

bool DAC80502::setCode(Channel ch, uint16_t code) {
    const uint8_t reg = (ch == ChannelA) ? REG_DAC_A : REG_DAC_B;
    return writeRegister(reg, code);
}

bool DAC80502::setVoltage(Channel ch, float volts) {
    return setCode(ch, voltsToCode(volts));
}

uint16_t DAC80502::voltsToCode(float volts) const {
    const float fullScale = _refVolts * _outputGain;
    if (fullScale <= 0.0f) return 0;

    float normalized = volts / fullScale;
    if (normalized < 0.0f) normalized = 0.0f;
    if (normalized > 1.0f) normalized = 1.0f;

    return static_cast<uint16_t>(lroundf(normalized * 65535.0f));
}
