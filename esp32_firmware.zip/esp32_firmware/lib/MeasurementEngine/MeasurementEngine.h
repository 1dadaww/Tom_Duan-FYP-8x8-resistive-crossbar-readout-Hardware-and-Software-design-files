#pragma once

#include <Arduino.h>
#include "ReadTypes.h"
#include "ProjectConfig.h"
#include "DAC80502.h"
#include "ADS131M08.h"
#include "SwitchMatrix.h"

class MeasurementEngine {
public:
    bool begin(DAC80502& dac, ADS131M08& adc, SwitchMatrix& matrix);

    bool setBias(float vcm, float vsel);
    BiasConfig bias() const { return _bias; }

    // Manual RF control.
    bool setRfIndex(uint8_t rfIndex);
    bool setRfIndexForChannel(uint8_t channel, uint8_t rfIndex);
    uint8_t rfIndex() const { return _rfIndex; }
    uint8_t rfIndexForChannel(uint8_t channel) const;
    float rfOhms() const { return RF_RANGES[_rfIndex].ohms; }
    float rfOhmsForChannel(uint8_t channel) const;

    bool readAdcFrame(AdcFrame& frame);
    bool readAdcAverage(AdcFrame& frame, uint16_t samples);
    bool setPacketAverageSamples(uint16_t samples);
    uint16_t packetAverageSamples() const { return _packetAverageSamples; }

    bool measureCellDirect(uint8_t row, uint8_t col, CellReading& out);
    bool measureCellVHalf(uint8_t row, uint8_t col, CellReading& out);
    bool measureCellFloat(uint8_t row, uint8_t col, CellReading& out);

    bool measureCellDirectAuto(uint8_t row, uint8_t col, CellReading& out);
    bool measureCellVHalfAuto(uint8_t row, uint8_t col, CellReading& out);
    bool measureCellFloatAuto(uint8_t row, uint8_t col, CellReading& out);

    bool measureRowDirect(uint8_t row, CellReading out[NUM_COLS]);
    bool measureRowDirectAuto(uint8_t row, CellReading out[NUM_COLS]);

    bool scanDirect(CellReading out[NUM_ROWS][NUM_COLS]);
    bool scanVHalf(CellReading out[NUM_ROWS][NUM_COLS]);
    bool scanFloat(CellReading out[NUM_ROWS][NUM_COLS]);
    bool scanDirectAuto(CellReading out[NUM_ROWS][NUM_COLS]);
    bool scanVHalfAuto(CellReading out[NUM_ROWS][NUM_COLS]);
    bool scanFloatAuto(CellReading out[NUM_ROWS][NUM_COLS]);

    bool readZeroFrame(AdcFrame& out);

    void setSafeState();
    bool setBiasVoltages(float vsel, float vcm);
    void setSingleRowDrive(uint8_t row, RowDriveLevel level);
    void setRowVector(uint8_t rowBits);
    void setSingleColumnState(uint8_t col, ColumnState state);
    void selectReadoutColumn(uint8_t selectedCol);
    bool measureColumnCurrent(uint8_t col, float& current);
    bool runBinaryVMM(uint8_t rowBits, float currents[NUM_COLS]);

    bool configureNoiseReadout(uint8_t row, uint8_t col, ReadMode mode, uint8_t rfIndex);
    bool readNoiseSample(uint32_t sampleIndex, NoiseReading& out);
    bool noiseConfigured() const { return _noiseConfigured; }

    static float resistanceFromVadc(float vread, float rfOhms, float vadcDiff);
    static float currentFromVadc(float rfOhms, float vadcDiff);

private:
    DAC80502* _dac = nullptr;
    ADS131M08* _adc = nullptr;
    SwitchMatrix* _matrix = nullptr;
    BiasConfig _bias;
    uint8_t _rfIndex = 2; // default 10k
    bool _noiseConfigured = false;
    uint8_t _noiseRow = 0;
    uint8_t _noiseCol = 0;
    ReadMode _noiseMode = ReadMode::Direct;
    uint16_t _packetAverageSamples = DEFAULT_ADC_AVG;

    bool configureReadState(ReadMode mode, uint8_t row, uint8_t col);
    bool measureConfiguredCell(ReadMode mode, uint8_t row, uint8_t col, uint8_t channel, CellReading& out, uint16_t avgSamples);
    bool autorangeCell(ReadMode mode, uint8_t row, uint8_t col, CellReading& out);
    bool increaseRf(uint8_t& rfIndex) const;
    bool decreaseRf(uint8_t& rfIndex) const;
};
