#include "MeasurementEngine.h"

bool MeasurementEngine::begin(DAC80502& dac, ADS131M08& adc, SwitchMatrix& matrix) {
    _dac = &dac;
    _adc = &adc;
    _matrix = &matrix;

    setBias(_bias.vcm, _bias.vsel);
    setRfIndex(_rfIndex);
    return true;
}

bool MeasurementEngine::setBias(float vcm, float vsel) {
    if (_dac == nullptr) return false;

    _bias.vcm = vcm;
    _bias.vsel = vsel;
    _bias.vhalf = 0.5f * (vcm + vsel);

    // Schematic convention assumed here:
    // DAC channel A -> VCM
    // DAC channel B -> VSEL
    // VHALF is made by analog resistor average and buffer, not by a DAC channel.
    const bool okA = _dac->setVoltage(DAC80502::ChannelA, _bias.vcm);
    const bool okB = _dac->setVoltage(DAC80502::ChannelB, _bias.vsel);
    delayMicroseconds(ANALOG_SETTLE_US);
    return okA && okB;
}

bool MeasurementEngine::setBiasVoltages(float vsel, float vcm) {
    // Public arguments use VSEL, VCM order; the board routes DAC A to VCM and
    // DAC B to VSEL.
    return setBias(vcm, vsel);
}

bool MeasurementEngine::setRfIndex(uint8_t rfIndex) {
    if (rfIndex >= NUM_RF_RANGES) return false;
    _rfIndex = rfIndex;
    if (_matrix != nullptr) {
        return _matrix->setRfRangeAllChannels(_rfIndex);
    }
    return true;
}

bool MeasurementEngine::setRfIndexForChannel(uint8_t channel, uint8_t rfIndex) {
    if (channel >= NUM_COLS || rfIndex >= NUM_RF_RANGES || _matrix == nullptr) return false;
    return _matrix->setRfRangeForChannel(channel, rfIndex);
}

uint8_t MeasurementEngine::rfIndexForChannel(uint8_t channel) const {
    if (_matrix == nullptr || channel >= NUM_COLS) return 0xFF;
    return _matrix->getRfIndexForChannel(channel);
}

float MeasurementEngine::rfOhmsForChannel(uint8_t channel) const {
    if (_matrix == nullptr || channel >= NUM_COLS) return NAN;
    return _matrix->getRfOhmsForChannel(channel);
}

bool MeasurementEngine::readAdcFrame(AdcFrame& frame) {
    if (_adc == nullptr) return false;
    return _adc->readFrame(frame, ADC_DRDY_TIMEOUT_US);
}

bool MeasurementEngine::readAdcAverage(AdcFrame& frame, uint16_t samples) {
    if (_adc == nullptr) return false;
    if (samples == 0) samples = 1;

    double acc[NUM_COLS] = {0};
    double rawAcc[NUM_COLS] = {0};
    AdcFrame temp;
    for (uint16_t n = 0; n < samples; ++n) {
        if (!readAdcFrame(temp)) return false;
        frame.status = temp.status;
        for (uint8_t c = 0; c < NUM_COLS; ++c) {
            acc[c] += temp.volts[c];
            rawAcc[c] += temp.raw[c];
        }
    }

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        frame.volts[c] = static_cast<float>(acc[c] / samples);
        frame.raw[c] = static_cast<int32_t>(rawAcc[c] / samples);
    }
    return true;
}

bool MeasurementEngine::setPacketAverageSamples(uint16_t samples) {
    if (samples < 1 || samples > MAX_PACKET_ADC_AVG) return false;
    _packetAverageSamples = samples;
    return true;
}

bool MeasurementEngine::configureReadState(ReadMode mode, uint8_t row, uint8_t col) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS) return false;

    if (mode == ReadMode::Direct) {
        _matrix->selectRow(row, ReadMode::Direct);
        _matrix->connectAllColumnsToTia();
        return true;
    }

    if (mode == ReadMode::VHalf) {
        _matrix->selectRow(row, ReadMode::VHalf);
        _matrix->selectSingleColumnVHalf(col);
        return true;
    }

    if (mode == ReadMode::Float) {
        _matrix->selectRowFloat(row);
        _matrix->selectSingleColumnFloat(col);
        return true;
    }

    return false;
}

bool MeasurementEngine::measureConfiguredCell(ReadMode mode, uint8_t row, uint8_t col, uint8_t channel, CellReading& out, uint16_t avgSamples) {
    if (channel >= NUM_COLS) return false;

    AdcFrame frame;
    if (!readAdcAverage(frame, avgSamples)) {
        out.status = AutoRangeStatus::ADC_TIMEOUT;
        return false;
    }

    const uint8_t rfIdx = rfIndexForChannel(channel);
    const float rfOhm = rfOhmsForChannel(channel);

    out.row = row;
    out.col = col;
    out.mode = mode;
    out.rfIndex = rfIdx;
    out.rfOhms = rfOhm;
    out.adcDiffVolts = frame.volts[channel];
    out.currentAmps = currentFromVadc(out.rfOhms, out.adcDiffVolts);
    out.resistanceOhms = resistanceFromVadc(_bias.vread(), out.rfOhms, out.adcDiffVolts);
    return true;
}

bool MeasurementEngine::measureCellDirect(uint8_t row, uint8_t col, CellReading& out) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS) return false;
    if (!configureReadState(ReadMode::Direct, row, col)) return false;
    delayMicroseconds(ANALOG_SETTLE_US);
    return measureConfiguredCell(ReadMode::Direct, row, col, col, out, _packetAverageSamples);
}

bool MeasurementEngine::measureCellVHalf(uint8_t row, uint8_t col, CellReading& out) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS) return false;
    if (!configureReadState(ReadMode::VHalf, row, col)) return false;
    delayMicroseconds(ANALOG_SETTLE_US);
    return measureConfiguredCell(ReadMode::VHalf, row, col, col, out, _packetAverageSamples);
}

bool MeasurementEngine::measureCellFloat(uint8_t row, uint8_t col, CellReading& out) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS) return false;
    if (!configureReadState(ReadMode::Float, row, col)) return false;
    delayMicroseconds(ANALOG_SETTLE_US);
    return measureConfiguredCell(ReadMode::Float, row, col, col, out, _packetAverageSamples);
}

bool MeasurementEngine::autorangeCell(ReadMode mode, uint8_t row, uint8_t col, CellReading& out) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS) {
        out.status = AutoRangeStatus::INVALID_ARGUMENT;
        return false;
    }

    const uint8_t channel = col;
    uint8_t rfIdx = rfIndexForChannel(channel);
    if (rfIdx >= NUM_RF_RANGES) rfIdx = 0;

    // For first-time unknowns, starting with low gain is safest.
    if (!isfinite(rfOhmsFromIndex(rfIdx))) rfIdx = 0;

    AutoRangeStatus lastStatus = AutoRangeStatus::ERROR;
    CellReading trial;

    for (uint8_t attempt = 0; attempt < AUTORANGE_MAX_STEPS; ++attempt) {
        // Park selected row before changing RF to avoid switching the feedback
        // path while large array current is flowing.
        if (mode == ReadMode::Float) {
            _matrix->floatAllRows();
            _matrix->parkAllColumnsFloat();
        } else {
            _matrix->parkAllRowsAtIdle();
        }
        _matrix->setRfRangeForChannel(channel, rfIdx);
        delayMicroseconds(AUTORANGE_SETTLE_US);

        if (!configureReadState(mode, row, col)) {
            out.status = AutoRangeStatus::INVALID_ARGUMENT;
            return false;
        }
        delayMicroseconds(AUTORANGE_SETTLE_US);

        const uint16_t avgSamples = max(AUTORANGE_ADC_AVG, _packetAverageSamples);
        if (!measureConfiguredCell(mode, row, col, channel, trial, avgSamples)) {
            out = trial;
            out.autorangeAttempts = attempt + 1;
            return false;
        }

        trial.autorangeAttempts = attempt + 1;
        const float amp = fabsf(trial.adcDiffVolts);

        if (!isfinite(amp)) {
            lastStatus = AutoRangeStatus::ERROR;
            break;
        }

        if (amp >= AUTORANGE_VADC_SAT || amp > AUTORANGE_VADC_HIGH) {
            if (!decreaseRf(rfIdx)) {
                trial.status = (amp >= AUTORANGE_VADC_SAT) ? AutoRangeStatus::SATURATED : AutoRangeStatus::MIN_RF_LIMIT;
                out = trial;
                return true;
            }
            lastStatus = (amp >= AUTORANGE_VADC_SAT) ? AutoRangeStatus::SATURATED : AutoRangeStatus::HIGH_SIGNAL;
            continue;
        }

        if (amp < AUTORANGE_VADC_LOW) {
            if (!increaseRf(rfIdx)) {
                trial.status = AutoRangeStatus::MAX_RF_LIMIT;
                out = trial;
                return true;
            }
            lastStatus = AutoRangeStatus::LOW_SIGNAL;
            continue;
        }

        trial.status = AutoRangeStatus::OK;
        out = trial;
        return true;
    }

    trial.status = lastStatus;
    out = trial;
    return true;
}

bool MeasurementEngine::increaseRf(uint8_t& rfIndex) const {
    if (rfIndex >= NUM_RF_RANGES - 1) return false;
    rfIndex++;
    return true;
}

bool MeasurementEngine::decreaseRf(uint8_t& rfIndex) const {
    if (rfIndex == 0 || rfIndex >= NUM_RF_RANGES) return false;
    rfIndex--;
    return true;
}

bool MeasurementEngine::measureCellDirectAuto(uint8_t row, uint8_t col, CellReading& out) {
    return autorangeCell(ReadMode::Direct, row, col, out);
}

bool MeasurementEngine::measureCellVHalfAuto(uint8_t row, uint8_t col, CellReading& out) {
    return autorangeCell(ReadMode::VHalf, row, col, out);
}

bool MeasurementEngine::measureCellFloatAuto(uint8_t row, uint8_t col, CellReading& out) {
    return autorangeCell(ReadMode::Float, row, col, out);
}

bool MeasurementEngine::measureRowDirect(uint8_t row, CellReading out[NUM_COLS]) {
    if (_matrix == nullptr || row >= NUM_ROWS) return false;

    _matrix->selectRow(row, ReadMode::Direct);
    _matrix->connectAllColumnsToTia();
    delayMicroseconds(ANALOG_SETTLE_US);

    AdcFrame frame;
    if (!readAdcAverage(frame, _packetAverageSamples)) return false;

    for (uint8_t col = 0; col < NUM_COLS; ++col) {
        const float rfOhm = rfOhmsForChannel(col);
        out[col].row = row;
        out[col].col = col;
        out[col].mode = ReadMode::Direct;
        out[col].rfIndex = rfIndexForChannel(col);
        out[col].rfOhms = rfOhm;
        out[col].adcDiffVolts = frame.volts[col];
        out[col].currentAmps = currentFromVadc(rfOhm, out[col].adcDiffVolts);
        out[col].resistanceOhms = resistanceFromVadc(_bias.vread(), rfOhm, out[col].adcDiffVolts);
        out[col].status = AutoRangeStatus::OK;
    }

    return true;
}

bool MeasurementEngine::measureRowDirectAuto(uint8_t row, CellReading out[NUM_COLS]) {
    if (row >= NUM_ROWS) return false;
    for (uint8_t col = 0; col < NUM_COLS; ++col) {
        if (!measureCellDirectAuto(row, col, out[col])) return false;
    }
    return true;
}

bool MeasurementEngine::scanDirect(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        if (!measureRowDirect(row, out[row])) return false;
    }
    return true;
}

bool MeasurementEngine::scanVHalf(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        for (uint8_t col = 0; col < NUM_COLS; ++col) {
            if (!measureCellVHalf(row, col, out[row][col])) return false;
        }
    }
    return true;
}

bool MeasurementEngine::scanFloat(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        for (uint8_t col = 0; col < NUM_COLS; ++col) {
            if (!measureCellFloat(row, col, out[row][col])) return false;
        }
    }
    return true;
}

bool MeasurementEngine::scanDirectAuto(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        if (!measureRowDirectAuto(row, out[row])) return false;
    }
    return true;
}

bool MeasurementEngine::scanVHalfAuto(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        for (uint8_t col = 0; col < NUM_COLS; ++col) {
            if (!measureCellVHalfAuto(row, col, out[row][col])) return false;
        }
    }
    return true;
}

bool MeasurementEngine::scanFloatAuto(CellReading out[NUM_ROWS][NUM_COLS]) {
    for (uint8_t row = 0; row < NUM_ROWS; ++row) {
        for (uint8_t col = 0; col < NUM_COLS; ++col) {
            if (!measureCellFloatAuto(row, col, out[row][col])) return false;
        }
    }
    return true;
}

bool MeasurementEngine::readZeroFrame(AdcFrame& out) {
    if (_matrix == nullptr) return false;

    _matrix->zeroRowsToVcm();
    _matrix->connectAllColumnsToTia();
    delayMicroseconds(ANALOG_SETTLE_US);

    return readAdcAverage(out, _packetAverageSamples);
}

void MeasurementEngine::setSafeState() {
    if (_matrix == nullptr) return;
    _matrix->zeroRowsToVcm();
    _matrix->parkAllColumnsVHalf();
}

void MeasurementEngine::setSingleRowDrive(uint8_t row, RowDriveLevel level) {
    if (_matrix == nullptr) return;
    _matrix->setSingleRowDrive(row, level);
}

void MeasurementEngine::setRowVector(uint8_t rowBits) {
    if (_matrix == nullptr) return;
    _matrix->setRowVector(rowBits);
}

void MeasurementEngine::setSingleColumnState(uint8_t col, ColumnState state) {
    if (_matrix == nullptr) return;
    _matrix->setSingleColumnState(col, state);
}

void MeasurementEngine::selectReadoutColumn(uint8_t selectedCol) {
    if (_matrix == nullptr) return;
    _matrix->selectReadoutColumn(selectedCol);
}

bool MeasurementEngine::measureColumnCurrent(uint8_t col, float& current) {
    if (col >= NUM_COLS) return false;

    AdcFrame frame;
    if (!readAdcAverage(frame, _packetAverageSamples)) return false;

    current = currentFromVadc(rfOhmsForChannel(col), frame.volts[col]);
    return true;
}

bool MeasurementEngine::runBinaryVMM(uint8_t rowBits, float currents[NUM_COLS]) {
    if (_matrix == nullptr || currents == nullptr) return false;

    // Start from a known low-stress state before applying a full row vector.
    _matrix->zeroRowsToVcm();
    _matrix->parkAllColumnsVHalf();
    delayMicroseconds(VMM_ROW_SETTLE_US);

    setBias(_bias.vcm, _bias.vsel);
    delayMicroseconds(VMM_DAC_SETTLE_US);

    _matrix->connectAllColumnsToTia();
    delayMicroseconds(VMM_COLUMN_SETTLE_US);

    setRowVector(rowBits);
    delayMicroseconds(VMM_ROW_SETTLE_US);

    for (uint8_t col = 0; col < NUM_COLS; ++col) {
        selectReadoutColumn(col);
        delayMicroseconds(VMM_COLUMN_SETTLE_US);
        if (!measureColumnCurrent(col, currents[col])) {
            setSafeState();
            return false;
        }
    }

    setSafeState();
    return true;
}

bool MeasurementEngine::configureNoiseReadout(uint8_t row, uint8_t col, ReadMode mode, uint8_t rfIndex) {
    if (_matrix == nullptr || row >= NUM_ROWS || col >= NUM_COLS || rfIndex >= NUM_RF_RANGES) return false;
    if (mode != ReadMode::Direct && mode != ReadMode::VHalf) return false;

    if (!_matrix->setRfRangeForChannel(col, rfIndex)) return false;
    delayMicroseconds(ANALOG_SETTLE_US);

    if (!configureReadState(mode, row, col)) return false;
    delayMicroseconds(ANALOG_SETTLE_US);

    _noiseConfigured = true;
    _noiseRow = row;
    _noiseCol = col;
    _noiseMode = mode;
    return true;
}

bool MeasurementEngine::readNoiseSample(uint32_t sampleIndex, NoiseReading& out) {
    if (!_noiseConfigured || _noiseCol >= NUM_COLS) return false;

    AdcFrame frame;
    if (!readAdcAverage(frame, _packetAverageSamples)) return false;

    const uint8_t channel = _noiseCol;
    const float rfOhm = rfOhmsForChannel(channel);

    out.sampleIndex = sampleIndex;
    out.channel = channel;
    out.adcRaw = frame.raw[channel];
    out.adcVolts = frame.volts[channel];
    out.currentAmps = currentFromVadc(rfOhm, out.adcVolts);
    out.rfOhms = rfOhm;
    out.timestampUs = micros();
    return true;
}

float MeasurementEngine::resistanceFromVadc(float vread, float rfOhms, float vadcDiff) {
    if (!isfinite(vadcDiff) || fabsf(vadcDiff) < MIN_VALID_ADC_DIFF_VOLTS) {
        return NAN;
    }
    return (vread * rfOhms) / vadcDiff;
}

float MeasurementEngine::currentFromVadc(float rfOhms, float vadcDiff) {
    if (rfOhms <= 0.0f) return NAN;
    return vadcDiff / rfOhms;
}
