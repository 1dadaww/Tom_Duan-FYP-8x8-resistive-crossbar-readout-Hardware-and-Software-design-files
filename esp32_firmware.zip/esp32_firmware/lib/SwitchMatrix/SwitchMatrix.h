#pragma once

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_MCP23X17.h>
#include "ReadTypes.h"
#include "SwitchMap.h"

class SwitchMatrix {
public:
    bool begin(TwoWire& wire);

    void allOff();
    void setMode(ReadMode mode);

    void parkAllRowsAtIdle();
    void floatAllRows();
    void selectRow(uint8_t row, ReadMode mode);
    void selectRowFloat(uint8_t row);
    void zeroRowsToVcm();
    void setSingleRowDrive(uint8_t row, RowDriveLevel level);
    void setRowVector(uint8_t rowBits);

    void connectAllColumnsToTia();
    void selectSingleColumnVHalf(uint8_t selectedCol);
    void selectSingleColumnFloat(uint8_t selectedCol);
    void parkAllColumnsVHalf();
    void parkAllColumnsFloat();
    void setSingleColumnState(uint8_t col, ColumnState state);
    void selectReadoutColumn(uint8_t selectedCol);

    // Manual/global and per-channel RF control.
    bool setRfRangeAllChannels(uint8_t rfIndex);
    bool setRfRangeForChannel(uint8_t channel, uint8_t rfIndex);
    bool disableRfChannel(uint8_t channel);
    bool disableAllRf();
    uint8_t getRfIndexForChannel(uint8_t channel) const;
    float getRfOhmsForChannel(uint8_t channel) const;

    bool valid() const { return _valid; }
    bool expanderPresent(uint8_t idx) const { return idx < NUM_EXPANDERS && _present[idx]; }

private:
    static constexpr uint8_t NUM_EXPANDERS = 4;
    static constexpr uint8_t MCP_ADDR[NUM_EXPANDERS] = {0x20, 0x21, 0x22, 0x23};

    Adafruit_MCP23X17 _mcp[NUM_EXPANDERS];
    bool _present[NUM_EXPANDERS] = {false, false, false, false};
    bool _valid = false;
    uint8_t _channelRfIndex[NUM_COLS] = {2,2,2,2,2,2,2,2};

    bool isLineUsed(const SwitchLine& line) const;
    void configureLine(const SwitchLine& line);
    void writeLine(const SwitchLine& line, bool enabled);
    void writeLineRaw(const SwitchLine& line, bool levelHigh);
    void writeColumnModeTia(uint8_t col);
    void writeColumnModeVHalf(uint8_t col);
    void writeColumnModeHiz(uint8_t col);
};
