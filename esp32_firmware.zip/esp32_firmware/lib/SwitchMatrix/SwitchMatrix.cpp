#include "SwitchMatrix.h"
#include "BoardPins.h"
#include "ProjectConfig.h"

constexpr uint8_t SwitchMatrix::MCP_ADDR[NUM_EXPANDERS];

bool SwitchMatrix::begin(TwoWire& wire) {
    _valid = true;

    for (uint8_t i = 0; i < NUM_EXPANDERS; ++i) {
        _present[i] = _mcp[i].begin_I2C(MCP_ADDR[i], &wire);
        if (!_present[i]) {
            Serial.print(F("WARNING: MCP23017 not found at 0x"));
            Serial.println(MCP_ADDR[i], HEX);
            _valid = false;
        }
    }

    // IC2 operation-mode control. Safe default: direct mode.
    pinMode(PIN_ROW_IDLE_MODE, OUTPUT);
    digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_DIRECT_LEVEL);

    // Configure all known switch lines as outputs, default OFF/disconnected.
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        configureLine(ROW_IDLE_EN[r]);
        configureLine(ROW_SEL_EN[r]);
    }

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        configureLine(COL_MODE[c]);
    }

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        for (uint8_t k = 0; k < NUM_RF_RANGES; ++k) {
            configureLine(RF_EN[c][k]);
        }
    }

    allOff();
    setMode(ReadMode::Direct);
    return _valid;
}

void SwitchMatrix::allOff() {
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
        writeLine(ROW_IDLE_EN[r], false);
    }

    // Default columns to VHALF parking for safety while idle.
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        writeColumnModeVHalf(c);
    }

    disableAllRf();
}

void SwitchMatrix::setMode(ReadMode mode) {
    // IC2 ADG734 operation-mode switch:
    //   IN1 = ROW_IDLE_MODE
    //   S1A = VCM_DIST
    //   D1  = ROW_IDLE_BUS
    //   S1B = VHALF_DIST
    // Firmware convention for this PCB revision:
    //   Direct -> GPIO27 HIGH -> ROW_IDLE_BUS = VCM_DIST
    //   V/2    -> GPIO27 LOW  -> ROW_IDLE_BUS = VHALF_DIST
    if (mode == ReadMode::VHalf) {
        digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_VHALF_LEVEL);
    } else {
        digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_DIRECT_LEVEL);
    }
    delayMicroseconds(5);
}

void SwitchMatrix::parkAllRowsAtIdle() {
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
        writeLine(ROW_IDLE_EN[r], true);
    }
}

void SwitchMatrix::floatAllRows() {
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
        writeLine(ROW_IDLE_EN[r], false);
    }
}

void SwitchMatrix::selectRow(uint8_t row, ReadMode mode) {
    if (row >= NUM_ROWS) return;

    setMode(mode);

    // Break-before-make: turn off selected-row overrides first.
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
    }
    delayMicroseconds(5);

    // Unselected rows connect to idle bus. Selected row disconnects from idle bus and goes to VSEL.
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        if (r == row) {
            writeLine(ROW_IDLE_EN[r], false);
            delayMicroseconds(2);
            writeLine(ROW_SEL_EN[r], true);
        } else {
            writeLine(ROW_SEL_EN[r], false);
            writeLine(ROW_IDLE_EN[r], true);
        }
    }
}

void SwitchMatrix::selectRowFloat(uint8_t row) {
    if (row >= NUM_ROWS) return;

    // ROW_IDLE_EN false puts the row idle ADG on its NC/high-Z throw.
    // ROW_SEL_EN true connects only the selected row to VSEL through TMUX1112.
    setMode(ReadMode::Direct);

    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
    }
    delayMicroseconds(5);

    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_IDLE_EN[r], false);
        if (r == row) {
            delayMicroseconds(2);
            writeLine(ROW_SEL_EN[r], true);
        }
    }
}

void SwitchMatrix::zeroRowsToVcm() {
    setMode(ReadMode::Direct);
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
        writeLine(ROW_IDLE_EN[r], true);
    }
}

void SwitchMatrix::setSingleRowDrive(uint8_t row, RowDriveLevel level) {
    if (row >= NUM_ROWS) return;

    // Direct mode makes ROW_IDLE_BUS = VCM_DIST on this PCB.
    setMode(ReadMode::Direct);

    if (level == RowDriveLevel::Vsel) {
        writeLine(ROW_IDLE_EN[row], false);
        delayMicroseconds(2);
        writeLine(ROW_SEL_EN[row], true);
        return;
    }

    if (level == RowDriveLevel::Vcm) {
        writeLine(ROW_SEL_EN[row], false);
        delayMicroseconds(2);
        writeLine(ROW_IDLE_EN[row], true);
        return;
    }

    writeLine(ROW_SEL_EN[row], false);
    writeLine(ROW_IDLE_EN[row], false);
}

void SwitchMatrix::setRowVector(uint8_t rowBits) {
    setMode(ReadMode::Direct);

    // Break before make: first disconnect all selected-row/VSEL switches.
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        writeLine(ROW_SEL_EN[r], false);
    }
    delayMicroseconds(5);

    // Bit mapping: bit 0 -> row 0, ..., bit 7 -> row 7.
    // Clear bits are actively tied to VCM through ROW_IDLE_BUS, not floated.
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        const bool active = (rowBits & (1u << r)) != 0;
        if (active) {
            writeLine(ROW_IDLE_EN[r], false);
            delayMicroseconds(2);
            writeLine(ROW_SEL_EN[r], true);
        } else {
            writeLine(ROW_IDLE_EN[r], true);
        }
    }
}

void SwitchMatrix::connectAllColumnsToTia() {
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        writeColumnModeTia(c);
    }
    delayMicroseconds(5);
}

void SwitchMatrix::selectSingleColumnVHalf(uint8_t selectedCol) {
    if (selectedCol >= NUM_COLS) return;

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        if (c == selectedCol) {
            writeColumnModeTia(c);
        } else {
            writeColumnModeVHalf(c);
        }
    }
    delayMicroseconds(5);
}

void SwitchMatrix::selectSingleColumnFloat(uint8_t selectedCol) {
    if (selectedCol >= NUM_COLS) return;

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        if (c == selectedCol) {
            writeColumnModeTia(c);
        } else {
            writeColumnModeHiz(c);
        }
    }
    delayMicroseconds(5);
}

void SwitchMatrix::parkAllColumnsVHalf() {
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        writeColumnModeVHalf(c);
    }
    delayMicroseconds(5);
}

void SwitchMatrix::parkAllColumnsFloat() {
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        writeColumnModeHiz(c);
    }
    delayMicroseconds(5);
}

void SwitchMatrix::setSingleColumnState(uint8_t col, ColumnState state) {
    if (col >= NUM_COLS) return;

    if (state == ColumnState::Readout) {
        writeColumnModeTia(col);
        return;
    }

    if (state == ColumnState::VHalfPark) {
        writeColumnModeVHalf(col);
        return;
    }

    writeColumnModeHiz(col);
}

void SwitchMatrix::selectReadoutColumn(uint8_t selectedCol) {
    if (selectedCol >= NUM_COLS) return;

    // This board has one TIA/ADC readout per column, so VMM leaves all columns
    // connected to readout and samples the requested ADC channel. No MCP init
    // state or address handling is changed by this command path.
    connectAllColumnsToTia();
}

bool SwitchMatrix::setRfRangeAllChannels(uint8_t rfIndex) {
    if (rfIndex >= NUM_RF_RANGES) return false;
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        if (!setRfRangeForChannel(c, rfIndex)) return false;
    }
    return true;
}

bool SwitchMatrix::setRfRangeForChannel(uint8_t channel, uint8_t rfIndex) {
    if (channel >= NUM_COLS || rfIndex >= NUM_RF_RANGES) return false;

    // Guarantee only one feedback branch per channel.
    disableRfChannel(channel);
    delayMicroseconds(5);
    writeLine(RF_EN[channel][rfIndex], true);
    _channelRfIndex[channel] = rfIndex;
    return true;
}

bool SwitchMatrix::disableRfChannel(uint8_t channel) {
    if (channel >= NUM_COLS) return false;
    for (uint8_t k = 0; k < NUM_RF_RANGES; ++k) {
        writeLine(RF_EN[channel][k], false);
    }
    return true;
}

bool SwitchMatrix::disableAllRf() {
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        disableRfChannel(c);
    }
    return true;
}

uint8_t SwitchMatrix::getRfIndexForChannel(uint8_t channel) const {
    if (channel >= NUM_COLS) return 0xFF;
    return _channelRfIndex[channel];
}

float SwitchMatrix::getRfOhmsForChannel(uint8_t channel) const {
    const uint8_t idx = getRfIndexForChannel(channel);
    return rfOhmsFromIndex(idx);
}

void SwitchMatrix::writeColumnModeTia(uint8_t col) {
    if (col >= NUM_COLS) return;
    writeLineRaw(COL_MODE[col], COL_MODE_TIA_LEVEL_HIGH);
}

void SwitchMatrix::writeColumnModeVHalf(uint8_t col) {
    if (col >= NUM_COLS) return;
    writeLineRaw(COL_MODE[col], !COL_MODE_TIA_LEVEL_HIGH);
}

void SwitchMatrix::writeColumnModeHiz(uint8_t col) {
    if (col >= NUM_COLS) return;
    // In FLOAT mode, the non-TIA throw provides the high-impedance column
    // state. VHALF retains a separate named control path.
    writeLineRaw(COL_MODE[col], !COL_MODE_TIA_LEVEL_HIGH);
}

bool SwitchMatrix::isLineUsed(const SwitchLine& line) const {
    return line.chip < NUM_EXPANDERS && line.pin < 16;
}

void SwitchMatrix::configureLine(const SwitchLine& line) {
    if (!isLineUsed(line)) return;
    if (!_present[line.chip]) return;
    _mcp[line.chip].pinMode(line.pin, OUTPUT);
    writeLine(line, false);
}

void SwitchMatrix::writeLine(const SwitchLine& line, bool enabled) {
    if (!isLineUsed(line)) return;
    if (!_present[line.chip]) return;

    const bool level = enabled ? line.activeHigh : !line.activeHigh;
    _mcp[line.chip].digitalWrite(line.pin, level ? HIGH : LOW);
}

void SwitchMatrix::writeLineRaw(const SwitchLine& line, bool levelHigh) {
    if (!isLineUsed(line)) return;
    if (!_present[line.chip]) return;
    _mcp[line.chip].digitalWrite(line.pin, levelHigh ? HIGH : LOW);
}
