#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>

#include "BoardPins.h"
#include "ProjectConfig.h"
#include "ReadTypes.h"
#include "DAC80502.h"
#include "ADS131M08.h"
#include "SwitchMatrix.h"
#include "MeasurementEngine.h"

DAC80502 dac;
ADS131M08 adc;
SwitchMatrix matrix;
MeasurementEngine meas;

static String lineBuffer;
static CellReading scanBuffer[NUM_ROWS][NUM_COLS];

struct NoiseCommandState {
    bool configured = false;
    bool streaming = false;
    uint8_t row = 0;
    uint8_t col = 0;
    ReadMode mode = ReadMode::Direct;
    uint8_t rfIndex = 2;
    float rfOhms = 10.0e3f;
    uint32_t sampleDelayUs = 0;
    uint32_t sampleIndex = 0;
    uint32_t nextSampleAtUs = 0;
};

struct NoiseSummary {
    bool initialized = false;
    double sumRaw = 0.0;
    double sumRawSq = 0.0;
    int32_t minRaw = 0;
    int32_t maxRaw = 0;
    double sumV = 0.0;
    double sumVSq = 0.0;
    float minV = 0.0f;
    float maxV = 0.0f;
    double sumI = 0.0;
    double sumISq = 0.0;
    float minI = 0.0f;
    float maxI = 0.0f;
};

static NoiseCommandState noiseState;

static void printHelp();
static void printStatus();
static void printI2cScan();
static void handleCommand(String line);
static int parseRfIndex(const String& token);
static bool parseReadModeToken(const String& token, ReadMode& mode);
static bool parseUint32Token(const String& token, uint32_t& value);
static void printCellReadingHuman(const CellReading& r);
static void printCellDataLine(const CellReading& r);
static void printScanDataBlock(const char* modeName, CellReading data[NUM_ROWS][NUM_COLS]);
static void printRfStatus();
static void printVMMResult(uint8_t rowBits, float vsel, float vcm, const float currents[NUM_COLS]);
static void printNoiseSample(const NoiseReading& r);
static void noiseSummaryAdd(NoiseSummary& summary, const NoiseReading& r);
static void printNoiseSummary(uint8_t channel, uint32_t count, const NoiseSummary& summary);
static bool setupNoiseReadout(uint8_t row, uint8_t col, ReadMode mode, uint8_t rfIndex);
static bool runNoiseRead(uint32_t numSamples, uint32_t sampleDelayUs);
static void serviceNoiseStream();
static void stopNoiseStream();
static String tokenAt(const String& s, uint8_t index);
static bool parseRowCol(const String& line, int& row, int& col);
static bool parseRowBitsDecimal(const String& token, uint8_t& rowBits);
static bool parseRowBitsBinary(const String& token, uint8_t& rowBits);
static bool biasVoltageInRange(float volts);
static bool validateVmmBias(float vsel, float vcm);
static void testMode();
static void testRf();

void setup() {
    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, LOW);

    Serial.begin(SERIAL_BAUD);
    delay(1000);
    Serial.println();
    Serial.println(F("Selectorless 8x8 resistive-array reader"));
    Serial.println(F("Firmware target: DFR0478 ESP32 + DAC80502 + ADS131M08 + MCP23017"));
    Serial.println(F("Build: auto-RF + machine-readable scan output"));

    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
    Wire.setClock(I2C_HZ);

    SPI.begin(PIN_SPI_SCLK, PIN_SPI_MISO, PIN_SPI_MOSI);

    const bool dacOk = dac.begin(SPI, PIN_DAC_CS_N, DAC_SPI_HZ, DAC_REF_VOLTS, DAC_OUTPUT_GAIN);
    Serial.print(F("DAC init: "));
    Serial.println(dacOk ? F("OK") : F("FAIL"));

    const bool adcOk = adc.begin(SPI, PIN_ADC_CS_N, PIN_ADC_DRDY_N, PIN_ADC_SYNC_RESET_N,
                                 ADC_SPI_HZ, ADC_REF_VOLTS, ADC_PGA_GAIN);
    Serial.print(F("ADC init: "));
    Serial.println(adcOk ? F("OK") : F("FAIL"));

    const bool swOk = matrix.begin(Wire);
    Serial.print(F("Switch matrix init: "));
    Serial.println(swOk ? F("OK") : F("WARN/FAIL - check MCP addresses and SwitchMap.h"));

    meas.begin(dac, adc, matrix);
    meas.setBias(1.650f, 1.750f);
    meas.setRfIndex(2); // 10k on all channels
    matrix.setMode(ReadMode::Direct);

    Serial.println(F("Default bias: VCM=1.650 V, VSEL=1.750 V, VREAD=0.100 V, RF=10k"));
    Serial.println(F("Default mode: DIRECT -> GPIO27 HIGH -> TP6/ROW_IDLE_BUS should equal VCM_DIST"));
    printHelp();

    digitalWrite(PIN_STATUS_LED, HIGH);
}

void loop() {
    while (Serial.available() > 0) {
        const char c = static_cast<char>(Serial.read());
        if (c == '\n' || c == '\r') {
            if (lineBuffer.length() > 0) {
                handleCommand(lineBuffer);
                lineBuffer = "";
            }
        } else {
            lineBuffer += c;
        }
    }

    serviceNoiseStream();
}

static void printHelp() {
    Serial.println();
    Serial.println(F("Commands:"));
    Serial.println(F("  HELP"));
    Serial.println(F("  STATUS"));
    Serial.println(F("  I2CSCAN"));
    Serial.println(F("  BIAS <vcm> <vsel>                     example: BIAS 1.65 1.75"));
    Serial.println(F("  SETBIAS <vsel> <vcm>                  VMM bias, example: SETBIAS 1.75 1.65"));
    Serial.println(F("  VMM <rowBitsDecimal>                  bit 0 -> row 0, ..., bit 7 -> row 7"));
    Serial.println(F("  VMMBIN <8_bit_binary_string>          leftmost char is bit 7, rightmost is bit 0"));
    Serial.println(F("  SETAVG <samples 1..1000>              ADC frames averaged inside ESP32 per output"));
    Serial.println(F("  RF <100|1k|10k|100k|1M>               set all TIA channels"));
    Serial.println(F("  RFCH <ch 0..7> <100|1k|10k|100k|1M>   set one TIA channel"));
    Serial.println(F("  RFSTATUS"));
    Serial.println(F("  MODE_DIRECT                           GPIO27 HIGH -> TP6 = VCM_DIST"));
    Serial.println(F("  MODE_VHALF                            GPIO27 LOW  -> TP6 = VHALF_DIST"));
    Serial.println(F("  MODE_FLOAT                            rows Hi-Z, columns non-TIA/Hi-Z throw"));
    Serial.println(F("  ZERO                                  read zero-bias frame"));
    Serial.println(F("  CELL_DIRECT <row> <col>               manual RF, row/col are 0..7"));
    Serial.println(F("  CELL_VHALF <row> <col>                manual RF, row/col are 0..7"));
    Serial.println(F("  CELL_FLOAT <row> <col>                manual RF, unselected rows/columns float"));
    Serial.println(F("  CELL_DIRECT_AUTO <row> <col>          auto RF"));
    Serial.println(F("  CELL_VHALF_AUTO <row> <col>           auto RF"));
    Serial.println(F("  CELL_FLOAT_AUTO <row> <col>           auto RF, unselected rows/columns float"));
    Serial.println(F("  ROW_DIRECT <row>                      manual RF row read"));
    Serial.println(F("  NOISE_SETUP <row> <col> <DIRECT|VHALF> <rf>"));
    Serial.println(F("  NOISE_READ <numSamples> <sampleDelayUs>"));
    Serial.println(F("  NOISE_STREAM <sampleDelayUs>"));
    Serial.println(F("  NOISE_STOP"));
    Serial.println(F("  NOISE_READ_CELL <row> <col> <DIRECT|VHALF> <rf> <numSamples> <sampleDelayUs>"));
    Serial.println(F("  SCAN_DIRECT                           manual RF full scan"));
    Serial.println(F("  SCAN_VHALF                            manual RF full scan"));
    Serial.println(F("  SCAN_FLOAT                            manual RF full scan"));
    Serial.println(F("  SCAN_DIRECT_AUTO                      auto RF full scan"));
    Serial.println(F("  SCAN_VHALF_AUTO                       auto RF full scan"));
    Serial.println(F("  SCAN_FLOAT_AUTO                       auto RF full scan"));
    Serial.println(F("  TEST_MODE"));
    Serial.println(F("  TEST_RF"));
    Serial.println();
    Serial.println(F("Machine-readable scan output:"));
    Serial.println(F("  BEGIN_SCAN,<MODE>,8,8,VREAD,<vread>,AVG,<packet_avg>"));
    Serial.println(F("  DATA,<row>,<col>,<rf_ohm>,<vadc_v>,<current_a>,<r_ohm>,<status>,<attempts>,AVG,<packet_avg>"));
    Serial.println(F("  END_SCAN"));
    Serial.println(F("  VMM_RESULT,<rowBits>,<VSEL>,<VCM>,<deltaV>,<I0>,<I1>,<I2>,<I3>,<I4>,<I5>,<I6>,<I7>,AVG,<packet_avg>"));
    Serial.println(F("  ADC_SAMPLE,<sampleIndex>,<channel>,<adc_raw>,<vadc_v>,<current_a>,<rf_ohm>,<timestamp_us>,AVG,<packet_avg>"));
    Serial.println(F("  ADC_SUMMARY,<channel>,<numSamples>,<mean_raw>,<std_raw>,<pp_raw>,<mean_v>,<std_v>,<pp_v>,<mean_i>,<std_i>,<pp_i>,AVG,<packet_avg>"));
    Serial.println();
}

static void printStatus() {
    const BiasConfig b = meas.bias();
    Serial.println(F("BEGIN_STATUS"));
    Serial.print(F("VCM,")); Serial.println(b.vcm, 6);
    Serial.print(F("VSEL,")); Serial.println(b.vsel, 6);
    Serial.print(F("VHALF,")); Serial.println(b.vhalf, 6);
    Serial.print(F("VREAD,")); Serial.println(b.vread(), 6);
    Serial.print(F("ROW_IDLE_MODE_PIN,")); Serial.println(PIN_ROW_IDLE_MODE);
    Serial.println(F("MODE_DIRECT_LEVEL,HIGH"));
    Serial.println(F("MODE_VHALF_LEVEL,LOW"));
    Serial.println(F("FLOAT_STRATEGY,selected_row_VSEL_unselected_rows_HIZ_selected_col_TIA_unselected_cols_HIZ"));
    Serial.println(F("VMM_ROW_BITS,bit0=row0 bit1=row1 bit2=row2 bit3=row3 bit4=row4 bit5=row5 bit6=row6 bit7=row7"));
    Serial.println(F("VMM_BINARY_STRING,leftmost_bit7_rightmost_bit0"));
    Serial.println(F("VMM_COLUMN_ORDER,I0,I1,I2,I3,I4,I5,I6,I7"));
    Serial.println(F("VMM_DAC_ROUTING,uses_existing_board_mapping_DAC_A=VCM_DAC_B=VSEL"));
    Serial.println(F("VMM_COLUMN_LIMITATION,no_firmware_VCM_clamp_columns_use_TIA_readout_or_VHALF_parking"));
    Serial.print(F("PACKET_AVG,")); Serial.println(meas.packetAverageSamples());
    Serial.print(F("NOISE_CONFIGURED,")); Serial.println(noiseState.configured ? F("YES") : F("NO"));
    if (noiseState.configured) {
        Serial.print(F("NOISE_CHANNEL,"));
        Serial.print(noiseState.row);
        Serial.print(F(","));
        Serial.print(noiseState.col);
        Serial.print(F(","));
        Serial.print(readModeName(noiseState.mode));
        Serial.print(F(","));
        Serial.print(rfNameFromIndex(noiseState.rfIndex));
        Serial.print(F(","));
        Serial.println(noiseState.rfOhms, 1);
    }
    Serial.print(F("NOISE_STREAMING,")); Serial.println(noiseState.streaming ? F("YES") : F("NO"));
    printRfStatus();
    Serial.println(F("END_STATUS"));
}

static void printI2cScan() {
    Serial.println(F("BEGIN_I2CSCAN"));
    for (uint8_t addr = 1; addr < 127; ++addr) {
        Wire.beginTransmission(addr);
        const uint8_t err = Wire.endTransmission();
        if (err == 0) {
            Serial.print(F("I2C,0x"));
            if (addr < 16) Serial.print('0');
            Serial.println(addr, HEX);
        }
    }
    Serial.println(F("END_I2CSCAN"));
}

static void handleCommand(String line) {
    line.trim();
    line.toUpperCase();
    if (line.length() == 0) return;

    const String cmd = tokenAt(line, 0);

    if (cmd == "HELP") {
        printHelp();
        return;
    }

    if (cmd == "STATUS") {
        printStatus();
        return;
    }

    if (cmd == "I2CSCAN") {
        printI2cScan();
        return;
    }

    if (cmd == "SETBIAS") {
        const String vselToken = tokenAt(line, 1);
        const String vcmToken = tokenAt(line, 2);
        const float vsel = vselToken.toFloat();
        const float vcm = vcmToken.toFloat();
        if (vselToken.length() == 0 || vcmToken.length() == 0 ||
            !biasVoltageInRange(vsel) || !biasVoltageInRange(vcm)) {
            Serial.println(F("ERROR,bias_voltage_out_of_range"));
            return;
        }
        if (!validateVmmBias(vsel, vcm)) return;

        if (!meas.setBiasVoltages(vsel, vcm)) {
            Serial.println(F("ERROR,bias_set_failed"));
            return;
        }

        const BiasConfig b = meas.bias();
        Serial.print(F("OK,SETBIAS,VSEL,")); Serial.print(b.vsel, 6);
        Serial.print(F(",VCM,")); Serial.print(b.vcm, 6);
        Serial.print(F(",DELTAV,")); Serial.println(b.vread(), 6);
        return;
    }

    if (cmd == "VMM" || cmd == "VMMBIN") {
        uint8_t rowBits = 0;
        const bool parsed = (cmd == "VMM") ? parseRowBitsDecimal(tokenAt(line, 1), rowBits)
                                           : parseRowBitsBinary(tokenAt(line, 1), rowBits);
        if (!parsed) {
            Serial.println(cmd == "VMM" ? F("ERROR,invalid_row_bits") : F("ERROR,invalid_binary_string"));
            return;
        }

        const BiasConfig b = meas.bias();
        if (!validateVmmBias(b.vsel, b.vcm)) return;

        float currents[NUM_COLS] = {0};
        if (!meas.runBinaryVMM(rowBits, currents)) {
            Serial.println(F("ERROR,measurement_failed_or_adc_timeout"));
            return;
        }

        printVMMResult(rowBits, b.vsel, b.vcm, currents);
        return;
    }

    if (cmd == "SETAVG") {
        uint32_t samples = 0;
        if (!parseUint32Token(tokenAt(line, 1), samples) ||
            samples < 1 || samples > MAX_PACKET_ADC_AVG) {
            Serial.println(F("ERROR,invalid_average_count"));
            return;
        }
        if (!meas.setPacketAverageSamples(static_cast<uint16_t>(samples))) {
            Serial.println(F("ERROR,invalid_average_count"));
            return;
        }
        Serial.print(F("OK,SETAVG,"));
        Serial.println(meas.packetAverageSamples());
        return;
    }

    if (cmd == "NOISE_SETUP") {
        uint32_t rowValue = 0;
        uint32_t colValue = 0;
        ReadMode mode = ReadMode::Direct;
        const int rfIdx = parseRfIndex(tokenAt(line, 4));

        if (!parseUint32Token(tokenAt(line, 1), rowValue) ||
            !parseUint32Token(tokenAt(line, 2), colValue) ||
            rowValue >= NUM_ROWS || colValue >= NUM_COLS) {
            Serial.println(F("ERROR,invalid_noise_channel"));
            return;
        }
        if (!parseReadModeToken(tokenAt(line, 3), mode)) {
            Serial.println(F("ERROR,invalid_noise_mode"));
            return;
        }
        if (rfIdx < 0) {
            Serial.println(F("ERROR,invalid_noise_rf"));
            return;
        }
        if (!setupNoiseReadout(static_cast<uint8_t>(rowValue),
                               static_cast<uint8_t>(colValue),
                               mode,
                               static_cast<uint8_t>(rfIdx))) {
            Serial.println(F("ERROR,adc_read_failed"));
        }
        return;
    }

    if (cmd == "NOISE_READ") {
        uint32_t numSamples = 0;
        uint32_t sampleDelayUs = 0;
        if (!parseUint32Token(tokenAt(line, 1), numSamples) ||
            !parseUint32Token(tokenAt(line, 2), sampleDelayUs) ||
            numSamples == 0 || numSamples > MAX_NOISE_SAMPLES ||
            sampleDelayUs < MIN_NOISE_SAMPLE_DELAY_US) {
            Serial.println(F("ERROR,invalid_noise_sample_count"));
            return;
        }
        if (!runNoiseRead(numSamples, sampleDelayUs)) {
            Serial.println(noiseState.configured ? F("ERROR,adc_read_failed") : F("ERROR,noise_not_setup"));
        }
        return;
    }

    if (cmd == "NOISE_STREAM") {
        uint32_t sampleDelayUs = 0;
        if (!parseUint32Token(tokenAt(line, 1), sampleDelayUs) ||
            sampleDelayUs < MIN_NOISE_SAMPLE_DELAY_US) {
            Serial.println(F("ERROR,invalid_noise_sample_count"));
            return;
        }
        if (!noiseState.configured || !meas.noiseConfigured()) {
            Serial.println(F("ERROR,noise_not_setup"));
            return;
        }
        noiseState.streaming = true;
        noiseState.sampleDelayUs = sampleDelayUs;
        noiseState.sampleIndex = 0;
        noiseState.nextSampleAtUs = micros();
        Serial.print(F("NOISE_STREAM_OK,"));
        Serial.print(noiseState.col);
        Serial.print(F(","));
        Serial.println(sampleDelayUs);
        return;
    }

    if (cmd == "NOISE_STOP") {
        stopNoiseStream();
        return;
    }

    if (cmd == "NOISE_READ_CELL") {
        uint32_t rowValue = 0;
        uint32_t colValue = 0;
        uint32_t numSamples = 0;
        uint32_t sampleDelayUs = 0;
        ReadMode mode = ReadMode::Direct;
        const int rfIdx = parseRfIndex(tokenAt(line, 4));

        if (!parseUint32Token(tokenAt(line, 1), rowValue) ||
            !parseUint32Token(tokenAt(line, 2), colValue) ||
            rowValue >= NUM_ROWS || colValue >= NUM_COLS) {
            Serial.println(F("ERROR,invalid_noise_channel"));
            return;
        }
        if (!parseReadModeToken(tokenAt(line, 3), mode)) {
            Serial.println(F("ERROR,invalid_noise_mode"));
            return;
        }
        if (rfIdx < 0) {
            Serial.println(F("ERROR,invalid_noise_rf"));
            return;
        }
        if (!parseUint32Token(tokenAt(line, 5), numSamples) ||
            !parseUint32Token(tokenAt(line, 6), sampleDelayUs) ||
            numSamples == 0 || numSamples > MAX_NOISE_SAMPLES ||
            sampleDelayUs < MIN_NOISE_SAMPLE_DELAY_US) {
            Serial.println(F("ERROR,invalid_noise_sample_count"));
            return;
        }
        if (!setupNoiseReadout(static_cast<uint8_t>(rowValue),
                               static_cast<uint8_t>(colValue),
                               mode,
                               static_cast<uint8_t>(rfIdx))) {
            Serial.println(F("ERROR,adc_read_failed"));
            return;
        }
        if (!runNoiseRead(numSamples, sampleDelayUs)) {
            Serial.println(F("ERROR,adc_read_failed"));
        }
        return;
    }

    if (cmd == "BIAS") {
        const float vcm = tokenAt(line, 1).toFloat();
        const float vsel = tokenAt(line, 2).toFloat();
        if (vcm <= 0.0f || vsel <= 0.0f || vsel <= vcm) {
            Serial.println(F("ERROR,use BIAS <vcm> <vsel>, with vsel > vcm"));
            return;
        }
        meas.setBias(vcm, vsel);
        const BiasConfig b = meas.bias();
        Serial.print(F("OK,BIAS,VCM,")); Serial.print(b.vcm, 6);
        Serial.print(F(",VSEL,")); Serial.print(b.vsel, 6);
        Serial.print(F(",VHALF,")); Serial.print(b.vhalf, 6);
        Serial.print(F(",VREAD,")); Serial.println(b.vread(), 6);
        return;
    }

    if (cmd == "RF") {
        const int idx = parseRfIndex(tokenAt(line, 1));
        if (idx < 0) {
            Serial.println(F("ERROR,RF must be one of 100, 1K, 10K, 100K, 1M"));
            return;
        }
        if (!meas.setRfIndex(static_cast<uint8_t>(idx))) {
            Serial.println(F("ERROR,RF set failed"));
            return;
        }
        Serial.print(F("OK,RF_GLOBAL,"));
        Serial.print(RF_RANGES[idx].name);
        Serial.print(F(","));
        Serial.println(RF_RANGES[idx].ohms, 1);
        return;
    }

    if (cmd == "RFCH") {
        const int ch = tokenAt(line, 1).toInt();
        const int idx = parseRfIndex(tokenAt(line, 2));
        if (ch < 0 || ch >= NUM_COLS || idx < 0) {
            Serial.println(F("ERROR,use RFCH <ch 0..7> <100|1K|10K|100K|1M>"));
            return;
        }
        if (!meas.setRfIndexForChannel(static_cast<uint8_t>(ch), static_cast<uint8_t>(idx))) {
            Serial.println(F("ERROR,RFCH set failed"));
            return;
        }
        Serial.print(F("OK,RFCH,"));
        Serial.print(ch);
        Serial.print(F(","));
        Serial.print(RF_RANGES[idx].name);
        Serial.print(F(","));
        Serial.println(RF_RANGES[idx].ohms, 1);
        return;
    }

    if (cmd == "RFSTATUS") {
        printRfStatus();
        return;
    }

    if (cmd == "MODE_DIRECT") {
        matrix.setMode(ReadMode::Direct);
        Serial.println(F("OK,MODE_DIRECT,GPIO27,HIGH,TP6_SHOULD_EQUAL,VCM_DIST"));
        return;
    }

    if (cmd == "MODE_VHALF") {
        matrix.setMode(ReadMode::VHalf);
        Serial.println(F("OK,MODE_VHALF,GPIO27,LOW,TP6_SHOULD_EQUAL,VHALF_DIST"));
        return;
    }

    if (cmd == "MODE_FLOAT") {
        matrix.floatAllRows();
        matrix.parkAllColumnsFloat();
        Serial.println(F("OK,MODE_FLOAT,ROWS,HIZ,COLUMNS,NON_TIA_HIZ_THROW"));
        return;
    }

    if (cmd == "ZERO") {
        AdcFrame frame;
        if (!meas.readZeroFrame(frame)) {
            Serial.println(F("ERROR,ADC timeout"));
            return;
        }
        Serial.println(F("BEGIN_ZERO,8"));
        for (uint8_t c = 0; c < NUM_COLS; ++c) {
            Serial.print(F("ZERO,"));
            Serial.print(c);
            Serial.print(F(","));
            Serial.print(frame.volts[c], 9);
            Serial.print(F(",AVG,"));
            Serial.println(meas.packetAverageSamples());
        }
        Serial.println(F("END_ZERO"));
        return;
    }

    if (cmd == "CELL_DIRECT" || cmd == "CELL_VHALF" || cmd == "CELL_FLOAT" ||
        cmd == "CELL_DIRECT_AUTO" || cmd == "CELL_VHALF_AUTO" || cmd == "CELL_FLOAT_AUTO") {
        int row = -1;
        int col = -1;
        if (!parseRowCol(line, row, col)) {
            Serial.println(F("ERROR,row and col must be 0..7"));
            return;
        }

        CellReading r;
        bool ok = false;
        if (cmd == "CELL_DIRECT") {
            ok = meas.measureCellDirect(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        } else if (cmd == "CELL_VHALF") {
            ok = meas.measureCellVHalf(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        } else if (cmd == "CELL_FLOAT") {
            ok = meas.measureCellFloat(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        } else if (cmd == "CELL_DIRECT_AUTO") {
            ok = meas.measureCellDirectAuto(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        } else if (cmd == "CELL_VHALF_AUTO") {
            ok = meas.measureCellVHalfAuto(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        } else {
            ok = meas.measureCellFloatAuto(static_cast<uint8_t>(row), static_cast<uint8_t>(col), r);
        }

        if (!ok) {
            Serial.println(F("ERROR,measurement failed or ADC timeout"));
            return;
        }
        printCellReadingHuman(r);
        printCellDataLine(r);
        return;
    }

    if (cmd == "ROW_DIRECT") {
        const int row = tokenAt(line, 1).toInt();
        if (row < 0 || row >= NUM_ROWS) {
            Serial.println(F("ERROR,row must be 0..7"));
            return;
        }

        CellReading rowData[NUM_COLS];
        if (!meas.measureRowDirect(static_cast<uint8_t>(row), rowData)) {
            Serial.println(F("ERROR,measurement failed or ADC timeout"));
            return;
        }
        Serial.print(F("BEGIN_ROW,DIRECT,")); Serial.println(row);
        for (uint8_t c = 0; c < NUM_COLS; ++c) printCellDataLine(rowData[c]);
        Serial.println(F("END_ROW"));
        return;
    }

    if (cmd == "SCAN_DIRECT" || cmd == "SCAN_VHALF" || cmd == "SCAN_FLOAT" ||
        cmd == "SCAN_DIRECT_AUTO" || cmd == "SCAN_VHALF_AUTO" || cmd == "SCAN_FLOAT_AUTO") {
        Serial.print(F("RUNNING,"));
        Serial.println(cmd);

        bool ok = false;
        const char* modeName = "UNKNOWN";
        if (cmd == "SCAN_DIRECT") {
            ok = meas.scanDirect(scanBuffer);
            modeName = "DIRECT";
        } else if (cmd == "SCAN_VHALF") {
            ok = meas.scanVHalf(scanBuffer);
            modeName = "VHALF";
        } else if (cmd == "SCAN_FLOAT") {
            ok = meas.scanFloat(scanBuffer);
            modeName = "FLOAT";
        } else if (cmd == "SCAN_DIRECT_AUTO") {
            ok = meas.scanDirectAuto(scanBuffer);
            modeName = "DIRECT_AUTO";
        } else if (cmd == "SCAN_VHALF_AUTO") {
            ok = meas.scanVHalfAuto(scanBuffer);
            modeName = "VHALF_AUTO";
        } else {
            ok = meas.scanFloatAuto(scanBuffer);
            modeName = "FLOAT_AUTO";
        }

        if (!ok) {
            Serial.println(F("ERROR,scan failed or ADC timeout"));
            return;
        }
        printScanDataBlock(modeName, scanBuffer);
        return;
    }

    if (cmd == "TEST_MODE") {
        testMode();
        return;
    }

    if (cmd == "TEST_RF") {
        testRf();
        return;
    }

    Serial.println(F("ERROR,unknown command. Type HELP."));
}

static int parseRfIndex(const String& token) {
    if (token == "100") return 0;
    if (token == "1K" || token == "1000") return 1;
    if (token == "10K" || token == "10000") return 2;
    if (token == "100K" || token == "100000") return 3;
    if (token == "1M" || token == "1000000") return 4;
    return -1;
}

static bool parseReadModeToken(const String& token, ReadMode& mode) {
    if (token == "DIRECT") {
        mode = ReadMode::Direct;
        return true;
    }
    if (token == "VHALF" || token == "V_HALF" || token == "V/2") {
        mode = ReadMode::VHalf;
        return true;
    }
    return false;
}

static bool parseUint32Token(const String& token, uint32_t& value) {
    if (token.length() == 0) return false;

    uint32_t parsed = 0;
    for (uint16_t i = 0; i < token.length(); ++i) {
        if (!isDigit(token[i])) return false;
        const uint8_t digit = static_cast<uint8_t>(token[i] - '0');
        if (parsed > (UINT32_MAX - digit) / 10UL) return false;
        parsed = (parsed * 10UL) + digit;
    }

    value = parsed;
    return true;
}

static void printCellReadingHuman(const CellReading& r) {
    Serial.print(F("row=")); Serial.print(r.row);
    Serial.print(F(" col=")); Serial.print(r.col);
    Serial.print(F(" mode=")); Serial.print(readModeName(r.mode));
    Serial.print(F(" RF=")); Serial.print(r.rfOhms, 1);
    Serial.print(F(" Vadc=")); Serial.print(r.adcDiffVolts, 9);
    Serial.print(F(" I=")); Serial.print(r.currentAmps, 12);
    Serial.print(F(" R_ohm=")); Serial.print(r.resistanceOhms, 3);
    Serial.print(F(" status=")); Serial.print(autoRangeStatusName(r.status));
    Serial.print(F(" attempts=")); Serial.println(r.autorangeAttempts);
}

static void printCellDataLine(const CellReading& r) {
    Serial.print(F("DATA,"));
    Serial.print(r.row);
    Serial.print(F(","));
    Serial.print(r.col);
    Serial.print(F(","));
    Serial.print(r.rfOhms, 6);
    Serial.print(F(","));
    Serial.print(r.adcDiffVolts, 9);
    Serial.print(F(","));
    Serial.print(r.currentAmps, 12);
    Serial.print(F(","));
    Serial.print(r.resistanceOhms, 6);
    Serial.print(F(","));
    Serial.print(autoRangeStatusName(r.status));
    Serial.print(F(","));
    Serial.print(r.autorangeAttempts);
    Serial.print(F(",AVG,"));
    Serial.println(meas.packetAverageSamples());
}

static void printScanDataBlock(const char* modeName, CellReading data[NUM_ROWS][NUM_COLS]) {
    const BiasConfig b = meas.bias();
    Serial.print(F("BEGIN_SCAN,"));
    Serial.print(modeName);
    Serial.print(F(",8,8,VREAD,"));
    Serial.print(b.vread(), 9);
    Serial.print(F(",AVG,"));
    Serial.println(meas.packetAverageSamples());

    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        for (uint8_t c = 0; c < NUM_COLS; ++c) {
            printCellDataLine(data[r][c]);
        }
    }

    Serial.println(F("END_SCAN"));
}

static void printRfStatus() {
    Serial.println(F("BEGIN_RFSTATUS"));
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        Serial.print(F("RFCH,"));
        Serial.print(c);
        Serial.print(F(","));
        const uint8_t idx = meas.rfIndexForChannel(c);
        Serial.print(rfNameFromIndex(idx));
        Serial.print(F(","));
        Serial.println(rfOhmsFromIndex(idx), 1);
    }
    Serial.println(F("END_RFSTATUS"));
}

static void printVMMResult(uint8_t rowBits, float vsel, float vcm, const float currents[NUM_COLS]) {
    Serial.print(F("VMM_RESULT,"));
    Serial.print(rowBits);
    Serial.print(F(","));
    Serial.print(vsel, 4);
    Serial.print(F(","));
    Serial.print(vcm, 4);
    Serial.print(F(","));
    Serial.print(vsel - vcm, 4);
    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        Serial.print(F(","));
        Serial.print(currents[c], 12);
    }
    Serial.print(F(",AVG,"));
    Serial.print(meas.packetAverageSamples());
    Serial.println();
}

static void printNoiseSample(const NoiseReading& r) {
    Serial.print(F("ADC_SAMPLE,"));
    Serial.print(r.sampleIndex);
    Serial.print(F(","));
    Serial.print(r.channel);
    Serial.print(F(","));
    Serial.print(r.adcRaw);
    Serial.print(F(","));
    Serial.print(r.adcVolts, 9);
    Serial.print(F(","));
    Serial.print(r.currentAmps, 12);
    Serial.print(F(","));
    Serial.print(r.rfOhms, 6);
    Serial.print(F(","));
    Serial.print(r.timestampUs);
    Serial.print(F(",AVG,"));
    Serial.println(meas.packetAverageSamples());
}

static void noiseSummaryAdd(NoiseSummary& summary, const NoiseReading& r) {
    const double raw = static_cast<double>(r.adcRaw);
    const double v = static_cast<double>(r.adcVolts);
    const double i = static_cast<double>(r.currentAmps);

    if (!summary.initialized) {
        summary.initialized = true;
        summary.minRaw = r.adcRaw;
        summary.maxRaw = r.adcRaw;
        summary.minV = r.adcVolts;
        summary.maxV = r.adcVolts;
        summary.minI = r.currentAmps;
        summary.maxI = r.currentAmps;
    }

    if (r.adcRaw < summary.minRaw) summary.minRaw = r.adcRaw;
    if (r.adcRaw > summary.maxRaw) summary.maxRaw = r.adcRaw;
    if (r.adcVolts < summary.minV) summary.minV = r.adcVolts;
    if (r.adcVolts > summary.maxV) summary.maxV = r.adcVolts;
    if (r.currentAmps < summary.minI) summary.minI = r.currentAmps;
    if (r.currentAmps > summary.maxI) summary.maxI = r.currentAmps;

    summary.sumRaw += raw;
    summary.sumRawSq += raw * raw;
    summary.sumV += v;
    summary.sumVSq += v * v;
    summary.sumI += i;
    summary.sumISq += i * i;
}

static void printNoiseSummary(uint8_t channel, uint32_t count, const NoiseSummary& summary) {
    if (count == 0 || !summary.initialized) return;

    const double n = static_cast<double>(count);
    const double meanRaw = summary.sumRaw / n;
    const double meanV = summary.sumV / n;
    const double meanI = summary.sumI / n;
    const double varRaw = max(0.0, (summary.sumRawSq / n) - (meanRaw * meanRaw));
    const double varV = max(0.0, (summary.sumVSq / n) - (meanV * meanV));
    const double varI = max(0.0, (summary.sumISq / n) - (meanI * meanI));

    Serial.print(F("ADC_SUMMARY,"));
    Serial.print(channel);
    Serial.print(F(","));
    Serial.print(count);
    Serial.print(F(","));
    Serial.print(meanRaw, 3);
    Serial.print(F(","));
    Serial.print(sqrt(varRaw), 3);
    Serial.print(F(","));
    Serial.print(static_cast<int32_t>(summary.maxRaw - summary.minRaw));
    Serial.print(F(","));
    Serial.print(meanV, 9);
    Serial.print(F(","));
    Serial.print(sqrt(varV), 9);
    Serial.print(F(","));
    Serial.print(static_cast<double>(summary.maxV - summary.minV), 9);
    Serial.print(F(","));
    Serial.print(meanI, 12);
    Serial.print(F(","));
    Serial.print(sqrt(varI), 12);
    Serial.print(F(","));
    Serial.print(static_cast<double>(summary.maxI - summary.minI), 12);
    Serial.print(F(",AVG,"));
    Serial.println(meas.packetAverageSamples());
}

static bool setupNoiseReadout(uint8_t row, uint8_t col, ReadMode mode, uint8_t rfIndex) {
    noiseState.streaming = false;
    if (!meas.configureNoiseReadout(row, col, mode, rfIndex)) return false;

    noiseState.configured = true;
    noiseState.row = row;
    noiseState.col = col;
    noiseState.mode = mode;
    noiseState.rfIndex = rfIndex;
    noiseState.rfOhms = meas.rfOhmsForChannel(col);
    noiseState.sampleDelayUs = 0;
    noiseState.sampleIndex = 0;
    noiseState.nextSampleAtUs = 0;

    Serial.print(F("NOISE_SETUP_OK,"));
    Serial.print(row);
    Serial.print(F(","));
    Serial.print(col);
    Serial.print(F(","));
    Serial.print(readModeName(mode));
    Serial.print(F(","));
    Serial.print(rfNameFromIndex(rfIndex));
    Serial.print(F(","));
    Serial.println(noiseState.rfOhms, 6);
    return true;
}

static bool runNoiseRead(uint32_t numSamples, uint32_t sampleDelayUs) {
    if (!noiseState.configured || !meas.noiseConfigured()) return false;

    NoiseSummary summary;
    for (uint32_t i = 0; i < numSamples; ++i) {
        NoiseReading reading;
        if (!meas.readNoiseSample(i, reading)) return false;
        printNoiseSample(reading);
        noiseSummaryAdd(summary, reading);
        if (i + 1 < numSamples && sampleDelayUs > 0) delayMicroseconds(sampleDelayUs);
    }

    printNoiseSummary(noiseState.col, numSamples, summary);
    Serial.print(F("END_NOISE_READ,"));
    Serial.println(numSamples);
    return true;
}

static void serviceNoiseStream() {
    if (!noiseState.streaming) return;

    const uint32_t now = micros();
    if (static_cast<int32_t>(now - noiseState.nextSampleAtUs) < 0) return;

    NoiseReading reading;
    if (!meas.readNoiseSample(noiseState.sampleIndex, reading)) {
        noiseState.streaming = false;
        Serial.println(F("ERROR,adc_read_failed"));
        return;
    }

    printNoiseSample(reading);
    noiseState.sampleIndex++;
    noiseState.nextSampleAtUs = micros() + noiseState.sampleDelayUs;
}

static void stopNoiseStream() {
    const uint32_t count = noiseState.sampleIndex;
    noiseState.streaming = false;
    Serial.print(F("END_NOISE_STREAM,"));
    Serial.println(count);
}

static bool parseRowCol(const String& line, int& row, int& col) {
    row = tokenAt(line, 1).toInt();
    col = tokenAt(line, 2).toInt();
    return row >= 0 && row < NUM_ROWS && col >= 0 && col < NUM_COLS;
}

static bool parseRowBitsDecimal(const String& token, uint8_t& rowBits) {
    if (token.length() == 0) return false;

    uint16_t value = 0;
    for (uint16_t i = 0; i < token.length(); ++i) {
        if (!isDigit(token[i])) return false;
        value = static_cast<uint16_t>((value * 10u) + static_cast<uint16_t>(token[i] - '0'));
        if (value > 255u) return false;
    }

    rowBits = static_cast<uint8_t>(value);
    return true;
}

static bool parseRowBitsBinary(const String& token, uint8_t& rowBits) {
    if (token.length() != NUM_ROWS) return false;

    uint8_t value = 0;
    for (uint8_t i = 0; i < NUM_ROWS; ++i) {
        const char c = token[i];
        if (c != '0' && c != '1') return false;
        value <<= 1;
        if (c == '1') value |= 0x01;
    }

    rowBits = value;
    return true;
}

static bool biasVoltageInRange(float volts) {
    return isfinite(volts) && volts >= VMM_MIN_SAFE_BIAS_V && volts <= VMM_MAX_SAFE_BIAS_V;
}

static bool validateVmmBias(float vsel, float vcm) {
    if (!biasVoltageInRange(vsel) || !biasVoltageInRange(vcm)) {
        Serial.println(F("ERROR,bias_voltage_out_of_range"));
        return false;
    }

    const float deltaV = vsel - vcm;
    if (deltaV <= 0.0f) {
        Serial.println(F("ERROR,deltaV_must_be_positive"));
        return false;
    }

    if (deltaV > VMM_MAX_SAFE_DELTA_V) {
        Serial.println(F("ERROR,deltaV_too_large"));
        return false;
    }

    return true;
}

static void testMode() {
    Serial.println(F("BEGIN_TEST_MODE"));
    matrix.setMode(ReadMode::Direct);
    Serial.println(F("MODE_DIRECT,GPIO27,HIGH,MEASURE_TP6,VCM_DIST"));
    delay(1000);
    matrix.setMode(ReadMode::VHalf);
    Serial.println(F("MODE_VHALF,GPIO27,LOW,MEASURE_TP6,VHALF_DIST"));
    delay(1000);
    matrix.setMode(ReadMode::Direct);
    Serial.println(F("MODE_DIRECT,GPIO27,HIGH,MEASURE_TP6,VCM_DIST"));
    Serial.println(F("END_TEST_MODE"));
}

static void testRf() {
    Serial.println(F("BEGIN_TEST_RF"));
    for (uint8_t idx = 0; idx < NUM_RF_RANGES; ++idx) {
        meas.setRfIndex(idx);
        Serial.print(F("RF_GLOBAL,"));
        Serial.print(rfNameFromIndex(idx));
        Serial.print(F(","));
        Serial.println(rfOhmsFromIndex(idx), 1);
        delay(500);
    }
    meas.setRfIndex(2);
    Serial.println(F("RF_GLOBAL,10k,10000.0"));
    Serial.println(F("END_TEST_RF"));
}

static String tokenAt(const String& s, uint8_t index) {
    int start = 0;
    uint8_t current = 0;

    while (start < static_cast<int>(s.length())) {
        while (start < static_cast<int>(s.length()) && s[start] == ' ') start++;
        int end = start;
        while (end < static_cast<int>(s.length()) && s[end] != ' ') end++;

        if (current == index) {
            return s.substring(start, end);
        }

        current++;
        start = end + 1;
    }

    return "";
}
