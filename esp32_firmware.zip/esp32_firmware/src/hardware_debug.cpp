#ifdef HARDWARE_DEBUG_BUILD

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_MCP23X17.h>

#include "ADS131M08.h"
#include "BoardPins.h"
#include "DAC80502.h"
#include "ProjectConfig.h"
#include "ReadTypes.h"
#include "SwitchMap.h"

static constexpr uint8_t MCP_COUNT = 4;
static constexpr uint8_t MCP_ADDR[MCP_COUNT] = {0x20, 0x21, 0x22, 0x23};

static DAC80502 dac;
static ADS131M08 adc;
static Adafruit_MCP23X17 mcp[MCP_COUNT];
static bool mcpPresent[MCP_COUNT] = {false, false, false, false};
static bool dacReady = false;
static bool adcReady = false;
static String inputLine;
static uint32_t lastReadyPrintMs = 0;
static uint32_t lastInputMs = 0;
static bool commandSeen = false;

static String tokenAt(const String& line, uint8_t index);
static int parseRangeIndex(const String& token);
static int parseLevel(const String& token);
static bool parseChannel(const String& token, DAC80502::Channel& channel);
static void printHelp();
static void printQuickStart();
static void printPrompt();
static void printPins();
static void initBuses();
static void initMcp();
static void initDac();
static void initAdc();
static void i2cScan();
static void configureKnownMcpOutputs();
static void writeMappedLine(const SwitchLine& line, bool enabled);
static void writeMappedLineRaw(const SwitchLine& line, bool high);
static void printMcpStatus();
static void printAdcFrame(uint8_t frames);
static bool handleDacShortcut(const String& line);
static void setDacBothVoltage(float volts);
static void setDacBothCode(uint16_t code);
static void dacRampTest();
static void dacStepTest();
static void handleCommand(String line);

void setup() {
    Serial.begin(SERIAL_BAUD);
    delay(1500);

    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, LOW);
    pinMode(PIN_ROW_IDLE_MODE, OUTPUT);
    digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_DIRECT_LEVEL);

    Serial.println();
    Serial.println(F("=================================================="));
    Serial.println(F("HARDWARE DEBUG FIRMWARE IS RUNNING"));
    Serial.println(F("Manual component control only. No final processing."));
    Serial.println(F("=================================================="));

    initBuses();
    printPins();
    printQuickStart();
    printPrompt();
    digitalWrite(PIN_STATUS_LED, HIGH);
}

void loop() {
    while (Serial.available() > 0) {
        const char c = static_cast<char>(Serial.read());
        if (c == '\r' || c == '\n') {
            inputLine.trim();
            if (inputLine.length() > 0) {
                commandSeen = true;
                handleCommand(inputLine);
            }
            inputLine = "";
        } else {
            inputLine += c;
            lastInputMs = millis();
        }
    }

    if (inputLine.length() > 0 && millis() - lastInputMs > 1200) {
        inputLine.trim();
        if (inputLine.length() > 0) {
            commandSeen = true;
            handleCommand(inputLine);
        }
        inputLine = "";
    }

    if (!commandSeen && millis() - lastReadyPrintMs > 3000) {
        lastReadyPrintMs = millis();
        Serial.println(F("DEBUG_READY,type HELP then press Enter"));
        Serial.println(F("If nothing happens after typing, set Serial Monitor line ending to Newline or Both NL & CR."));
        printPrompt();
    }
}

static String tokenAt(const String& line, uint8_t index) {
    int start = 0;
    uint8_t current = 0;

    while (start < line.length()) {
        while (start < line.length() && line[start] == ' ') start++;
        int end = line.indexOf(' ', start);
        if (end < 0) end = line.length();
        if (current == index) return line.substring(start, end);
        start = end + 1;
        current++;
    }

    return "";
}

static int parseRangeIndex(const String& token) {
    String t = token;
    t.toUpperCase();
    if (t == "100" || t == "100R") return 0;
    if (t == "1K" || t == "1000") return 1;
    if (t == "10K" || t == "10000") return 2;
    if (t == "100K" || t == "100000") return 3;
    if (t == "1M" || t == "1000000") return 4;
    return -1;
}

static int parseLevel(const String& token) {
    String t = token;
    t.toUpperCase();
    if (t == "1" || t == "HIGH" || t == "ON") return HIGH;
    if (t == "0" || t == "LOW" || t == "OFF") return LOW;
    return -1;
}

static bool parseChannel(const String& token, DAC80502::Channel& channel) {
    String t = token;
    t.toUpperCase();
    if (t == "A" || t == "0") {
        channel = DAC80502::ChannelA;
        return true;
    }
    if (t == "B" || t == "1") {
        channel = DAC80502::ChannelB;
        return true;
    }
    return false;
}

static void printHelp() {
    Serial.println();
    Serial.println(F("Commands"));
    Serial.println(F("  HELP                         show this menu"));
    Serial.println(F("  PINS                         print ESP32 pin map"));
    Serial.println(F("  INIT ALL                     init MCP, DAC, ADC"));
    Serial.println(F("  INIT MCP|DAC|ADC             init one component"));
    Serial.println(F("  I2CSCAN                      scan I2C bus"));
    Serial.println(F("  MCPSTATUS                    show MCP presence"));
    Serial.println(F("  LED <0|1|BLINK>              control status LED"));
    Serial.println(F("  GPIO <pin> <0|1>             digital write any ESP32 pin"));
    Serial.println(F("  DRDY                         read ADS131M08 DRDY pin"));
    Serial.println(F("  ADCRESET                     pulse ADS131M08 SYNC/RESET"));
    Serial.println(F("  ADCFRAME [count]             read raw ADC frame(s), no processing"));
    Serial.println(F("  ADCREG <addr>                read ADS131M08 register"));
    Serial.println(F("  ADCWREG <addr> <value>       write ADS131M08 register"));
    Serial.println(F("  DACV <A|B> <volts>           set DAC channel voltage"));
    Serial.println(F("  DACC <A|B> <0..65535>        set DAC channel raw code"));
    Serial.println(F("  DACREG <addr> <value>        write DAC register"));
    Serial.println(F("  a1.25 / b0.80                DAC-only shortcut: set A/B volts"));
    Serial.println(F("  v1.65                        DAC-only shortcut: set both volts"));
    Serial.println(F("  aa12345 / bb50000 / c32768   DAC-only shortcut: raw code A/B/both"));
    Serial.println(F("  r / s / z                    DAC-only ramp, step, or zero test"));
    Serial.println(F("  ROWMODE DIRECT|VHALF         GPIO27 mode switch"));
    Serial.println(F("  MCP <chip 0..3> <pin> <0|1>  raw MCP pin write"));
    Serial.println(F("  MCPALL <0|1>                 raw write all known MCP pins"));
    Serial.println(F("  ROWIDLE <row 0..7> <0|1>     mapped row idle switch"));
    Serial.println(F("  ROWSEL <row 0..7> <0|1>      mapped row select switch"));
    Serial.println(F("  COLTIA <col 0..7>            connect column to TIA"));
    Serial.println(F("  COLVHALF <col 0..7>          park column at VHALF"));
    Serial.println(F("  RF <col 0..7> <100|1k|10k|100k|1M|OFF>"));
    Serial.println(F("  RFOFF ALL|<col 0..7>         disable RF branches"));
    Serial.println(F("  SAFE                         rows off, columns VHALF, RF off, DAC 0V"));
    Serial.println();
}

static void printQuickStart() {
    Serial.println();
    Serial.println(F("Quick start"));
    Serial.println(F("  1) Type HELP and press Enter for all commands."));
    Serial.println(F("  2) Type INIT ALL to initialise MCP, DAC, and ADC."));
    Serial.println(F("  3) Type I2CSCAN. Expected MCP addresses: 0x20, 0x21, 0x22, 0x23."));
    Serial.println(F("  4) Type SAFE before changing tests."));
    Serial.println(F("  5) Try DACV A 1.65, ROWMODE DIRECT, COLTIA 0, RF 0 10k, ADCFRAME 1."));
    Serial.println();
}

static void printPrompt() {
    Serial.print(F("debug> "));
}

static void printPins() {
    Serial.println(F("BEGIN_PINS"));
    Serial.print(F("I2C_SDA,")); Serial.println(PIN_I2C_SDA);
    Serial.print(F("I2C_SCL,")); Serial.println(PIN_I2C_SCL);
    Serial.print(F("SPI_SCLK,")); Serial.println(PIN_SPI_SCLK);
    Serial.print(F("SPI_MISO,")); Serial.println(PIN_SPI_MISO);
    Serial.print(F("SPI_MOSI,")); Serial.println(PIN_SPI_MOSI);
    Serial.print(F("DAC_CS_N,")); Serial.println(PIN_DAC_CS_N);
    Serial.print(F("ADC_CS_N,")); Serial.println(PIN_ADC_CS_N);
    Serial.print(F("ADC_DRDY_N,")); Serial.println(PIN_ADC_DRDY_N);
    Serial.print(F("ADC_SYNC_RESET_N,")); Serial.println(PIN_ADC_SYNC_RESET_N);
    Serial.print(F("ROW_IDLE_MODE,")); Serial.println(PIN_ROW_IDLE_MODE);
    Serial.print(F("STATUS_LED,")); Serial.println(PIN_STATUS_LED);
    Serial.println(F("END_PINS"));
}

static void initBuses() {
    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
    Wire.setClock(I2C_HZ);
    SPI.begin(PIN_SPI_SCLK, PIN_SPI_MISO, PIN_SPI_MOSI);

    pinMode(PIN_DAC_CS_N, OUTPUT);
    pinMode(PIN_ADC_CS_N, OUTPUT);
    digitalWrite(PIN_DAC_CS_N, HIGH);
    digitalWrite(PIN_ADC_CS_N, HIGH);
    pinMode(PIN_ADC_DRDY_N, INPUT_PULLUP);
    pinMode(PIN_ADC_SYNC_RESET_N, OUTPUT);
    digitalWrite(PIN_ADC_SYNC_RESET_N, HIGH);
}

static void initMcp() {
    Serial.println(F("BEGIN_INIT_MCP"));
    for (uint8_t i = 0; i < MCP_COUNT; ++i) {
        mcpPresent[i] = mcp[i].begin_I2C(MCP_ADDR[i], &Wire);
        Serial.print(F("MCP,"));
        Serial.print(i);
        Serial.print(F(",0x"));
        Serial.print(MCP_ADDR[i], HEX);
        Serial.print(F(","));
        Serial.println(mcpPresent[i] ? F("OK") : F("FAIL"));
    }
    configureKnownMcpOutputs();
    Serial.println(F("END_INIT_MCP"));
}

static void initDac() {
    dacReady = dac.begin(SPI, PIN_DAC_CS_N, DAC_SPI_HZ, DAC_REF_VOLTS, DAC_OUTPUT_GAIN);
    Serial.print(F("DAC_INIT,"));
    Serial.println(dacReady ? F("OK") : F("FAIL"));
}

static void initAdc() {
    adcReady = adc.begin(SPI, PIN_ADC_CS_N, PIN_ADC_DRDY_N, PIN_ADC_SYNC_RESET_N,
                         ADC_SPI_HZ, ADC_REF_VOLTS, ADC_PGA_GAIN);
    Serial.print(F("ADC_INIT,"));
    Serial.println(adcReady ? F("OK") : F("FAIL"));
}

static void i2cScan() {
    Serial.println(F("BEGIN_I2CSCAN"));
    for (uint8_t addr = 1; addr < 127; ++addr) {
        Wire.beginTransmission(addr);
        if (Wire.endTransmission() == 0) {
            Serial.print(F("I2C,0x"));
            if (addr < 16) Serial.print('0');
            Serial.println(addr, HEX);
        }
    }
    Serial.println(F("END_I2CSCAN"));
}

static void configureKnownMcpOutputs() {
    for (uint8_t r = 0; r < NUM_ROWS; ++r) {
        if (mcpPresent[ROW_IDLE_EN[r].chip]) mcp[ROW_IDLE_EN[r].chip].pinMode(ROW_IDLE_EN[r].pin, OUTPUT);
        if (mcpPresent[ROW_SEL_EN[r].chip]) mcp[ROW_SEL_EN[r].chip].pinMode(ROW_SEL_EN[r].pin, OUTPUT);
        writeMappedLine(ROW_IDLE_EN[r], false);
        writeMappedLine(ROW_SEL_EN[r], false);
    }

    for (uint8_t c = 0; c < NUM_COLS; ++c) {
        if (mcpPresent[COL_MODE[c].chip]) mcp[COL_MODE[c].chip].pinMode(COL_MODE[c].pin, OUTPUT);
        writeMappedLineRaw(COL_MODE[c], !COL_MODE_TIA_LEVEL_HIGH);
        for (uint8_t rf = 0; rf < NUM_RF_RANGES; ++rf) {
            if (mcpPresent[RF_EN[c][rf].chip]) mcp[RF_EN[c][rf].chip].pinMode(RF_EN[c][rf].pin, OUTPUT);
            writeMappedLine(RF_EN[c][rf], false);
        }
    }
}

static void writeMappedLine(const SwitchLine& line, bool enabled) {
    if (line.chip >= MCP_COUNT || line.pin >= 16 || !mcpPresent[line.chip]) return;
    const bool high = enabled ? line.activeHigh : !line.activeHigh;
    mcp[line.chip].digitalWrite(line.pin, high ? HIGH : LOW);
}

static void writeMappedLineRaw(const SwitchLine& line, bool high) {
    if (line.chip >= MCP_COUNT || line.pin >= 16 || !mcpPresent[line.chip]) return;
    mcp[line.chip].digitalWrite(line.pin, high ? HIGH : LOW);
}

static void printMcpStatus() {
    Serial.println(F("BEGIN_MCPSTATUS"));
    for (uint8_t i = 0; i < MCP_COUNT; ++i) {
        Serial.print(F("MCP,"));
        Serial.print(i);
        Serial.print(F(",0x"));
        Serial.print(MCP_ADDR[i], HEX);
        Serial.print(F(","));
        Serial.println(mcpPresent[i] ? F("PRESENT") : F("MISSING"));
    }
    Serial.println(F("END_MCPSTATUS"));
}

static void printAdcFrame(uint8_t frames) {
    if (!adcReady) initAdc();

    for (uint8_t n = 0; n < frames; ++n) {
        AdcFrame frame;
        if (!adc.readFrame(frame, ADC_DRDY_TIMEOUT_US)) {
            Serial.println(F("ERROR,ADC_TIMEOUT"));
            return;
        }

        Serial.print(F("ADCFRAME,"));
        Serial.print(n);
        Serial.print(F(",STATUS,0x"));
        Serial.println(frame.status, HEX);
        for (uint8_t ch = 0; ch < NUM_COLS; ++ch) {
            Serial.print(F("ADCCH,"));
            Serial.print(ch);
            Serial.print(F(",RAW,"));
            Serial.print(frame.raw[ch]);
            Serial.print(F(",VOLTS,"));
            Serial.println(frame.volts[ch], 9);
        }
    }
}

static float dacCodeToVoltage(uint16_t code) {
    return (static_cast<float>(code) / 65535.0f) * DAC_REF_VOLTS * DAC_OUTPUT_GAIN;
}

static bool startsWithNumber(const String& s, uint8_t start) {
    if (s.length() <= start) return false;
    const char c = s[start];
    return (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '+';
}

static void setDacBothVoltage(float volts) {
    if (!dacReady) initDac();
    const bool okA = dac.setVoltage(DAC80502::ChannelA, volts);
    const bool okB = dac.setVoltage(DAC80502::ChannelB, volts);
    Serial.print(okA && okB ? F("OK,DACBOTH,VOLTS,") : F("ERROR,DACBOTH,VOLTS,"));
    Serial.println(volts, 6);
}

static void setDacBothCode(uint16_t code) {
    if (!dacReady) initDac();
    const bool okA = dac.setCode(DAC80502::ChannelA, code);
    const bool okB = dac.setCode(DAC80502::ChannelB, code);
    Serial.print(okA && okB ? F("OK,DACBOTH,CODE,") : F("ERROR,DACBOTH,CODE,"));
    Serial.print(code);
    Serial.print(F(",EXPECTED_VOLTS,"));
    Serial.println(dacCodeToVoltage(code), 6);
}

static void dacRampTest() {
    if (!dacReady) initDac();
    Serial.println(F("BEGIN_DAC_RAMP"));
    for (uint32_t code = 0; code <= 65535UL; code += 1024UL) {
        setDacBothCode(static_cast<uint16_t>(code));
        delay(100);
    }
    setDacBothCode(0);
    Serial.println(F("END_DAC_RAMP"));
}

static void dacStepTest() {
    static const float testVoltages[] = {
        0.0f, 0.25f, 0.50f, 0.75f, 1.00f, 1.25f, 1.50f, 2.00f, 2.50f
    };

    Serial.println(F("BEGIN_DAC_STEP"));
    for (float volts : testVoltages) {
        setDacBothVoltage(volts);
        delay(1000);
    }
    setDacBothVoltage(0.0f);
    Serial.println(F("END_DAC_STEP"));
}

static bool handleDacShortcut(const String& line) {
    String t = line;
    t.trim();
    if (t.length() == 0 || t.indexOf(' ') >= 0) return false;

    String u = t;
    u.toUpperCase();

    if (u == "R") {
        dacRampTest();
        return true;
    }
    if (u == "S") {
        dacStepTest();
        return true;
    }
    if (u == "Z") {
        setDacBothVoltage(0.0f);
        return true;
    }
    if (u == "H") {
        printHelp();
        return true;
    }
    if (u.startsWith("AA") && startsWithNumber(u, 2)) {
        if (!dacReady) initDac();
        const uint16_t code = static_cast<uint16_t>(strtoul(u.substring(2).c_str(), nullptr, 0));
        const bool ok = dac.setCode(DAC80502::ChannelA, code);
        Serial.print(ok ? F("OK,DACA,CODE,") : F("ERROR,DACA,CODE,"));
        Serial.print(code);
        Serial.print(F(",EXPECTED_VOLTS,"));
        Serial.println(dacCodeToVoltage(code), 6);
        return true;
    }
    if (u.startsWith("BB") && startsWithNumber(u, 2)) {
        if (!dacReady) initDac();
        const uint16_t code = static_cast<uint16_t>(strtoul(u.substring(2).c_str(), nullptr, 0));
        const bool ok = dac.setCode(DAC80502::ChannelB, code);
        Serial.print(ok ? F("OK,DACB,CODE,") : F("ERROR,DACB,CODE,"));
        Serial.print(code);
        Serial.print(F(",EXPECTED_VOLTS,"));
        Serial.println(dacCodeToVoltage(code), 6);
        return true;
    }
    if ((u[0] == 'A' || u[0] == 'B' || u[0] == 'V' || u[0] == 'C') && startsWithNumber(u, 1)) {
        if (u[0] == 'A' || u[0] == 'B') {
            if (!dacReady) initDac();
            const DAC80502::Channel channel = (u[0] == 'A') ? DAC80502::ChannelA : DAC80502::ChannelB;
            const float volts = u.substring(1).toFloat();
            const bool ok = dac.setVoltage(channel, volts);
            Serial.print(ok ? F("OK,DAC,VOLTS,") : F("ERROR,DAC,VOLTS,"));
            Serial.print(u[0]);
            Serial.print(F(","));
            Serial.println(volts, 6);
            return true;
        }
        if (u[0] == 'V') {
            setDacBothVoltage(u.substring(1).toFloat());
            return true;
        }
        setDacBothCode(static_cast<uint16_t>(strtoul(u.substring(1).c_str(), nullptr, 0)));
        return true;
    }

    return false;
}

static void handleCommand(String line) {
    line.trim();
    Serial.print(F("CMD,"));
    Serial.println(line);
    if (handleDacShortcut(line)) {
        printPrompt();
        return;
    }
    String cmd = tokenAt(line, 0);
    cmd.toUpperCase();

    if (cmd == "HELP" || cmd == "?") {
        printHelp();
    } else if (cmd == "PINS") {
        printPins();
    } else if (cmd == "INIT") {
        String target = tokenAt(line, 1);
        target.toUpperCase();
        if (target == "ALL") {
            initMcp();
            initDac();
            initAdc();
        } else if (target == "MCP") {
            initMcp();
        } else if (target == "DAC") {
            initDac();
        } else if (target == "ADC") {
            initAdc();
        } else {
            Serial.println(F("ERROR,use INIT ALL|MCP|DAC|ADC"));
        }
    } else if (cmd == "I2CSCAN") {
        i2cScan();
    } else if (cmd == "MCPSTATUS") {
        printMcpStatus();
    } else if (cmd == "LED") {
        String mode = tokenAt(line, 1);
        mode.toUpperCase();
        if (mode == "BLINK") {
            for (uint8_t i = 0; i < 6; ++i) {
                digitalWrite(PIN_STATUS_LED, !digitalRead(PIN_STATUS_LED));
                delay(150);
            }
            Serial.println(F("OK,LED,BLINK"));
        } else {
            const int level = parseLevel(mode);
            if (level < 0) Serial.println(F("ERROR,use LED 0|1|BLINK"));
            else {
                digitalWrite(PIN_STATUS_LED, level);
                Serial.println(F("OK,LED"));
            }
        }
    } else if (cmd == "GPIO") {
        const int pin = tokenAt(line, 1).toInt();
        const int level = parseLevel(tokenAt(line, 2));
        if (level < 0) Serial.println(F("ERROR,use GPIO <pin> <0|1>"));
        else {
            pinMode(pin, OUTPUT);
            digitalWrite(pin, level);
            Serial.println(F("OK,GPIO"));
        }
    } else if (cmd == "DRDY") {
        Serial.print(F("DRDY,"));
        Serial.println(digitalRead(PIN_ADC_DRDY_N));
    } else if (cmd == "ADCRESET") {
        digitalWrite(PIN_ADC_SYNC_RESET_N, LOW);
        delayMicroseconds(10);
        digitalWrite(PIN_ADC_SYNC_RESET_N, HIGH);
        Serial.println(F("OK,ADCRESET"));
    } else if (cmd == "ADCFRAME") {
        int frames = tokenAt(line, 1).toInt();
        if (frames < 1) frames = 1;
        if (frames > 20) frames = 20;
        printAdcFrame(static_cast<uint8_t>(frames));
    } else if (cmd == "ADCREG") {
        if (!adcReady) initAdc();
        const uint8_t addr = static_cast<uint8_t>(strtoul(tokenAt(line, 1).c_str(), nullptr, 0));
        Serial.print(F("ADCREG,0x"));
        Serial.print(addr, HEX);
        Serial.print(F(",0x"));
        Serial.println(adc.readRegister(addr), HEX);
    } else if (cmd == "ADCWREG") {
        if (!adcReady) initAdc();
        const uint8_t addr = static_cast<uint8_t>(strtoul(tokenAt(line, 1).c_str(), nullptr, 0));
        const uint16_t value = static_cast<uint16_t>(strtoul(tokenAt(line, 2).c_str(), nullptr, 0));
        Serial.println(adc.writeRegister(addr, value) ? F("OK,ADCWREG") : F("ERROR,ADCWREG"));
    } else if (cmd == "DACV" || cmd == "DACC") {
        if (!dacReady) initDac();
        DAC80502::Channel channel;
        if (!parseChannel(tokenAt(line, 1), channel)) {
            Serial.println(F("ERROR,use DACV/DACC <A|B> <value>"));
            return;
        }
        bool ok = false;
        if (cmd == "DACV") {
            ok = dac.setVoltage(channel, tokenAt(line, 2).toFloat());
        } else {
            ok = dac.setCode(channel, static_cast<uint16_t>(strtoul(tokenAt(line, 2).c_str(), nullptr, 0)));
        }
        Serial.println(ok ? F("OK,DAC") : F("ERROR,DAC"));
    } else if (cmd == "DACREG") {
        if (!dacReady) initDac();
        const uint8_t reg = static_cast<uint8_t>(strtoul(tokenAt(line, 1).c_str(), nullptr, 0));
        const uint16_t value = static_cast<uint16_t>(strtoul(tokenAt(line, 2).c_str(), nullptr, 0));
        Serial.println(dac.writeRegister(reg, value) ? F("OK,DACREG") : F("ERROR,DACREG"));
    } else if (cmd == "ROWMODE") {
        String mode = tokenAt(line, 1);
        mode.toUpperCase();
        if (mode == "DIRECT") {
            digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_DIRECT_LEVEL);
            Serial.println(F("OK,ROWMODE,DIRECT"));
        } else if (mode == "VHALF") {
            digitalWrite(PIN_ROW_IDLE_MODE, ROW_IDLE_MODE_VHALF_LEVEL);
            Serial.println(F("OK,ROWMODE,VHALF"));
        } else {
            Serial.println(F("ERROR,use ROWMODE DIRECT|VHALF"));
        }
    } else if (cmd == "MCP") {
        const int chip = tokenAt(line, 1).toInt();
        const int pin = tokenAt(line, 2).toInt();
        const int level = parseLevel(tokenAt(line, 3));
        if (chip < 0 || chip >= MCP_COUNT || pin < 0 || pin > 15 || level < 0 || !mcpPresent[chip]) {
            Serial.println(F("ERROR,use MCP <chip 0..3> <pin 0..15> <0|1>; run INIT MCP first"));
        } else {
            mcp[chip].pinMode(pin, OUTPUT);
            mcp[chip].digitalWrite(pin, level);
            Serial.println(F("OK,MCP"));
        }
    } else if (cmd == "MCPALL") {
        const int level = parseLevel(tokenAt(line, 1));
        if (level < 0) {
            Serial.println(F("ERROR,use MCPALL <0|1>"));
        } else {
            for (uint8_t chip = 0; chip < MCP_COUNT; ++chip) {
                if (!mcpPresent[chip]) continue;
                for (uint8_t pin = 0; pin < 16; ++pin) {
                    mcp[chip].pinMode(pin, OUTPUT);
                    mcp[chip].digitalWrite(pin, level);
                }
            }
            Serial.println(F("OK,MCPALL"));
        }
    } else if (cmd == "ROWIDLE" || cmd == "ROWSEL") {
        if (!mcpPresent[0]) initMcp();
        const int row = tokenAt(line, 1).toInt();
        const int level = parseLevel(tokenAt(line, 2));
        if (row < 0 || row >= NUM_ROWS || level < 0) {
            Serial.println(F("ERROR,use ROWIDLE/ROWSEL <row 0..7> <0|1>"));
        } else {
            writeMappedLine(cmd == "ROWIDLE" ? ROW_IDLE_EN[row] : ROW_SEL_EN[row], level == HIGH);
            Serial.println(F("OK,ROW"));
        }
    } else if (cmd == "COLTIA" || cmd == "COLVHALF") {
        if (!mcpPresent[1]) initMcp();
        const int col = tokenAt(line, 1).toInt();
        if (col < 0 || col >= NUM_COLS) {
            Serial.println(F("ERROR,use COLTIA/COLVHALF <col 0..7>"));
        } else {
            writeMappedLineRaw(COL_MODE[col], cmd == "COLTIA" ? COL_MODE_TIA_LEVEL_HIGH : !COL_MODE_TIA_LEVEL_HIGH);
            Serial.println(F("OK,COL"));
        }
    } else if (cmd == "RF") {
        if (!mcpPresent[1]) initMcp();
        const int col = tokenAt(line, 1).toInt();
        String rangeToken = tokenAt(line, 2);
        rangeToken.toUpperCase();
        if (col < 0 || col >= NUM_COLS) {
            Serial.println(F("ERROR,use RF <col 0..7> <range|OFF>"));
            return;
        }
        for (uint8_t rf = 0; rf < NUM_RF_RANGES; ++rf) writeMappedLine(RF_EN[col][rf], false);
        if (rangeToken != "OFF") {
            const int rf = parseRangeIndex(rangeToken);
            if (rf < 0) {
                Serial.println(F("ERROR,range must be 100|1k|10k|100k|1M|OFF"));
                return;
            }
            writeMappedLine(RF_EN[col][rf], true);
        }
        Serial.println(F("OK,RF"));
    } else if (cmd == "RFOFF") {
        String target = tokenAt(line, 1);
        target.toUpperCase();
        if (target == "ALL") {
            for (uint8_t col = 0; col < NUM_COLS; ++col) {
                for (uint8_t rf = 0; rf < NUM_RF_RANGES; ++rf) writeMappedLine(RF_EN[col][rf], false);
            }
        } else {
            const int col = target.toInt();
            if (col < 0 || col >= NUM_COLS) {
                Serial.println(F("ERROR,use RFOFF ALL|<col 0..7>"));
                return;
            }
            for (uint8_t rf = 0; rf < NUM_RF_RANGES; ++rf) writeMappedLine(RF_EN[col][rf], false);
        }
        Serial.println(F("OK,RFOFF"));
    } else if (cmd == "SAFE") {
        if (!mcpPresent[0]) initMcp();
        for (uint8_t row = 0; row < NUM_ROWS; ++row) {
            writeMappedLine(ROW_IDLE_EN[row], false);
            writeMappedLine(ROW_SEL_EN[row], false);
        }
        for (uint8_t col = 0; col < NUM_COLS; ++col) {
            writeMappedLineRaw(COL_MODE[col], !COL_MODE_TIA_LEVEL_HIGH);
            for (uint8_t rf = 0; rf < NUM_RF_RANGES; ++rf) writeMappedLine(RF_EN[col][rf], false);
        }
        if (!dacReady) initDac();
        dac.setVoltage(DAC80502::ChannelA, 0.0f);
        dac.setVoltage(DAC80502::ChannelB, 0.0f);
        Serial.println(F("OK,SAFE"));
    } else {
        Serial.println(F("ERROR,unknown command. Type HELP."));
    }

    printPrompt();
}

#endif
